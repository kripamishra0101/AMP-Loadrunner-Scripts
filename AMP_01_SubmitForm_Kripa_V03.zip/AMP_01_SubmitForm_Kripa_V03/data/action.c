Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("Origin", 
		"https://www.google.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=91", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_custom_request("token", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1//0gCFnpXxMsVTyCgYIARAAGBASNwF-L9Ir0Ayg8WE19pfdAtCPdT8I1kSvGxp_tOkv3l1p3j6cJIPciVhV8xioIrFcdxTDMjqQyNw", 
		LAST);

	web_custom_request("issuetoken", 
		"URL=https://oauthaccountmanager.googleapis.com/v1/issuetoken", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"Body=force=false&response_type=token&scope=https://www.googleapis.com/auth/calendar.readonly+https://www.googleapis.com/auth/hangouts+https://www.googleapis.com/auth/hangouts.readonly+https://www.googleapis.com/auth/meetings+https://www.googleapis.com/auth/userinfo.email&enable_granular_permissions=false&client_id=919648714761-55j965o0km033psv3i9qls5mo3qtdrb0.apps.googleusercontent.com&origin=pkedcjkdefgpdelpbcmbmeomcjbeemfm&lib_ver=91.0.4472.114&release_channel=stable&device_id="
		"0c32b1cc-9f0b-44d4-92eb-288d201e023e&device_type=chrome", 
		LAST);

	web_custom_request("token_2", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1//0gCFnpXxMsVTyCgYIARAAGBASNwF-L9Ir0Ayg8WE19pfdAtCPdT8I1kSvGxp_tOkv3l1p3j6cJIPciVhV8xioIrFcdxTDMjqQyNw&scope=https://www.googleapis.com/auth/chromesync", 
		EXTRARES, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_variation_9.pb", "Referer=", ENDITEM, 
		LAST);

	lr_start_transaction("01_LaunchURL");

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_reg_find("Text=AMP �\x80� Banking, Super, Retirement, Financial Advice &amp; Insurance - AMP", 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("www.amp.com.au", 
		"URL=http://www.amp.com.au/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.amp.com.au/ddc/public/ui/assets/ddc-fonts/ddc-fonts.css", "Referer=https://www.amp.com.au/etc/designs/amp-au/clientlibs/clientlib-site.css", ENDITEM, 
		"Url=https://hello.myfonts.net/count/3a2740", "Referer=https://www.amp.com.au/etc/designs/amp-au/clientlibs/clientlib-site.css", ENDITEM, 
		"Url=https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,300,600", "Referer=https://www.amp.com.au/etc/designs/amp-au/clientlibs/clientlib-site.css", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/id?d_visid_ver=4.5.2&d_fieldgroup=A&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&mid=23569144125047983874531016401195797023&ts=1624946679923", "Referer=https://www.amp.com.au/", ENDITEM, 
		"Url=https://www.amp.com.au/etc/designs/amp-au/assets/aa8fe13f4c832769bd0ab2ea7e247013.svg", "Referer=https://www.amp.com.au/etc/designs/amp-au/clientlibs/clientlib-site.css", ENDITEM, 
		"Url=https://s.yimg.com/wi/ytc.js", "Referer=https://www.amp.com.au/", ENDITEM, 
		"Url=https://bat.bing.com/bat.js", "Referer=https://www.amp.com.au/", ENDITEM, 
		"Url=https://www.amp.com.au/etc/designs/amp-au/clientlibs/legacy-nps.js?_=1624946680087", "Referer=https://www.amp.com.au/", ENDITEM, 
		"Url=https://www.amp.com.au/etc/designs/amp-au/assets/819af3d3abdc9f135d49b80a91e2ff4c.woff2", "Referer=https://www.amp.com.au/etc/designs/amp-au/clientlibs/clientlib-site.css", ENDITEM, 
		"Url=https://www.amp.com.au/etc/designs/amp-au/assets/2525a15d1fb3ce824a7aad5e07ba2513.ttf", "Referer=https://www.amp.com.au/etc/designs/amp-au/clientlibs/clientlib-site.css", ENDITEM, 
		"Url=https://www.amp.com.au/etc/designs/amp-au/assets/98c3ea22ad6bca213fa88175f7d9ffaf.woff2", "Referer=https://www.amp.com.au/etc/designs/amp-au/clientlibs/clientlib-site.css", ENDITEM, 
		"Url=https://www.amp.com.au/etc/designs/amp-au/assets/ce62fa71a1a38af297b433e85d36d83f.woff2", "Referer=https://www.amp.com.au/etc/designs/amp-au/clientlibs/clientlib-site.css", ENDITEM, 
		"Url=https://www.amp.com.au/etc/designs/amp-au/assets/33543c5cc5d88f5695dd08c87d280dfd.woff2", "Referer=https://www.amp.com.au/etc/designs/amp-au/clientlibs/clientlib-site.css", ENDITEM, 
		"Url=https://ad.doubleclick.net/ddm/adj/N962361.197812NSO.CODESRV/B22590592.244647881;sz=1x2;ord=678481876450?", "Referer=https://www.amp.com.au/", ENDITEM, 
		"Url=https://connect.facebook.net/en_US/fbevents.js", "Referer=https://www.amp.com.au/", ENDITEM, 
		"Url=https://www.amp.com.au/etc/designs/amp-au/assets/5c32de29c638fdf3bb4adc662a0ad595.woff2", "Referer=https://www.amp.com.au/etc/designs/amp-au/clientlibs/clientlib-site.css", ENDITEM, 
		"Url=https://www.amp.com.au/etc/designs/amp/assets/fonts/xtreme.woff", "Referer=https://www.amp.com.au/etc/designs/amp/clientLibraries/icons-libs.css", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_custom_request("id", 
		"URL=https://dpm.demdex.net/id?d_visid_ver=4.5.2&d_fieldgroup=MC&d_rtbd=json&d_ver=2&d_orgid=11BA6EA55322342B0A490D44%40AdobeOrg&d_nsid=0&ts=1624946678691", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded", 
		LAST);

	web_revert_auto_header("Origin");

	web_custom_request("delivery", 
		"URL=https://ampserviceslimited.tt.omtrdc.net/rest/v1/delivery?client=ampserviceslimited&sessionId=3cc95b43f68748bfb93d005ba6dcfa05&version=2.3.2", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body={\"requestId\":\"44a390690ace4b908200b796f2566a19\",\"context\":{\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36\",\"timeOffsetInMinutes\":600,\"channel\":\"web\",\"screen\":{\"width\":1500,\"height\":1000,\"orientation\":\"landscape\",\"colorDepth\":24,\"pixelRatio\":1},\"window\":{\"width\":1500,\"height\":857},\"browser\":{\"host\":\"www.amp.com.au\",\"webGLRenderer\":\"Google SwiftShader\"},\"address\":{\""
		"url\":\"https://www.amp.com.au/\",\"referringUrl\":\"\"}},\"id\":{\"marketingCloudVisitorId\":\"23569144125047983874531016401195797023\"},\"experienceCloud\":{\"audienceManager\":{\"locationHint\":8,\"blob\":\"6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y\"},\"analytics\":{\"logging\":\"server_side\",\"supplementalDataId\":\"0E7133F4CD282E06-7CE241CAF03B1E5F\",\"trackingServer\":\"amp.d2.sc.omtrdc.net\",\"trackingServerSecure\":\"amp.d2.sc.omtrdc.net\"}},\"execute\":{\"pageLoad\":{\""
		"profileParameters\":{\"pageName\":\"home\"}}},\"prefetch\":{\"views\":[{\"profileParameters\":{\"pageName\":\"home\"}}]}}", 
		LAST);

	web_reg_find("Text=Adobe AudienceManager", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"iframe");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("dest5.html", 
		"URL=https://ampserviceslimited.demdex.net/dest5.html?d_nsid=0", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_url("api.ipdata.co", 
		"URL=https://api.ipdata.co/?api-key=1a31485dfcd75b472742d9f7e224d7057a5d9ba6ce95eee1ee785c30", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_custom_request("rb_bf96747ztk", 
		"URL=https://www.amp.com.au/rb_bf96747ztk?app=cd4697ba1bc4a478;crc=1993901525;end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a="
		"1%7C1%7C_load_%7C_load_%7C-%7C1624946665667%7C0%7Cdn%7C-1%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%2C2%7C7%7C_event_%7C1624946665667%7C_vc_%7CV%7C-1%5Epf%7CVCD%7C141%7CVCDS%7C5%7CVCS%7C16784%7CVCO%7C16784%7CVCI%7C0%7CS%7C-1%2C2%7C8%7C_event_%7C1624946665667%7C_wv_%7Ccls%7C0%7Clt%7C1029%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C2%7C2%7Cx%7Cxhr%7Cx%7C1624946678693%7C0%7Cdn%7C27%7Cxu%7Chttps%3A%2F%2Fdpm.demdex.net%2Fid%3Fd_visid_ver%3D4.5.2%26d_fieldgroup%3DMC%26d_rtbd%3Djson%26d_ver%3D2%26d_orgid%3D11BA6EA5532"
		"2342B0A490D44%2540AdobeOrg%26d_nsid%3D0%26ts%3D1624946678691%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946678697e0m1214T-1z11I1%7Cxcs%7C1224%7Cxce%7C1253%2C3%7C3%7Cx%7Cxhr%7Cx%7C1624946679924%7C0%7Cdn%7C-1%7Cxu%7Chttps%3A%2F%2Famp.d2.sc.omtrdc.net%2Fid%3Fd_visid_ver%3D4.5.2%26d_fieldgroup%3DA%26mcorgid%3D11BA6EA55322342B0A490D44%2540AdobeOrg%26mid%3D23569144125047983874531016401195797023%26ts%3D1624946679923%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Cxcs%7C902%7C"
		"xce%7C971%2C2%7C4%7Cx%7Cxhr%7Cx%7C1624946679958%7C0%7Cdn%7C-1%7Cxu%7Chttps%3A%2F%2Fampserviceslimited.tt.omtrdc.net%2Frest%2Fv1%2Fdelivery%3Fclient%3Dampserviceslimited%26sessionId%3D3cc95b43f68748bfb93d005ba6dcfa05%26version%3D2.3.2%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Cxcs%7C953%7Cxce%7C953%2C2%7C5%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946680655%7C0%7Cdn%7C-1%7Cxu%7C%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Flegacy-nps.js%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%2C2%7C6%7Cx%7Cxhr%7Cx%7C1624946681236%7C"
		"0%7Cdn%7C-1%7Cxu%7Chttps%3A%2F%2Fapi.ipdata.co%2F%3Fapi-key%3D1a31485dfcd75b472742d9f7e224d7057a5d9ba6ce95eee1ee785c30%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Cxcs%7C1211%7Cxce%7C1211%2C1%7C9%7C_event_%7C1624946665667%7C_view_%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0$svrid=-54$rId=RID_2418$rpId=-1677640186$unload=xhr$tvn=%2F$tvt=1624946665667$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1500$h=857$sw=1500$sh=1000$nt=a0b1624946665667e2281f2281g2281h2305i11945j3346k11945l12098m12122u20688v19796w158152M-1677640186$ni=4g|3.65$di"
		"=1$fd=j1.12.4$url=https%3A%2F%2Fwww.amp.com.au%2F$title=AMP%20%E2%80%93%20Banking%2C%20Super%2C%20Retirement%2C%20Financial%20Advice%20%26%20Insurance%20-%20AMP$isUnload=1$latC=5972$app=cd4697ba1bc4a478$visitID=KGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0$vs=2$fId=146678395_135$v=10217210531114014$vID=16249466784450Q0MQIFVSELV6Q8T30TVRP9L9CP81NSQ$nV=1$nVAT=1$time=1624946682619", 
		LAST);

	web_revert_auto_header("Origin");

	web_reg_find("Text=AMP �\x80� Banking, Super, Retirement, Financial Advice &amp; Insurance - AMP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("www.amp.com.au_2", 
		"URL=https://www.amp.com.au/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/content/dam/amp-au/illustrations/Banking.svg", ENDITEM, 
		"Url=/content/dam/amp-au/illustrations/Super.svg", ENDITEM, 
		"Url=https://assets.adobedtm.com/extensions/EPbde2f7ca14e540399dcc1f8208860b7b/AppMeasurement.min.js", ENDITEM, 
		"Url=https://ad.doubleclick.net/ddm/adj/N962361.197812NSO.CODESRV/B22590592.244647881;sz=1x2;ord=448111192613?", ENDITEM, 
		"Url=/etc/designs/amp-au/clientlibs/legacy-nps.js?_=1624946682984", ENDITEM, 
		"Url=https://bat.bing.com/p/action/16012365.js", ENDITEM, 
		"Url=https://www.gstatic.com/recaptcha/releases/eKRIyK-9MtX6JxeZcNZIkfUq/recaptcha__en.js", ENDITEM, 
		"Url=https://assets.adobedtm.com/30cb14f656a0/7a08285d48a4/29c0db022c3d/RC3780d39ec03d45df99c03f86ac0bab9c-source.min.js", ENDITEM, 
		"Url=https://assets.adobedtm.com/30cb14f656a0/7a08285d48a4/29c0db022c3d/RC15a5c6f5e8cb4510b7d70763e430d359-source.min.js", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s83231038142202?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A4%3A44%202%20-600&sdid=165F3B609EE21AF0-2E87747AEA3745C6&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=home&g=https%3A%2F%2Fwww.amp.com.au%2F&r=https%3A%2F%2Fwww.amp.com.au%2F&cc=AUD&ch=amp&events=event75%3D12&aamb=6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y&c1=web&v1=D%3Dc1&h1=home&c2=home&v2=D%3Dc2&c3=home&v3="
		"D%3Dc3&v6=false&v7=home&c12=1624946683773&v12=4%3A04PM%7C4%3A00PM%7CTuesday%7C29%2F6%2F2021&c16=https%3A%2F%2Fwww.amp.com.au%2F&v16=D%3Dc16&c30=23569144125047983874531016401195797023&v30=D%3Dc30&c74=AMP%20PUBLIC%20SITE%20Launch&c75=12&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&AQE=1", ENDITEM, 
		"Url=https://yourir.info/lib/1.11.6/yourir.js", ENDITEM, 
		"Url=/content/dam/amp-au/illustrations/Tell-your-employer.svg", ENDITEM, 
		"Url=https://yourir.info/lib/1.11.6/yourir.css", ENDITEM, 
		"Url=https://connect.facebook.net/signals/config/131169910928083?v=2.9.42&r=stable", ENDITEM, 
		"Url=https://api.ipify.org/?format=jsonp&callback=?", ENDITEM, 
		"Url=https://sp.analytics.yahoo.com/sp.pl?a=10000&d=Tue%2C%2029%20Jun%202021%2006%3A04%3A43%20GMT&n=-10&b=AMP%20%E2%80%93%20Banking%2C%20Super%2C%20Retirement%2C%20Financial%20Advice%20%26%20Insurance%20-%20AMP&.yp=10092149&f=https%3A%2F%2Fwww.amp.com.au%2F&e=https%3A%2F%2Fwww.amp.com.au%2F&enc=UTF-8&yv=1.10.1&tagmgr=adobe", ENDITEM, 
		"Url=https://pagead2.googlesyndication.com/pagead/js/r20210624/r20110914/elements/html/omrhp.js", ENDITEM, 
		"Url=https://cdn.taboola.com/libtrc/unip/1236555/tfa.js", ENDITEM, 
		"Url=https://www.googletagservices.com/activeview/js/current/rx_lidar.js?cache=r20110914", ENDITEM, 
		"Url=https://www.googletagmanager.com/gtag/js?id=DC-8836193", ENDITEM, 
		"Url=https://www.facebook.com/tr/?id=131169910928083&ev=ViewContent&dl=https%3A%2F%2Fwww.amp.com.au%2F&rl=https%3A%2F%2Fwww.amp.com.au%2F&if=false&ts=1624946684864&sw=1500&sh=1000&v=2.9.42&r=stable&ec=1&o=28&fbp=fb.2.1624946684859.99642261&it=1624946684430&coo=false&rqm=GET", ENDITEM, 
		"Url=https://www.facebook.com/tr/?id=131169910928083&ev=PageView&dl=https%3A%2F%2Fwww.amp.com.au%2F&rl=https%3A%2F%2Fwww.amp.com.au%2F&if=false&ts=1624946684861&sw=1500&sh=1000&v=2.9.42&r=stable&ec=0&o=28&fbp=fb.2.1624946684859.99642261&it=1624946684430&coo=false&rqm=GET", ENDITEM, 
		"Url=https://www.googletagmanager.com/gtag/js?id=AW-751278354&l=dataLayer&cx=c", ENDITEM, 
		"Url=https://www.googletagmanager.com/gtag/js?id=AW-684022622&l=dataLayer&cx=c", ENDITEM, 
		"Url=https://trc.taboola.com/1236555/trc/3/json?tim=1624946688038&data="
		"%7B%22id%22%3A294%2C%22ii%22%3A%22%2F%22%2C%22it%22%3A%22video%22%2C%22sd%22%3Anull%2C%22ui%22%3Anull%2C%22vi%22%3A1624946688011%2C%22cv%22%3A%2220210615-3-RELEASE%22%2C%22uiv%22%3A%22default%22%2C%22u%22%3A%22https%3A%2F%2Fwww.amp.com.au%2F%22%2C%22e%22%3A%22https%3A%2F%2Fwww.amp.com.au%2F%22%2C%22cb%22%3A%22TFASC.trkCallback%22%2C%22qs%22%3A%22%22%2C%22r%22%3A%5B%7B%22li%22%3A%22rbox-tracking%22%2C%22s%22%3A0%2C%22uim%22%3A%22rbox-tracking%3Apub%3Dreprisemelb-amp-au-sc%3Aabp%3D0%22%2C%22uip%22%3"
		"A%22rbox-tracking%22%2C%22orig_uip%22%3A%22rbox-tracking%22%7D%5D%2C%22mpv%22%3Atrue%2C%22mpvd%22%3A%7B%22en%22%3A%22page_view%22%2C%22item-url%22%3A%22https%3A%2F%2Fwww.amp.com.au%2F%22%2C%22tim%22%3A1624946688035%2C%22ref%22%3A%22https%3A%2F%2Fwww.amp.com.au%2F%22%2C%22tos%22%3A4%2C%22ssd%22%3A1%2C%22scd%22%3A16%7D%7D&pubit=i", ENDITEM, 
		"Url=https://www.googletagmanager.com/gtag/js?id=AW-711997817&l=dataLayer&cx=c", ENDITEM, 
		"Url=https://www.googleadservices.com/pagead/conversion_async.js", ENDITEM, 
		"Url=https://trc.taboola.com/1236555/log/3/unip?en=page_view&item-url=https%3A%2F%2Fwww.amp.com.au%2F&tim=1624946688035&ref=https%3A%2F%2Fwww.amp.com.au%2F&cv=20210615-3-RELEASE&tos=2019&ssd=1&scd=16&mrir=to&vi=1624946688011", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/711997817/?random=1624946690396&cv=9&fst=1624946690396&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=1&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2F&ref=https%3A%2F%2Fwww.amp.com.au%2F&tiba="
		"AMP%20%E2%80%93%20Banking%2C%20Super%2C%20Retirement%2C%20Financial%20Advice%20%26%20Insurance%20-%20AMP&hn=www.googleadservices.com&async=1&rfmt=3&fmt=4", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/684022622/?random=1624946690401&cv=9&fst=1624946690401&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=2505059651&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=1&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2F&ref=https%3A%2F%2Fwww.amp.com.au%2F&tiba="
		"AMP%20%E2%80%93%20Banking%2C%20Super%2C%20Retirement%2C%20Financial%20Advice%20%26%20Insurance%20-%20AMP&hn=www.googleadservices.com&async=1&rfmt=3&fmt=4", ENDITEM, 
		"Url=https://www.google.com/pagead/1p-user-list/711997817/?random=1624946690396&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=1&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2F&ref=https%3A%2F%2Fwww.amp.com.au%2F&tiba=AMP%20%E2%80%93%20Banking%2C%20Super%2C%20Retirement%2C%20Financial%20Advice%20%26%20Insurance%20-%20AMP&async=1&fmt=3&is_vtc=1&random="
		"653161531&resp=GooglemKTybQhCsO&rmt_tld=0&ipr=y", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/751278354/?random=1624946690404&cv=9&fst=1624946690404&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=2505059651&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=1&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2F&ref=https%3A%2F%2Fwww.amp.com.au%2F&tiba="
		"AMP%20%E2%80%93%20Banking%2C%20Super%2C%20Retirement%2C%20Financial%20Advice%20%26%20Insurance%20-%20AMP&hn=www.googleadservices.com&async=1&rfmt=3&fmt=4", ENDITEM, 
		"Url=https://www.google.com/pagead/1p-user-list/684022622/?random=1624946690401&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=2505059651&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=1&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2F&ref=https%3A%2F%2Fwww.amp.com.au%2F&tiba=AMP%20%E2%80%93%20Banking%2C%20Super%2C%20Retirement%2C%20Financial%20Advice%20%26%20Insurance%20-%20AMP&async=1&fmt=3&is_vtc=1&random="
		"2522463738&resp=GooglemKTybQhCsO&rmt_tld=0&ipr=y", ENDITEM, 
		"Url=https://www.google.com/pagead/1p-user-list/751278354/?random=1624946690404&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=2505059651&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=1&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2F&ref=https%3A%2F%2Fwww.amp.com.au%2F&tiba=AMP%20%E2%80%93%20Banking%2C%20Super%2C%20Retirement%2C%20Financial%20Advice%20%26%20Insurance%20-%20AMP&async=1&fmt=3&is_vtc=1&random="
		"221394015&resp=GooglemKTybQhCsO&rmt_tld=0&ipr=y", ENDITEM, 
		"Url=https://trc-events.taboola.com/1236555/log/3/unip?en=pre_d_eng_tb&tos=2838&scd=16&ssd=1&est=1624946688030&ver=32&isls=true&src=i&invt=1500&tim=1624946690870&mrir=tto&vi=1624946688011&ref=https%3A%2F%2Fwww.amp.com.au%2F&cv=20210615-3-RELEASE&item-url=https%3A%2F%2Fwww.amp.com.au%2F", ENDITEM, 
		"Url=/content/dam/amp-au/authoring/icons/favicon.ico", ENDITEM, 
		"Url=https://trc-events.taboola.com/1236555/log/3/unip?en=pre_d_eng_tb&tos=6403&scd=16&ssd=1&est=1624946688030&ver=32&isls=true&src=i&invt=3000&tim=1624946694435&mrir=tto&vi=1624946688011&ref=https%3A%2F%2Fwww.amp.com.au%2F&cv=20210615-3-RELEASE&item-url=https%3A%2F%2Fwww.amp.com.au%2F", ENDITEM, 
		"Url=https://www.sc.pages03.net/lp/static/js/iMAWebCookie.js?18560ebc-14a40f8eab9-943e27de0c8b91cc3fcf1475c3e5d726&h=www.pages03.net", ENDITEM, 
		"Url=https://www.pages03.net/WTS/event.jpeg?accesskey=18560ebc-14a40f8eab9-943e27de0c8b91cc3fcf1475c3e5d726&v=1.31&isNewSession=1&type=pageview&isNewVisitor=1&sessionGUID=bb945113-85bc-a875-4ddc-6479ec5c1c79&webSyncID=ac130211-93c1-63b2-1ca5-a0d58d000ac2&url=https%3A%2F%2Fwww.amp.com.au%2F&newSiteVisit=1&referringURL=https%3A%2F%2Fwww.amp.com.au%2F&hostname=www.amp.com.au&pathname=%2F&newPageVisit=1&eventKey=1b893601-1d52-0ac5-6c7c-8ac2013a9b7e", ENDITEM, 
		"Url=https://trc-events.taboola.com/1236555/log/3/unip?en=pre_d_eng_tb&tos=12417&scd=16&ssd=1&est=1624946688030&ver=32&isls=true&src=i&invt=6000&tim=1624946700449&mrir=tto&vi=1624946688011&ref=https%3A%2F%2Fwww.amp.com.au%2F&cv=20210615-3-RELEASE&item-url=https%3A%2F%2Fwww.amp.com.au%2F", ENDITEM, 
		"Url=https://trc-events.taboola.com/1236555/log/3/unip?en=pre_d_eng_tb&tos=24434&scd=16&ssd=1&est=1624946688030&ver=32&isls=true&src=i&invt=12000&tim=1624946712466&mrir=tto&vi=1624946688011&ref=https%3A%2F%2Fwww.amp.com.au%2F&cv=20210615-3-RELEASE&item-url=https%3A%2F%2Fwww.amp.com.au%2F", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s81880465461046?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A5%3A15%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=home&g=https%3A%2F%2Fwww.amp.com.au%2F&cc=AUD&events=event38&c4=main%20nav%3ABanking&v4=D%3Dc4&pe=lnk_o&pev2=main%20nav%3ABanking&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=265&AQE=1", ENDITEM, 
		LAST);

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_custom_request("delivery_2", 
		"URL=https://ampserviceslimited.tt.omtrdc.net/rest/v1/delivery?client=ampserviceslimited&sessionId=3cc95b43f68748bfb93d005ba6dcfa05&version=2.3.2", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body={\"requestId\":\"eb0af2e5a57e42b2a051a38c53bd6022\",\"context\":{\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36\",\"timeOffsetInMinutes\":600,\"channel\":\"web\",\"screen\":{\"width\":1500,\"height\":1000,\"orientation\":\"landscape\",\"colorDepth\":24,\"pixelRatio\":1},\"window\":{\"width\":1500,\"height\":857},\"browser\":{\"host\":\"www.amp.com.au\",\"webGLRenderer\":\"Google SwiftShader\"},\"address\":{\""
		"url\":\"https://www.amp.com.au/\",\"referringUrl\":\"https://www.amp.com.au/\"}},\"id\":{\"tntId\":\"3cc95b43f68748bfb93d005ba6dcfa05.36_0\",\"marketingCloudVisitorId\":\"23569144125047983874531016401195797023\"},\"experienceCloud\":{\"audienceManager\":{\"locationHint\":8,\"blob\":\"6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y\"},\"analytics\":{\"logging\":\"server_side\",\"supplementalDataId\":\"165F3B609EE21AF0-2E87747AEA3745C6\",\"trackingServer\":\"amp.d2.sc.omtrdc.net\",\""
		"trackingServerSecure\":\"amp.d2.sc.omtrdc.net\"}},\"execute\":{\"pageLoad\":{\"profileParameters\":{\"pageName\":\"home\"}}},\"prefetch\":{\"views\":[{\"profileParameters\":{\"pageName\":\"home\"}}]}}", 
		LAST);

	web_url("10092149.json", 
		"URL=https://s.yimg.com/wi/config/10092149.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_submit_data("register3", 
		"Action=https://android.clients.google.com/c2dm/register3", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=app", "Value=com.chrome.windows", ENDITEM, 
		"Name=X-subtype", "Value=com.google.chrome.fcm.invalidations", ENDITEM, 
		"Name=device", "Value=4880919089772198241", ENDITEM, 
		"Name=scope", "Value=GCM", ENDITEM, 
		"Name=X-scope", "Value=GCM", ENDITEM, 
		"Name=gmsv", "Value=91", ENDITEM, 
		"Name=appid", "Value=eb7xSDpQ_x0", ENDITEM, 
		"Name=sender", "Value=8181035976", ENDITEM, 
		"Name=ttl", "Value=1209600", ENDITEM, 
		LAST);

	web_submit_data("register3_2", 
		"Action=https://android.clients.google.com/c2dm/register3", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=app", "Value=com.chrome.windows", ENDITEM, 
		"Name=X-subtype", "Value=com.google.chrome.fcm.invalidations-1013309121859", ENDITEM, 
		"Name=device", "Value=4880919089772198241", ENDITEM, 
		"Name=scope", "Value=GCM", ENDITEM, 
		"Name=X-scope", "Value=GCM", ENDITEM, 
		"Name=gmsv", "Value=91", ENDITEM, 
		"Name=appid", "Value=f6wO-f1vGQ0", ENDITEM, 
		"Name=sender", "Value=1013309121859", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("x-dtpc", 
		"-54$146682855_874h6vKGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0e2");

	web_url("NetPromoterScore", 
		"URL=https://www.amp.com.au/wps/gws/NetPromoterScore?pageId=amp%3A", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_url("0", 
		"URL=https://bat.bing.com/action/0?ti=16012365&Ver=2&mid=ecbf8a36-37a6-4942-9970-c20cf0f63b83&sid=e6578fe0d89f11eb98165deac4f355a8&vid=e657ca70d89f11eb8fe68f742e2032a1&vids=1&pi=1200101525&lg=en-GB&sw=1500&sh=1000&sc=24&tl=AMP%20%E2%80%93%20Banking,%20Super,%20Retirement,%20Financial%20Advice%20%26%20Insurance%20-%20AMP&p=https%3A%2F%2Fwww.amp.com.au%2F&r=https%3A%2F%2Fwww.amp.com.au%2F&lt=1415&evt=pageLoad&msclkid=N&sv=1&rn=260742", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("X-Goog-Update-AppId", 
		"aapocclcgogkmnckokdopfmhonfmgoek,aohghmighlieiainnegkcijnfilokake,apdfllckaahabafndbhieahigkjlhalf,blpcfgokakmgnkcojhhkbfbldkacnbeo,felcaaldnbdncclmgdcncolpebgiejap,ghbmnnjooekpmoecnnnilnnbdlolhkhi,nmmhkkegccagdldgiimedpiccmgmieda,pjkljhegncpnkpknbcohdijeoejaedia,pkedcjkdefgpdelpbcmbmeomcjbeemfm");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chromecrx-91.0.4472.114");

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=10:137066109&cup2hreq=b56d4d1b46454fc8b4862e223d5316670a5a306af391014cb090c48afbe9eea9", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chromecrx\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"aapocclcgogkmnckokdopfmhonfmgoek\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"2.0.10\"}]},\"ping\":{\"ping_freshness\":\"{d22c7f6f-fea1-456c-bec1-3dd15cb240cf}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"0.10\"},{\"appid\":\"aohghmighlieiainnegkcijnfilokake\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\""
		"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"2.0.10\"}]},\"ping\":{\"ping_freshness\":\"{5aa9010c-79b8-41fb-931d-23cc2a5c5d8c}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"0.10\"},{\"appid\":\"apdfllckaahabafndbhieahigkjlhalf\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"2.14.5\"}]},\"ping\":{\"ping_freshness\":\"{9ea955ec-ad32-4042-a81b-fded05ae77c1}\",\"rd\":5292},\"updatecheck\":{"
		"},\"version\":\"14.5\"},{\"appid\":\"blpcfgokakmgnkcojhhkbfbldkacnbeo\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"2.4.2.8\"}]},\"ping\":{\"ping_freshness\":\"{3b41ec48-456f-488f-a6e8-ee3dadae5879}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"4.2.8\"},{\"appid\":\"felcaaldnbdncclmgdcncolpebgiejap\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\""
		"2.1.2\"}]},\"ping\":{\"ping_freshness\":\"{e2e67f6a-fe14-466a-8667-73f82c159478}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"1.2\"},{\"appid\":\"ghbmnnjooekpmoecnnnilnnbdlolhkhi\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"external\",\"packages\":{\"package\":[{\"fp\":\"1.d116fa8d8ee309f01340fb6f3d2ad314a7b7c8bdf22dd9b6af4c22b1a6923461\"}]},\"ping\":{\"ping_freshness\":\"{ad47d325-b877-4a3e-bb17-b287d0a04033}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"1.31.0"
		"\"},{\"appid\":\"nmmhkkegccagdldgiimedpiccmgmieda\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"other\",\"packages\":{\"package\":[{\"fp\":\"2.1.0.0.6\"}]},\"ping\":{\"ping_freshness\":\"{439b4326-b727-4737-aaea-efb1a491d921}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"1.0.0.6\"},{\"appid\":\"pjkljhegncpnkpknbcohdijeoejaedia\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"2.8.3\"}]},\"ping\""
		":{\"ping_freshness\":\"{882d31e8-b0fa-4e4b-9de8-2c7ffcfb1862}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"8.3\"},{\"appid\":\"pkedcjkdefgpdelpbcmbmeomcjbeemfm\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"other\",\"packages\":{\"package\":[{\"fp\":\"1.3bba8f43f392ecbc35b582986edcbf7c6591081b63f3f0214f8eed1d239b0f60\"}]},\"ping\":{\"ping_freshness\":\"{11d400ab-9dfb-40c5-abce-dfb1ec8c6960}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"9121.329.0.0\"}],\"arch\":\""
		"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"physmemory\":8},\"lang\":\"en-GB\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.18363.1500\"},\"prodversion\":\"91.0.4472.114\",\"protocol\":\"3.1\",\"requestid\":\"{cafa7d7e-81f3-4b51-b62a-c37c34927ab9}\",\"sessionid\":\"{a758a0cb-6e48-4595-b56c-bb8d053436ed}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\""
		"updatepolicy\":-1,\"version\":\"1.3.36.82\"},\"updaterversion\":\"91.0.4472.114\"}}", 
		LAST);

	web_reg_find("Text=reCAPTCHA", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"iframe");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_url("anchor", 
		"URL=https://www.google.com/recaptcha/api2/anchor?ar=1&k=6Lf1YKQUAAAAAK3RIImnFOQrks8gZnrC7pObqn5q&co=aHR0cHM6Ly93d3cuYW1wLmNvbS5hdTo0NDM.&hl=en&v=eKRIyK-9MtX6JxeZcNZIkfUq&size=invisible&cb=p9rmtrk5esvz", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_url("amp.asx", 
		"URL=https://yourir.info/api/v5/symbols/amp.asx?appID=61b218eca79bef95&liveness=delayed", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_url("amp.nzx", 
		"URL=https://yourir.info/api/v5/symbols/amp.nzx?appID=61b218eca79bef95&liveness=delayed", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://fonts.gstatic.com/s/opensans/v20/mem8YaGs126MiZpBA-UFVZ0b.woff2", "Referer=https://fonts.googleapis.com/", ENDITEM, 
		"Url=https://fonts.gstatic.com/s/opensans/v20/mem5YaGs126MiZpBA-UNirkOUuhp.woff2", "Referer=https://fonts.googleapis.com/", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_custom_request("view", 
		"URL=https://googleads4.g.doubleclick.net/pcs/view?xai=AKAOjss34czeH6WWo3rMheE_OcYKBwBc1shYh7skOIv7DO9_ayY1ZoqRMVl4L49sQfwpOVYhla6mQTIupLpI9E5Ofjd9e7izHmU8RQ8cxdDm50VKqfSISJbKfo-HmXJZFT3l&sig=Cg0ArKJSzA7Ba5pfM_kGEAE&fbs_aeid=[gw_fbsaeid]&urlfix=1&omid=0&rm=1&ctpt=1&cbvp=1&cisv=r20210624.77897&adurl=", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t23.inf", 
		"EncType=text/plain;charset=UTF-8", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_url("versions", 
		"URL=https://yourir.info/api/v5/versions?appID=61b218eca79bef95&libVersion=1.11.6&st=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.gstatic.com/recaptcha/api2/logo_48.png", "Referer=https://www.gstatic.com/recaptcha/releases/eKRIyK-9MtX6JxeZcNZIkfUq/styles__ltr.css", ENDITEM, 
		"Url=https://fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu4mxK.woff2", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmEU9fBBc4.woff2", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://www.google.com/recaptcha/api2/webworker.js?hl=en&v=eKRIyK-9MtX6JxeZcNZIkfUq", "Referer=https://www.google.com/recaptcha/api2/anchor?ar=1&k=6Lf1YKQUAAAAAK3RIImnFOQrks8gZnrC7pObqn5q&co=aHR0cHM6Ly93d3cuYW1wLmNvbS5hdTo0NDM.&hl=en&v=eKRIyK-9MtX6JxeZcNZIkfUq&size=invisible&cb=p9rmtrk5esvz", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_custom_request("rb_bf96747ztk_2", 
		"URL=https://www.amp.com.au/rb_bf96747ztk?app=cd4697ba1bc4a478;crc=1019978113;end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a="
		"1%7C1%7C_load_%7C_load_%7C-%7C1624946682624%7C0%7Cdn%7C-1%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Clr%7Chttps%3A%2F%2Fwww.amp.com.au%2F%2C2%7C2%7Cx%7Cxhr%7Cx%7C1624946682935%7C1624946683286%7Cdn%7C1191%7Cxu%7Chttps%3A%2F%2Fampserviceslimited.tt.omtrdc.net%2Frest%2Fv1%2Fdelivery%3Fclient%3Dampserviceslimited%26sessionId%3D3cc95b43f68748bfb93d005ba6dcfa05%26version%3D2.3.2%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946682940e0m160T-1z11I1%7Cxcs%7C350%7Cxce%7C350%2"
		"C2%7C3%7Cx%7Cxhr%7Cx%7C1624946683028%7C1624946683704%7Cdn%7C1184%7Cxu%7Chttps%3A%2F%2Fs.yimg.com%2Fwi%2Fconfig%2F10092149.json%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946683030e0m70T-2z11I1%7Cxcs%7C532%7Cxce%7C675%2C2%7C4%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946683187%7C1624946684214%7Cdn%7C1197%7Cxu%7C%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Flegacy-nps.js%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946683193e0f0g"
		"0h0i0j0k5l125m128u10622v9770w50111T-4z11I1M-1305959488%7Cxcs%7C906%7Cxce%7C933%2C3%7C6%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946684101%7C1624946684214%7Cdn%7C1197%7Cxu%7C%2Fwps%2Fgws%2FNetPromoterScore%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946684115e0f0g0h0i0j0k28l76m76u1144v19w19T-3z11I1M1946190603%7Cxcs%7C113%7Cxce%7C113%2C2%7C5%7Cx%7Cxhr%7Cx%7C1624946683385%7C1624946686238%7Cdn%7C1189%7Cxu%7Chttps%3A%2F%2Fapi.ipify.org%2F%3Fformat%3Djsonp%26callbac"
		"k%3D%3F%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946683389e0m1556T-5z11I1%7Cxcs%7C2837%7Cxce%7C2853%2C2%7C7%7Cx%7Cxhr%7Cx%7C1624946684839%7C1624946686253%7Cdn%7C1205%7Cxu%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.asx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946684842e0m1378T-6z11I1%7Cxcs%7C1410%7Cxce%7C1414%2C2%7C8%7Cx%7Cxhr%7Cx%7C1624946684842%7C16249466"
		"86270%7Cdn%7C1205%7Cxu%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.nzx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946684845e0m1394T-7z11I1%7Cxcs%7C1425%7Cxce%7C1428%2C2%7C9%7Cx%7Cxhr%7Cx%7C1624946687273%7C1624946688057%7Cdn%7C1206%7Cxu%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fversions%3FappID%3D61b218eca79bef95%26libVersion%3D1.11.6%26st%3D1%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5"
		"Esk0%5Esh0%7Cxrt%7Cb1624946687929e0m45T-8z11I1%7Cxcs%7C783%7Cxce%7C784%2C2%7C10%7Cx%7Cxhr%7Cx%7C1624946690052%7C1624946690369%7Cdn%7C1212%7Cxu%7Chttps%3A%2F%2Ftrc.taboola.com%2F1236555%2Flog%2F3%2Funip%3Fen%3Dpage_view%26item-url%3Dhttps%253A%252F%252Fwww.amp.com.au%252F%26tim%3D1624946688035%26ref%3Dhttps%253A%252F%252Fwww.amp.com.au%252F%26cv%3D20210615-3-RELEASE%26tos%3D2019%26ssd%3D1%26scd%3D16%26mrir%3Dto%26vi%3D1624946688011%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Es"
		"h0%7Cxrt%7Cb1624946690193e0m170T-9z11I1%7Cxcs%7C317%7Cxce%7C317%7Crc%7C204%7Crm%7CNo%20Content%2C2%7C11%7Cx%7Cxhr%7Cx%7C1624946690870%7C0%7Cdn%7C-1%7Cxu%7Chttps%3A%2F%2Ftrc-events.taboola.com%2F1236555%2Flog%2F3%2Funip%3Fen%3Dpre_d_eng_tb%26tos%3D2838%26scd%3D16%26ssd%3D1%26est%3D1624946688030%26ver%3D32%26isls%3Dtrue%26src%3Di%26invt%3D1500%26tim%3D1624946690870%26mrir%3Dtto%26vi%3D1624946688011%26ref%3Dhttps%253A%252F%252Fwww.amp.com.au%252F%26cv%3D20210615-3-RELEASE%26item-url%3Dhttps%253A%252F"
		"%252Fwww.amp.com.au%252F%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0$svrid=7$PV=1$rId=RID_2418$rpId=-1677640186$url=https%3A%2F%2Fwww.amp.com.au%2F$title=AMP%20%E2%80%93%20Banking%2C%20Super%2C%20Retirement%2C%20Financial%20Advice%20%26%20Insurance%20-%20AMP$latC=5$app=cd4697ba1bc4a478$visitID=KGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0$vs=2$fId=146682855_874$v=10217210531114014$time=1624946694429", 
		LAST);

	web_custom_request("rb_bf96747ztk_3", 
		"URL=https://www.amp.com.au/rb_bf96747ztk?app=cd4697ba1bc4a478;crc=832437276;end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a="
		"s%7C6%7Cx%7Cxhr%7Cx%7C146678395_135%7C1624946681236%7C%7C%2F%7C1624946665667%2C1%7C1%7C_load_%7C_load_%7C-%7C1624946682624%7C1624946694977%7Cdn%7C1216%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Clr%7Chttps%3A%2F%2Fwww.amp.com.au%2F%2C2%7C14%7C_event_%7C1624946682624%7C_vc_%7CV%7C1518%5Epc%7CVCD%7C3046%7CVCDS%7C7%7CVCS%7C12406%7CVCO%7C14213%7CVCI%7C0%7CVE%7C134%5Ep759%5Ep1296%5Eps%5Esdiv.media-block.image-template.cookie-ill%3Eimg.image-template%3Afirst-child%7CS%7C415%2"
		"C2%7C15%7C_event_%7C1624946682624%7C_wv_%7ClcpE%7CIMG%7ClcpSel%7C...ia-block.image-template%3Afirst-child%3Epicture.featured.resizable-image%3Afirst-child%3Eimg%3Anth-child...%7ClcpS%7C652520%7ClcpT%7C1621%7ClcpU%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fimages%2Fpage-banners%2Fhomepage-hero-AMPsaver-cataff-house-goals.jpg.ampaurendition.1920.0.jpg%7Cfcp%7C1621%7Cfp%7C1621%7Ccls%7C0%7Clt%7C4564%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C2%7C2%7Cx%7Cxhr%7Cx%7C1624946682935%7C1624946683286"
		"%7Cdn%7C1191%7Cxu%7Chttps%3A%2F%2Fampserviceslimited.tt.omtrdc.net%2Frest%2Fv1%2Fdelivery%3Fclient%3Dampserviceslimited%26sessionId%3D3cc95b43f68748bfb93d005ba6dcfa05%26version%3D2.3.2%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946682940e0m160T-10z1I1%7Cxcs%7C350%7Cxce%7C350%2C2%7C3%7Cx%7Cxhr%7Cx%7C1624946683028%7C1624946683704%7Cdn%7C1184%7Cxu%7Chttps%3A%2F%2Fs.yimg.com%2Fwi%2Fconfig%2F10092149.json%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%"
		"5Esk0%5Esh0%7Cxrt%7Cb1624946683030e0m70T-11z1I1%7Cxcs%7C532%7Cxce%7C675%2C2%7C4%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946683187%7C1624946684214%7Cdn%7C1197%7Cxu%7C%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Flegacy-nps.js%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946683193e0f0g0h0i0j0k5l125m128u10622v9770w50111T-13z1I1M-1305959488%7Cxcs%7C906%7Cxce%7C933%2C3%7C6%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946684101%7C1624946684214%7Cdn%7C1197%7Cxu%7C%2Fwps%2Fgws%"
		"2FNetPromoterScore%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946684115e0f0g0h0i0j0k28l76m76u1144v19w19T-12z1I1M1946190603%7Cxcs%7C113%7Cxce%7C113%2C2%7C5%7Cx%7Cxhr%7Cx%7C1624946683385%7C1624946686238%7Cdn%7C1189%7Cxu%7Chttps%3A%2F%2Fapi.ipify.org%2F%3Fformat%3Djsonp%26callback%3D%3F%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946683389e0m1556T-14z1I1%7Cxcs%7C2837%7Cxce%7C2853%2C2%7C7%7Cx%7Cxhr%7Cx%7C1624946684839%7C162"
		"4946686253%7Cdn%7C1205%7Cxu%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.asx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946684842e0m1378T-15z1I1%7Cxcs%7C1410%7Cxce%7C1414%2C2%7C8%7Cx%7Cxhr%7Cx%7C1624946684842%7C1624946686270%7Cdn%7C1205%7Cxu%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.nzx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7C"
		"i1%5Esk0%5Esh0%7Cxrt%7Cb1624946684845e0m1394T-16z1I1%7Cxcs%7C1425%7Cxce%7C1428%2C2%7C9%7Cx%7Cxhr%7Cx%7C1624946687273%7C1624946688057%7Cdn%7C1206%7Cxu%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fversions%3FappID%3D61b218eca79bef95%26libVersion%3D1.11.6%26st%3D1%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946687929e0m45T-17z1I1%7Cxcs%7C783%7Cxce%7C784%2C2%7C10%7Cx%7Cxhr%7Cx%7C1624946690052%7C1624946690369%7Cdn%7C1212%7Cxu%7Chttps%3A%2F%2Ftrc.taboola.com%2F1236555%"
		"2Flog%2F3%2Funip%3Fen%3Dpage_view%26item-url%3Dhttps%253A%252F%252Fwww.amp.com.au%252F%26tim%3D1624946688035%26ref%3Dhttps%253A%252F%252Fwww.amp.com.au%252F%26cv%3D20210615-3-RELEASE%26tos%3D2019%26ssd%3D1%26scd%3D16%26mrir%3Dto%26vi%3D1624946688011%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946690193e0m170T-18z1I1%7Cxcs%7C317%7Cxce%7C317%7Crc%7C204%7Crm%7CNo%20Content%2C2%7C11%7Cx%7Cxhr%7Cx%7C1624946690870%7C1624946694874%7Cdn%7C1216%7Cxu%7Chttps%3A%2F%2Ftr"
		"c-events.taboola.com%2F1236555%2Flog%2F3%2Funip%3Fen%3Dpre_d_eng_tb%26tos%3D2838%26scd%3D16%26ssd%3D1%26est%3D1624946688030%26ver%3D32%26isls%3Dtrue%26src%3Di%26invt%3D1500%26tim%3D1624946690870%26mrir%3Dtto%26vi%3D1624946688011%26ref%3Dhttps%253A%252F%252Fwww.amp.com.au%252F%26cv%3D20210615-3-RELEASE%26item-url%3Dhttps%253A%252F%252Fwww.amp.com.au%252F%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946690874e0m3992T-19z11I1%7Cxcs%7C4004%7Cxce%7C4004%7Crc%7C204%"
		"7Crm%7CNo%20Content%2C2%7C12%7Cx%7Cxhr%7Cx%7C1624946694436%7C1624946694977%7Cdn%7C1216%7Cxu%7Chttps%3A%2F%2Ftrc-events.taboola.com%2F1236555%2Flog%2F3%2Funip%3Fen%3Dpre_d_eng_tb%26tos%3D6403%26scd%3D16%26ssd%3D1%26est%3D1624946688030%26ver%3D32%26isls%3Dtrue%26src%3Di%26invt%3D3000%26tim%3D1624946694435%26mrir%3Dtto%26vi%3D1624946688011%26ref%3Dhttps%253A%252F%252Fwww.amp.com.au%252F%26cv%3D20210615-3-RELEASE%26item-url%3Dhttps%253A%252F%252Fwww.amp.com.au%252F%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7"
		"Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946694438e0m536T-20z11I1%7Cxcs%7C541%7Cxce%7C541%7Crc%7C204%7Crm%7CNo%20Content%2C2%7C13%7C_onload_%7C_load_%7C-%7C1624946694834%7C1624946694845%7Cdn%7C1216%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C1%7C16%7C_event_%7C1624946682624%7C_view_%7Csvn%7C%2F%7Csvt%7C1624946665667%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0$svrid=7$rId=RID_2418$rpId=-1677640186$domR=1624946694829$tvn=%2F$tvt="
		"1624946682624$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1500$h=857$sw=1500$sh=1000$nt=a1b1624946682624e2f2g2h2i2j2k9l35m44o1202p1202q1415r12205s12210t12221u20695v19796w158152M-1677640186$ni=4g|3.65$di=1$fd=j1.12.4^sb11-50$url=https%3A%2F%2Fwww.amp.com.au%2F$title=AMP%20%E2%80%93%20Banking%2C%20Super%2C%20Retirement%2C%20Financial%20Advice%20%26%20Insurance%20-%20AMP$latC=5$app=cd4697ba1bc4a478$visitID=KGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0$vs=2$fId=146682855_874$v=10217210531114014$vID="
		"16249466784450Q0MQIFVSELV6Q8T30TVRP9L9CP81NSQ$time=1624946698100", 
		LAST);

	web_custom_request("rb_bf96747ztk_4", 
		"URL=https://www.amp.com.au/rb_bf96747ztk?app=cd4697ba1bc4a478;crc=736000076;end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$svrid=7$tvn=%2F$tvt=1624946682624$tvm=i1%3Bk0%3Bh0$tvtrg=1$ni=4g|3.65$di=1$3p="
		"1-1624946682624%3Bassets.adobedtm.com%7C4%7C4%7C0%7C0%7C1%7C0%7C4%7C%7C0%7C0%7C0%7C222_222_264_287_1203_1379%7C64%7C0%7C167%3Bwww.amp.com.au%7Cu%7C20%7C0%7C0%7C14%7C0%7C20%7C%7C0%7C0%7C0%7C225_225_401_401_414_415_422_422_1427_1518_1571_1903_12251_12326_12329_12330%7C50%7C0%7C330%7C6%7C0%7C0%7C5%7C0%7C6%7C%7C0%7C0%7C0%7C223_224_419_419_569_697%7C21%7C0%7C128%7C4%7C0%7C0%7C4%7C223_224_343_343%7C0%7C0%7C0%7C6%7C0%7C0%7C3%7C368_369_395_398_1491_1568%7C14%7C0%7C76%3Bwww.google.com%7Ck%7C1%7C0%7C0%7C0%7"
		"C0%7C1%7C%7C0%7C0%7C0%7C225_225%7C0%7C0%7C0%7C4%7C0%7C0%7C0%7C1769_3615_8172_10320_10323_12001%7C1784%7C1466%7C2148%3Bs.yimg.com%7Ck%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C285_285%7C0%7C0%7C0%7C1%7C0%7C0%7C0%7C406_476%7C70%7C70%7C70%3Bbat.bing.com%7Ck%7C2%7C0%7C0%7C0%7C0%7C2%7C%7C0%7C0%7C0%7C299_299_409_695%7C143%7C0%7C286%7C0%7C1%7C0%7C0%7C1464_1725%7C260%7C260%7C260%3Bampserviceslimited.tt.omtrdc.net%7Cg%7C1%7C0%7C0%7C0%7C316_476%7C160%7C160%7C160%3Bhello.myfonts.net%7Cg%7C1%7C0%7C0%7C0%7C342_"
		"342%7C0%7C0%7C0%3Bfonts.googleapis.com%7Cg%7C1%7C0%7C0%7C1%7C342_342%7C0%7C0%7C0%3Bad.doubleclick.net%7Cg%7C1%7C0%7C0%7C0%7C380_559%7C180%7C180%7C180%3Bwww.gstatic.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C411_1530%7C1120%7C1120%7C1120%3Byourir.info%7Cs%7C2%7C0%7C0%7C0%7C0%7C2%7C%7C0%7C0%7C0%7C419_453_1576_2024%7C242%7C35%7C448%7C1%7C0%7C0%7C0%7C1579_2072%7C493%7C493%7C493%7C3%7C0%7C0%7C0%7C2218_3615_5305_5350%7C939%7C45%7C1394%3Bajax.googleapis.com%7C4%7C1%7C0%7C0%7C1%7C0%7C1%7C%7C0%7C0%7C"
		"0%7C420_420%7C0%7C0%7C0%3Bapi.ipify.org%7Cg%7C1%7C0%7C0%7C0%7C765_2321%7C1556%7C1556%7C1556%3Bsp.analytics.yahoo.com%7Cg%7C1%7C0%7C0%7C0%7C1080_2321%7C1241%7C1241%7C1241%3Bconnect.facebook.net%7Ck%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C1093_1142%7C49%7C49%7C49%7C1%7C0%7C0%7C0%7C1807_2158%7C351%7C351%7C351%3Bfonts.gstatic.com%7Cg%7C2%7C0%7C0%7C0%7C1526_5266%7C3392%7C3042%7C3741%3Bamp.d2.sc.omtrdc.net%7Cg%7C1%7C0%7C0%7C0%7C1544_1581%7C37%7C37%7C37%3Bwww.googletagservices.com%7C4%7C1%7C0%7C0%7C0%7C"
		"0%7C1%7C%7C0%7C0%7C0%7C1584_5298%7C3714%7C3714%7C3714%3Bpagead2.googlesyndication.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C1585_3663%7C2078%7C2078%7C2078%3Bgoogleads4.g.doubleclick.net%7Cg%7C1%7C0%7C0%7C0%7C1587_5264%7C3677%7C3677%7C3677%3Bwww.googletagmanager.com%7Cg%7C4%7C0%7C0%7C0%7C1883_5297_6750_7627%7C1366%7C342%7C3415%3Bcdn.taboola.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C1886_5266%7C3380%7C3380%7C3380%3Bwww.facebook.com%7Cg%7C2%7C0%7C0%7C0%7C2240_5312%7C3065%7C3057%7C3072%3"
		"Btrc.taboola.com%7Cg%7C2%7C0%7C0%7C0%7C5426_7540_7569_7739%7C1142%7C170%7C2114%3Bwww.googleadservices.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C7120_7766%7C647%7C647%7C647%3Bgoogleads.g.doubleclick.net%7Cg%7C3%7C0%7C0%7C0%7C7774_10320%7C1825%7C395%7C2540%3Bwww.google.com.au%7Cg%7C3%7C0%7C0%7C0%7C8172_12204%7C1840%7C1487%7C2156%3Btrc-events.taboola.com%7Cg%7C2%7C0%7C0%7C0%7C8250_12350%7C2264%7C536%7C3992%3Bwww.sc.pages03.net%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C12214_13178%7C964%7C96"
		"4%7C964%3Bwww.pages03.net%7C2%7C0%7C1%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C13205_15448%7C2242%7C2242%7C2242$rt="
		"1-1624946682624%3Bhttps%3A%2F%2Fassets.adobedtm.com%2F30cb14f656a0%2F7a08285d48a4%2Flaunch-36c302166c9d.min.js%7Cb222e0f0g0h0i0j0m0v98652w377849K1I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Fclientlib-site.css%7Cb223e0f0g0h0i0j0m0v43375w348255K1I11M-446851815%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc.clientlibs%2Fclientlibs%2Fgranite%2Fjquery.js%7Cb223e0f0g0h0i0j0m0v88042w294660K1I12M1038558126%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc.clientlibs%2Fclientlibs%2Fgranite%2Futils."
		"js%7Cb223e0f0g0h0i0j0m0v10737w48607K1I12M-675004936%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc.clientlibs%2Fclientlibs%2Fgranite%2Fjquery%2Fgranite.js%7Cb224e0f0g0h0i0j0m0v973w2408K1I12M-1223847897%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Fswiftype-libs.js%7Cb224e0f0g0h0i0j0m0v8510w24519K1I12M254190841%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp%2FclientLibraries%2Ficons-libs.css%7Cb224e0f0g0h0i0j0m0v2180w11909K1I11M-831598683%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2F"
		"designs%2Famp-au%2Fclientlibs%2Flegacy-nps.css%7Cb224e0f0g0h0i0j0m0v4872w38911K1I11M-1422456331%7Chttps%3A%2F%2Fwww.google.com%2Frecaptcha%2Fapi.js%3Frender%3D6Lf1YKQUAAAAAK3RIImnFOQrks8gZnrC7pObqn5q%7Cb225e0m0I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fdata%2Ficons%2Famp-logo-reversed.svg%7Cb225e0f0g0h0i0j0m0v205162w205162E1F6188O119P52I7M-1281867438%7Chttps%3A%2F%2Fassets.adobedtm.com%2Fextensions%2FEPbde2f7ca14e540399dcc1f8208860b7b%2FAppMeasurement.min.js%7Cb264e0f0g0h0i0j0k4"
		"l23m23u12670v12184w33462I12%7Chttps%3A%2F%2Fs.yimg.com%2Fwi%2Fytc.js%7Cb285e0m0I12%7Chttps%3A%2F%2Fbat.bing.com%2Fbat.js%7Cb299e0m0I12%7Chttps%3A%2F%2Fampserviceslimited.tt.omtrdc.net%2Frest%2Fv1%2Fdelivery%3Fclient%3Dampserviceslimited%26sessionId%3D3cc95b43f68748bfb93d005ba6dcfa05%26version%3D2.3.2%7Cb316e0m160T-10z1I1%7Chttps%3A%2F%2Fhello.myfonts.net%2Fcount%2F3a2740%7Cb342e0m0I9%7Chttps%3A%2F%2Ffonts.googleapis.com%2Fcss%3Ffamily%3DOpen%2BSans%3A400italic%5Ec600italic%5Ec400%5Ec300%5Ec600%7Cb"
		"342e0f0g0h0i0j0m0v814w10371I9%7Chttps%3A%2F%2Fwww.amp.com.au%2Fddc%2Fpublic%2Fui%2Fassets%2Fddc-fonts%2Fddc-fonts.css%7Cb343e0f0g0h0i0j0m0v2043w10164I9M840765892%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F33543c5cc5d88f5695dd08c87d280dfd.woff2%7Cb368e0f0g0h0i0j0m0v14380w14380I9M-1860783378%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F819af3d3abdc9f135d49b80a91e2ff4c.woff2%7Cb369e0f0g0h0i0j0m0v14880w14880I9M-733586217%7Chttps%3A%2F%2Fwww.amp.com.au%2Fet"
		"c%2Fdesigns%2Famp-au%2Fassets%2F2525a15d1fb3ce824a7aad5e07ba2513.ttf%7Cb369e0f0g0h0i0j0m0v27480w27480I9M-835539285%7Chttps%3A%2F%2Fad.doubleclick.net%2Fddm%2Fadj%2FN962361.197812NSO.CODESRV%2FB22590592.244647881%5Essz%3D1x2%5Esord%3D448111192613%3F%7Cb380e0f0g0h0i0j0k3l148m180u8733v7785w20598K1I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F98c3ea22ad6bca213fa88175f7d9ffaf.woff2%7Cb395e0f0g0h0i0j0k2l2m2v96082w96082I9M-1892032532%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns"
		"%2Famp-au%2Fassets%2Fce62fa71a1a38af297b433e85d36d83f.woff2%7Cb397e0f0g0h0i0j0k2l2m2v76773w76773I9M1519948408%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fdata%2Ficons%2Famp-logo.svg%7Cb401e0f0g0h0i0j0m0v174276w174276N3O120P53Q284R125I7M-1231867539%7Chttps%3A%2F%2Fs.yimg.com%2Fwi%2Fconfig%2F10092149.json%7Cb406e0m70T-11z1I1%7Chttps%3A%2F%2Fbat.bing.com%2Fp%2Faction%2F16012365.js%7Cb409e0m286I12%7Chttps%3A%2F%2Fwww.gstatic.com%2Frecaptcha%2Freleases%2FeKRIyK-9MtX6JxeZcNZIkfUq%2Frecaptc"
		"ha_5F_5Fen.js%7Cb411e0m1120I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fimages%2Fpage-banners%2Fhomepage-hero-AMPsaver-cataff-house-goals.jpg.ampaurendition.1920.0.jpg%7Cb414e0f0g0h0i0j0m0v71022w71686E1F660000O1920P440I7M756397288%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fimages%2Fadviser-tab%2FTile_5FGuarantees_5F488.jpg.ampaurendition.1920.0.jpg%7Cb414e0f0g0h0i0j0m0v110565w113336I7M346259635%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Fic"
		"ons%2Fbanner%2FSuper.svg%7Cb414e0f0g0h0i0j0m0v2874w2874I7M-975234907%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Fbanner%2Frelaxation.svg%7Cb414e0f0g0h0i0j0m0v1837w1837I7M729609198%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Fbanner%2FHome_2520loans.svg%7Cb414e0f0g0h0i0j0m0v3446w3446I7M-1574632057%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Fbanner%2FBanking.svg%7Cb415e0f0g0h0i0j0m0v3076w3076I7M17156"
		"66691%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Fbanner%2Fhand-and-coin.svg%7Cb415e0f0g0h0i0j0m0v1205w1205I7M-1932096678%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Fbanner%2Fpiggy-bank-clock.svg%7Cb415e0f0g0h0i0j0m0v2386w2386I7M68765190%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Fbanner%2Fsmart-money.svg%7Cb415e0f0g0h0i0j0m0v1648w1648I7M1106042435%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2F"
		"amp-au%2Fauthoring%2Ficons%2Fbanner%2FInvestments.svg%7Cb415e0f0g0h0i0j0m0v2130w2130I7M1411770323%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Fbanner%2Fumbrella.svg%7Cb415e0f0g0h0i0j0m0v1315w1315I7M913959968%7Chttps%3A%2F%2Fyourir.info%2F61b218eca79bef95.js%7Cb419e0m35I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Fclientlib-site.js%7Cb419e0f0g0h0i0j0m0v130526w431873K1I12M1189347597%7Chttps%3A%2F%2Fajax.googleapis.com%2Fajax%2Flibs%2Fwebf"
		"ont%2F1.6%2Fwebfont.js%7Cb420e0f0g0h0i0j0m0v5437w13188K1I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2Faa8fe13f4c832769bd0ab2ea7e247013.svg%7Cb422e0f0g0h0i0j0m0v2555w2555I9M-2054678452%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Flegacy-nps.js%3F_5F%3D1624946682984%7Cb569e0f0g0h0i0j0k5l125m128u10622v9770w50111T-13z1I1M-1305959488%7Chttps%3A%2F%2Fapi.ipify.org%2F%3Fformat%3Djsonp%26callback%3D%3F%7Cb765e0m1556T-14z1I1%7Chttps%3A%2F%2Fsp.analytics.ya"
		"hoo.com%2Fsp.pl%7Cb1080e0m1241N3O1P1I7%7Chttps%3A%2F%2Fconnect.facebook.net%2Fen_5FUS%2Ffbevents.js%7Cb1093e0m49I12%7Chttps%3A%2F%2Fassets.adobedtm.com%2F30cb14f656a0%2F7a08285d48a4%2F29c0db022c3d%2FRC3780d39ec03d45df99c03f86ac0bab9c-source.min.js%7Cb1203e0f0g0h0i0j0k13l66m66u901v413w717I12%7Chttps%3A%2F%2Fassets.adobedtm.com%2F30cb14f656a0%2F7a08285d48a4%2F29c0db022c3d%2FRC15a5c6f5e8cb4510b7d70763e430d359-source.min.js%7Cb1212e0f0g0h0i0j0k58l146m167u977v489w824I12%7Chttps%3A%2F%2Fwww.amp.com.au%2"
		"Fcontent%2Fdam%2Famp-au%2Fdata%2Fillustrations%2FCookies.svg%7Cb1427e0f0g0h0i0j0k41l90m91u2118v1382w1382E2F1296O36P36Q150R150I7M-100836164%7Chttps%3A%2F%2Fbat.bing.com%2Faction%2F0%7Cb1464e0m260A1N3I7%7Chttps%3A%2F%2Fwww.amp.com.au%2Fwps%2Fgws%2FNetPromoterScore%3FpageId%3Damp_253A%7Cb1491e0f0g0h0i0j0k28l76m76u1144v19w19T-12z1I1M1946190603%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs%2Fopensans%2Fv20%2Fmem8YaGs126MiZpBA-UFVZ0b.woff2%7Cb1526e0f0g0h469i2123j525k2138l2209m3741u15203v14440w14440I9%7Chttps%3A"
		"%2F%2Famp.d2.sc.omtrdc.net%2Fb%2Fss%2Famp-dtm-prd%2F1%2FJS-2.22.0-LBSQ%2Fs83231038142202%7Cb1544e0m37I7%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fillustrations%2FBanking.svg%7Cb1571e0f0g0h0i0j0k156l227m267u3819v3076w3076I7M1306204354%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fillustrations%2FSuper.svg%7Cb1573e0f0g0h0i0j0k156l218m264u3618v2874w2874I7M-1671130075%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fillustrations%2FTell-your-employer.svg%7Cb1573e0f"
		"0g0h0i0j0k213l280m330u3498v2762w2762I7M1050799341%7Chttps%3A%2F%2Fyourir.info%2Flib%2F1.11.6%2Fyourir.js%7Cb1576e0m448I12%7Chttps%3A%2F%2Fyourir.info%2Flib%2F1.11.6%2Fyourir.css%7Cb1579e0m493K1I11%7Chttps%3A%2F%2Fwww.googletagservices.com%2Factiveview%2Fjs%2Fcurrent%2Frx_5Flidar.js%3Fcache%3Dr20110914%7Cb1584e0m3714I12%7Chttps%3A%2F%2Fpagead2.googlesyndication.com%2Fpagead%2Fjs%2Fr20210624%2Fr20110914%2Felements%2Fhtml%2Fomrhp.js%7Cb1585e0f0g0h378i2012j433k2030l2069m2078u3929v3124w7957K1I12%7Chttp"
		"s%3A%2F%2Fgoogleads4.g.doubleclick.net%2Fpcs%2Fview%7Cb1587e0f0g0h286i785j406k2010l3676m3677u818I3%7Chttps%3A%2F%2Fwww.google.com%2Frecaptcha%2Fapi2%2Fanchor%3Far%3D1%26k%3D6Lf1YKQUAAAAAK3RIImnFOQrks8gZnrC7pObqn5q%26co%3DaHR0cHM6Ly93d3cuYW1wLmNvbS5hdTo0NDM.%26hl%3Den%26v%3DeKRIyK-9MtX6JxeZcNZIkfUq%26size%3Dinvisible%26cb%3Dp9rmtrk5esvz%7Cb1769e0m1846F5220N1Bi0I4%7Chttps%3A%2F%2Fconnect.facebook.net%2Fsignals%2Fconfig%2F131169910928083%3Fv%3D2.9.42%26r%3Dstable%7Cb1807e0m351I12%7Chttps%3A%2F%2Fwww."
		"googletagmanager.com%2Fgtag%2Fjs%3Fid%3DDC-8836193%7Cb1883e0m3415I12%7Chttps%3A%2F%2Fcdn.taboola.com%2Flibtrc%2Funip%2F1236555%2Ftfa.js%7Cb1886e0m3380I12%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.asx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Cb2218e0m1378T-15z1I1%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.nzx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Cb2221e0m1394T-16z1I1%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs%2Fopensans%2Fv20%2Fmem5YaGs126MiZpBA-UNirkOUuhp.wo"
		"ff2%7Cb2224e0f0g0h76i1429j166k1440l1533m3042u15719v14956w14956I9%7Chttps%3A%2F%2Fwww.facebook.com%2Ftr%2F%7Cb2240e0m3072I7%7Chttps%3A%2F%2Fwww.facebook.com%2Ftr%2F%7Cb2241e0m3057I7%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fversions%3FappID%3D61b218eca79bef95%26libVersion%3D1.11.6%26st%3D1%7Cb5305e0m45T-17z1I1%7Chttps%3A%2F%2Ftrc.taboola.com%2F1236555%2Ftrc%2F3%2Fjson%7Cb5426e0m2114I12%7Chttps%3A%2F%2Fwww.googletagmanager.com%2Fgtag%2Fjs%3Fid%3DAW-751278354%26l%3DdataLayer%26cx%3Dc%7Cb6750e0m342I12%"
		"7Chttps%3A%2F%2Fwww.googletagmanager.com%2Fgtag%2Fjs%3Fid%3DAW-684022622%26l%3DdataLayer%26cx%3Dc%7Cb6751e0m832I12%7Chttps%3A%2F%2Fwww.googletagmanager.com%2Fgtag%2Fjs%3Fid%3DAW-711997817%26l%3DdataLayer%26cx%3Dc%7Cb6752e0m874I12%7Chttps%3A%2F%2Fwww.googleadservices.com%2Fpagead%2Fconversion_5Fasync.js%7Cb7120e0f0g0h5i444j42k464l595m647u14997v14015w36813I12%7Chttps%3A%2F%2Ftrc.taboola.com%2F1236555%2Flog%2F3%2Funip%7Cb7569e0m170T-18z1I1%7Chttps%3A%2F%2Fgoogleads.g.doubleclick.net%2Fpagead%2Fviewth"
		"roughconversion%2F711997817%2F%7Cb7774e0f0g0h4i170j41k170l389m395u2176v1095w2486K1I12%7Chttps%3A%2F%2Fgoogleads.g.doubleclick.net%2Fpagead%2Fviewthroughconversion%2F684022622%2F%7Cb7778e0f0g0h17i259j61k259l488m2540u2288v1094w2488K1I12%7Chttps%3A%2F%2Fgoogleads.g.doubleclick.net%2Fpagead%2Fviewthroughconversion%2F751278354%2F%7Cb7782e0f0g0h39i353j149k354l2537m2538u2244v1095w2486K1I12%7Chttps%3A%2F%2Fwww.google.com%2Fpagead%2F1p-user-list%2F711997817%2F%7Cb8172e0f0g0h0i0j0k3l2146m2148u768v42w42I7%7C"
		"https%3A%2F%2Fwww.google.com.au%2Fpagead%2F1p-user-list%2F711997817%2F%7Cb8172e0m2156I7%7Chttps%3A%2F%2Ftrc-events.taboola.com%2F1236555%2Flog%2F3%2Funip%7Cb8250e0m3992T-19z1I1%7Chttps%3A%2F%2Fwww.google.com%2Fpagead%2F1p-user-list%2F684022622%2F%7Cb10323e0f0g0h0i0j0k6l1460m1466u768v42w42I7%7Chttps%3A%2F%2Fwww.google.com.au%2Fpagead%2F1p-user-list%2F684022622%2F%7Cb10323e0m1487I7%7Chttps%3A%2F%2Fwww.google.com%2Fpagead%2F1p-user-list%2F751278354%2F%7Cb10326e0f0g0h0i0j0k1464l1674m1675u768v42w42I7%7"
		"Chttps%3A%2F%2Fwww.google.com.au%2Fpagead%2F1p-user-list%2F751278354%2F%7Cb10327e0m1877I7%7Chttps%3A%2F%2Ftrc-events.taboola.com%2F1236555%2Flog%2F3%2Funip%7Cb11814e0m536T-20z1I1%7Chttps%3A%2F%2Fwww.sc.pages03.net%2Flp%2Fstatic%2Fjs%2FiMAWebCookie.js%3F18560ebc-14a40f8eab9-943e27de0c8b91cc3fcf1475c3e5d726%26h%3Dwww.pages03.net%7Cb12214e0m964K1I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Ffavicon.ico%7Cb12251e0f0g0h0i0j0k3l74m75u2152v1406w1406I22M265790923%7Chttp"
		"s%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Ffavicon.ico%7Cb12329e0f0g0h0i0j0k1l1m2v1406w1406I22M265790923%7Chttps%3A%2F%2Fwww.pages03.net%2FWTS%2Fevent.jpeg%7Cb13205e0m2242A1N3S2245I7$url=https%3A%2F%2Fwww.amp.com.au%2F$title=AMP%20%E2%80%93%20Banking%2C%20Super%2C%20Retirement%2C%20Financial%20Advice%20%26%20Insurance%20-%20AMP$latC=2$app=cd4697ba1bc4a478$visitID=KGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0$vs=2$fId=146682855_874$v=10217210531114014$vID="
		"16249466784450Q0MQIFVSELV6Q8T30TVRP9L9CP81NSQ$time=1624946700158", 
		LAST);

	lr_end_transaction("01_LaunchURL",LR_AUTO);

	lr_start_transaction("02_CLick on Banking");

	web_revert_auto_header("Origin");

	web_reg_find("Text=Banking - AMP Bank", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("banking", 
		"URL=https://www.amp.com.au/banking", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://assets.adobedtm.com/extensions/EPbde2f7ca14e540399dcc1f8208860b7b/AppMeasurement.min.js", ENDITEM, 
		"Url=/content/dam/amp-au/images/page-banners/banner-product-15.jpg", ENDITEM, 
		"Url=/content/dam/amp-au/images/banking-hub/banners/kombi_van_product_promo.jpg", ENDITEM, 
		"Url=/etc/designs/amp-au/clientlibs/legacy-nps.js?_=1624946715814", ENDITEM, 
		"Url=https://ad.doubleclick.net/ddm/adj/N962361.197812NSO.CODESRV/B22590592.244647881;sz=1x2;ord=275629320778?", ENDITEM, 
		"Url=https://sp.analytics.yahoo.com/sp.pl?a=10000&d=Tue%2C%2029%20Jun%202021%2006%3A05%3A17%20GMT&n=-10&b=Banking%20-%20AMP%20Bank&.yp=10092149&f=https%3A%2F%2Fwww.amp.com.au%2Fbanking&e=https%3A%2F%2Fwww.amp.com.au%2F&enc=UTF-8&yv=1.10.1&tagmgr=adobe", ENDITEM, 
		"Url=https://d.la1-c1-syd.salesforceliveagent.com/chat/rest/System/MultiNoun.jsonp?nouns=VisitorId,Settings&VisitorId.prefix=Visitor&Settings.prefix=Visitor&Settings.buttonIds=[5732P000000004W]&Settings.updateBreadcrumb=1&Settings.urlPrefix=undefined&callback=liveagent._.handlePing&deployment_id=5722P000000004b&org_id=00D7F0000001MC1&version=51", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s89864429528600?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A5%3A18%202%20-600&sdid=2FD078431D872D61-05B49962AAAE4C58&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=banking&g=https%3A%2F%2Fwww.amp.com.au%2Fbanking&r=https%3A%2F%2Fwww.amp.com.au%2F&cc=AUD&ch=amp&events=event75%3D27&aamb=6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y&c1=web&v1=D%3Dc1&h1=banking&c2=banking&v2=D%3Dc2"
		"&c3=banking&v3=D%3Dc3&v6=false&v7=banking&c12=1624946717850&v12=4%3A05PM%7C4%3A00PM%7CTuesday%7C29%2F6%2F2021&c16=https%3A%2F%2Fwww.amp.com.au%2Fbanking&v16=D%3Dc16&c30=23569144125047983874531016401195797023&v30=D%3Dc30&c32=home&v47=personal&v49=consideration&c74=AMP%20PUBLIC%20SITE%20Launch&c75=27&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&AQE=1", ENDITEM, 
		"Url=https://www.facebook.com/tr/?id=131169910928083&ev=ViewContent&dl=https%3A%2F%2Fwww.amp.com.au%2Fbanking&rl=https%3A%2F%2Fwww.amp.com.au%2F&if=false&ts=1624946718445&sw=1500&sh=1000&v=2.9.42&r=stable&ec=1&o=28&fbp=fb.2.1624946684859.99642261&it=1624946718360&coo=false&rqm=GET", ENDITEM, 
		"Url=https://trc.taboola.com/1236555/trc/3/json?tim=1624946718462&data="
		"%7B%22id%22%3A691%2C%22ii%22%3A%22%2Fbanking%22%2C%22it%22%3A%22video%22%2C%22sd%22%3Anull%2C%22ui%22%3Anull%2C%22vi%22%3A1624946718448%2C%22cv%22%3A%2220210615-3-RELEASE%22%2C%22uiv%22%3A%22default%22%2C%22u%22%3A%22https%3A%2F%2Fwww.amp.com.au%2Fbanking%22%2C%22e%22%3A%22https%3A%2F%2Fwww.amp.com.au%2F%22%2C%22cb%22%3A%22TFASC.trkCallback%22%2C%22qs%22%3A%22%22%2C%22r%22%3A%5B%7B%22li%22%3A%22rbox-tracking%22%2C%22s%22%3A0%2C%22uim%22%3A%22rbox-tracking%3Apub%3Dreprisemelb-amp-au-sc%3Aabp%3D0%22"
		"%2C%22uip%22%3A%22rbox-tracking%22%2C%22orig_uip%22%3A%22rbox-tracking%22%7D%5D%2C%22mpv%22%3Atrue%2C%22mpvd%22%3A%7B%22en%22%3A%22page_view%22%2C%22item-url%22%3A%22https%3A%2F%2Fwww.amp.com.au%2F%22%2C%22tim%22%3A1624946718461%2C%22ref%22%3A%22https%3A%2F%2Fwww.amp.com.au%2F%22%2C%22tos%22%3A27607%2C%22ssd%22%3A2%2C%22scd%22%3A16%7D%7D&pubit=i", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/751278354/?random=1624946718563&cv=9&fst=1624946718563&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=2&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking&ref=https%3A%2F%2Fwww.amp.com.au%2F&tiba=Banking%20-%20AMP%20Bank&hn=www.googleadservices.com&async=1&rfmt=3&fmt=4", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/711997817/?random=1624946718568&cv=9&fst=1624946718568&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=2&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking&ref=https%3A%2F%2Fwww.amp.com.au%2F&tiba=Banking%20-%20AMP%20Bank&hn=www.googleadservices.com&async=1&rfmt=3&fmt=4", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/684022622/?random=1624946718567&cv=9&fst=1624946718567&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=2505059651&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=2&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking&ref=https%3A%2F%2Fwww.amp.com.au%2F&tiba=Banking%20-%20AMP%20Bank&hn=www.googleadservices.com&async=1&rfmt=3&fmt=4", ENDITEM, 
		"Url=https://trc.taboola.com/1236555/log/3/unip?en=page_view&item-url=https%3A%2F%2Fwww.amp.com.au%2F&tim=1624946718461&ref=https%3A%2F%2Fwww.amp.com.au%2F&cv=20210615-3-RELEASE&tos=27920&ssd=2&scd=16&vi=1624946718448&ri=ca3a166f24493bcbc73bd7b8dd513868&sd=v2_708454af5ecb44b01dc61b48cc798c89_69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e_1624946718_1624946718_CIi3jgYQy7xLGPDt_LKlLyABKAEwEDiu_QZA8IUQSInB1wNQiZoCWABgAGiV8efG4eHrgl8&ui=69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e", ENDITEM, 
		"Url=https://www.google.com/pagead/1p-user-list/751278354/?random=1624946718563&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=2&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking&ref=https%3A%2F%2Fwww.amp.com.au%2F&tiba=Banking%20-%20AMP%20Bank&async=1&fmt=3&is_vtc=1&random=631545156&resp=GooglemKTybQhCsO&rmt_tld=0&ipr=y", ENDITEM, 
		"Url=https://cdn.taboola.com/scripts/cds-pips.js", ENDITEM, 
		"Url=https://www.google.com/pagead/1p-user-list/711997817/?random=1624946718568&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=2&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking&ref=https%3A%2F%2Fwww.amp.com.au%2F&tiba=Banking%20-%20AMP%20Bank&async=1&fmt=3&is_vtc=1&random=1077475195&resp=GooglemKTybQhCsO&rmt_tld=0&ipr=y", ENDITEM, 
		"Url=https://www.facebook.com/tr/?id=131169910928083&ev=PageView&dl=https%3A%2F%2Fwww.amp.com.au%2Fbanking&rl=https%3A%2F%2Fwww.amp.com.au%2F&if=false&ts=1624946718443&sw=1500&sh=1000&v=2.9.42&r=stable&ec=0&o=28&fbp=fb.2.1624946684859.99642261&it=1624946718360&coo=false&rqm=GET", ENDITEM, 
		"Url=https://www.google.com/pagead/1p-user-list/684022622/?random=1624946718567&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=2505059651&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=2&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking&ref=https%3A%2F%2Fwww.amp.com.au%2F&tiba=Banking%20-%20AMP%20Bank&async=1&fmt=3&is_vtc=1&random=337248623&resp=GooglemKTybQhCsO&rmt_tld=0&ipr=y", ENDITEM, 
		"Url=https://www.pages03.net/WTS/event.jpeg?accesskey=18560ebc-14a40f8eab9-943e27de0c8b91cc3fcf1475c3e5d726&v=1.31&isNewSession=0&type=pageview&isNewVisitor=0&sessionGUID=bb945113-85bc-a875-4ddc-6479ec5c1c79&webSyncID=ac130211-93c1-63b2-1ca5-a0d58d000ac2&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking&newSiteVisit=0&referringURL=https%3A%2F%2Fwww.amp.com.au%2F&hostname=www.amp.com.au&pathname=%2Fbanking&newPageVisit=1&eventKey=871b69b9-0662-1a6d-7605-52c4de16040e", ENDITEM, 
		"Url=/content/dam/amp-au/images/goals/Save-for-something-big.jpg.ampaurendition.1920.0.jpg", ENDITEM, 
		"Url=/content/dam/amp-au/images/goals/Buy-a-home.jpg.ampaurendition.1920.0.jpg", ENDITEM, 
		"Url=/content/dam/amp-au/images/goals/Pursue-a-passion.jpg.ampaurendition.1920.0.jpg", ENDITEM, 
		"Url=https://trc-events.taboola.com/1236555/log/3/unip?en=pre_d_eng_tb&tos=51694&scd=25&ssd=2&est=1624946688030&ver=32&isls=true&src=i&invt=24000&tim=1624946742548&vi=1624946718448&ri=ca3a166f24493bcbc73bd7b8dd513868&sd=v2_708454af5ecb44b01dc61b48cc798c89_69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e_1624946718_1624946718_CIi3jgYQy7xLGPDt_LKlLyABKAEwEDiu_QZA8IUQSInB1wNQiZoCWABgAGiV8efG4eHrgl8&ui=69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e&ref=https%3A%2F%2Fwww.amp.com.au%2F&cv="
		"20210615-3-RELEASE&item-url=https%3A%2F%2Fwww.amp.com.au%2Fbanking", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s81990249316050?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A5%3A58%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=banking&g=https%3A%2F%2Fwww.amp.com.au%2Fbanking&cc=AUD&events=event52&c28=banking%3Aproduct-list%20cta%3ASavings%20accounts&v28=D%3Dc28&pe=lnk_o&pev1=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&pev2="
		"banking%3Aproduct-list%20cta%3ASavings%20accounts&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=249&AQE=1", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_custom_request("0_2", 
		"URL=https://bat.bing.com/actionp/0?ti=16012365&Ver=2&mid=ecbf8a36-37a6-4942-9970-c20cf0f63b83&sid=e6578fe0d89f11eb98165deac4f355a8&vid=e657ca70d89f11eb8fe68f742e2032a1&vids=1&evt=pageHide", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_revert_auto_header("Origin");

	web_custom_request("delivery_3", 
		"URL=https://ampserviceslimited.tt.omtrdc.net/rest/v1/delivery?client=ampserviceslimited&sessionId=3cc95b43f68748bfb93d005ba6dcfa05&version=2.3.2", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body={\"requestId\":\"40537a5a2e1446dfa40b734664361dc4\",\"context\":{\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36\",\"timeOffsetInMinutes\":600,\"channel\":\"web\",\"screen\":{\"width\":1500,\"height\":1000,\"orientation\":\"landscape\",\"colorDepth\":24,\"pixelRatio\":1},\"window\":{\"width\":1500,\"height\":857},\"browser\":{\"host\":\"www.amp.com.au\",\"webGLRenderer\":\"Google SwiftShader\"},\"address\":{\""
		"url\":\"https://www.amp.com.au/banking\",\"referringUrl\":\"https://www.amp.com.au/\"}},\"id\":{\"tntId\":\"3cc95b43f68748bfb93d005ba6dcfa05.36_0\",\"marketingCloudVisitorId\":\"23569144125047983874531016401195797023\"},\"experienceCloud\":{\"audienceManager\":{\"locationHint\":8,\"blob\":\"6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y\"},\"analytics\":{\"logging\":\"server_side\",\"supplementalDataId\":\"2FD078431D872D61-05B49962AAAE4C58\",\"trackingServer\":\"amp.d2.sc.omtrdc.net\",\""
		"trackingServerSecure\":\"amp.d2.sc.omtrdc.net\"}},\"execute\":{\"pageLoad\":{\"parameters\":{\"user.categoryId\":\"banking\"},\"profileParameters\":{\"pageName\":\"banking\"}}},\"prefetch\":{\"views\":[{\"parameters\":{\"user.categoryId\":\"banking\"},\"profileParameters\":{\"pageName\":\"banking\"}}]}}", 
		LAST);

	web_reg_find("Text=reCAPTCHA", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"iframe");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("anchor_2", 
		"URL=https://www.google.com/recaptcha/api2/anchor?ar=1&k=6Lf1YKQUAAAAAK3RIImnFOQrks8gZnrC7pObqn5q&co=aHR0cHM6Ly93d3cuYW1wLmNvbS5hdTo0NDM.&hl=en&v=eKRIyK-9MtX6JxeZcNZIkfUq&size=invisible&cb=d8ntgfzedi49", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.amp.com.au/banking", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_url("0_3", 
		"URL=https://bat.bing.com/action/0?ti=16012365&Ver=2&mid=788691d3-6609-4a79-a2eb-73b79bc044bd&sid=e6578fe0d89f11eb98165deac4f355a8&vid=e657ca70d89f11eb8fe68f742e2032a1&vids=0&pi=1200101525&lg=en-GB&sw=1500&sh=1000&sc=24&tl=Banking%20-%20AMP%20Bank&p=https%3A%2F%2Fwww.amp.com.au%2Fbanking&r=https%3A%2F%2Fwww.amp.com.au%2F&lt=2874&evt=pageLoad&msclkid=N&sv=1&rn=946552", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/banking", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_url("amp.asx_2", 
		"URL=https://yourir.info/api/v5/symbols/amp.asx?appID=61b218eca79bef95&liveness=delayed", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_custom_request("view_2", 
		"URL=https://googleads4.g.doubleclick.net/pcs/view?xai=AKAOjssWkTm8-n_MPfqwFWot3iVN2JGt-V-ESYOIhbdlxwEH_9mw1phY_DLabV2W8PqSO-PXdUF4bJKZ1UuEu95LdqLzp3k2VNIcje3_jCA2uyhOKxnL7OsauZjmxHRtv55e&sig=Cg0ArKJSzB-Rkev2HYvlEAE&fbs_aeid=[gw_fbsaeid]&urlfix=1&omid=0&rm=1&ctpt=1&cbvp=1&cisv=r20210624.95255&adurl=", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://www.amp.com.au/banking", 
		"Snapshot=t34.inf", 
		"EncType=text/plain;charset=UTF-8", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_header("x-dtpc", 
		"7$146715664_895h5vKGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0e3");

	web_url("NetPromoterScore_2", 
		"URL=https://www.amp.com.au/wps/gws/NetPromoterScore?pageId=amp%3Abanking", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_add_header("Access-Control-Request-Headers", 
		"content-type,x-requested-with");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_custom_request("7QBD98FWDMDQKABHCQLGZ52QEX", 
		"URL=https://d2vj5tua97fz9h.cloudfront.net/nuassist/rest/in/api/amp_nps_v1/survey/7QBD98FWDMDQKABHCQLGZ52QEX", 
		"Method=OPTIONS", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_custom_request("7QBD98FWDMDQKABHCQLGZ52QEX_2", 
		"URL=https://d2vj5tua97fz9h.cloudfront.net/nuassist/rest/in/api/amp_nps_v1/survey/7QBD98FWDMDQKABHCQLGZ52QEX", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"npsSessionId\":\"ace640ac-7ccf-4d8d-a02d-96b479f90bee\",\"parameters\":[{\"key\":\"channelname\",\"value\":\"anon-portal\"},{\"key\":\"device\",\"value\":\"desktop\"},{\"key\":\"browser\",\"value\":\"Chrome/91.0\"},{\"key\":\"pageId\",\"value\":\"amp:banking\"}]}", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("x-dtpc", 
		"7$146715664_895h13vKGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0e3");

	web_url("nps.html", 
		"URL=https://www.amp.com.au/wps/gws/com_amp_portal_nps/nps.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.amp.com.au/banking", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/ddc/public/ui/assets/ddc-fonts/ddc-icons.ttf", "Referer=https://www.amp.com.au/ddc/public/ui/assets/ddc-fonts/ddc-fonts.css", ENDITEM, 
		LAST);

	lr_end_transaction("02_CLick on Banking",LR_AUTO);

	web_revert_auto_header("X-Requested-With");

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_custom_request("rb_bf96747ztk_5", 
		"URL=https://www.amp.com.au/rb_bf96747ztk?app=cd4697ba1bc4a478;crc=746554546;end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.amp.com.au/banking", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a="
		"d%7C-1%7CBanking%7CC%7C-%7C146682855_874%7C1624946715130%7Chttps%3A%2F%2Fwww.amp.com.au%2F%7CAMP%20%E2%80%93%20Banking%5Ec%20Super%5Ec%20Retirement%5Ec%20Financial%20Advice%20%26%20Insurance%20-%20AMP%7C%7C%2F%7C1624946682624%2C1%7C1%7C_load_%7C_load_%7C-%7C1624946715171%7C1624946721587%7Cdn%7C1389%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Clr%7Chttps%3A%2F%2Fwww.amp.com.au%2F%2C2%7C15%7C_event_%7C1624946715171%7C_vc_%7CV%7C4355%5Epc%7CVCD%7C2711%7CVCDS%7C13%7CVCS%7C64"
		"71%7CVCO%7C7482%7CVCI%7C0%7CVE%7C1313%5Ep313%5Ep540%5Eps%5Esspan.icon.icon--plus.icon--plus-rotated%7CS%7C1023%2C2%7C16%7C_event_%7C1624946715171%7C_wv_%7ClcpE%7CDIV%7ClcpSel%7Cdiv.banner-wrapper.banner-wrapper--image%7ClcpS%7C652520%7ClcpT%7C3223%7ClcpU%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fimages%2Fpage-banners%2Fbanner-product-15.jpg%7Cfcp%7C2648%7Cfp%7C2648%7Ccls%7C0.0207%7Clt%7C2550%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C2%7C2%7Cx%7Cxhr%7Cx%7C1624946715771%7C1624946717717%7C"
		"dn%7C1292%7Cxu%7Chttps%3A%2F%2Fampserviceslimited.tt.omtrdc.net%2Frest%2Fv1%2Fdelivery%3Fclient%3Dampserviceslimited%26sessionId%3D3cc95b43f68748bfb93d005ba6dcfa05%26version%3D2.3.2%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946715775e0m1658T-1z11I1%7Cxcs%7C1946%7Cxce%7C1946%2C2%7C3%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946715929%7C1624946717819%7Cdn%7C1321%7Cxu%7C%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Flegacy-nps.js%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ct"
		"vtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946717344e0f0g0h0i0j0k236l319m372u10621v9770w50111T-2z11I1M-498705695%7Cxcs%7C1880%7Cxce%7C1891%2C2%7C4%7Cx%7Cxhr%7Cx%7C1624946717375%7C1624946717802%7Cdn%7C1292%7Cxu%7Chttps%3A%2F%2Fs.yimg.com%2Fwi%2Fconfig%2F10092149.json%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946717571e0m33T-3z11I1%7Cxcs%7C425%7Cxce%7C427%2C2%7C5%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946717870%7C1624946719524%7Cdn%7C1388%7Cxu%7C%2Fwps%2Fg"
		"ws%2FNetPromoterScore%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946717876e0f0g0h0i0j0k3l707m708u1138v259w312T-6z11I1M220796961%7Cxcs%7C716%7Cxce%7C850%2C3%7C6%7CResizeObserver%20loop%20limit%20exceeded%7C_error_%7C-%7C1624946718070%7C1624946718070%7Cdn%7C-1%2C4%7C7%7Chttps%3A%2F%2Fwww.amp.com.au%2Fbanking%7C_location_%7C-%7C1624946718074%7C1624946718074%7Cdn%7C-1%2C4%7C8%7C2406%7C_ts_%7C-%7C1624946718076%7C1624946718076%7Cdn%7C-1%2C3%7C11%7Cj1.12.4-aem%7Cxh"
		"r%7Cj1.12.4-aem%7C1624946718709%7C1624946719524%7Cdn%7C1388%7Cxu%7Chttps%3A%2F%2Fd2vj5tua97fz9h.cloudfront.net%2Fnuassist%2Frest%2Fin%2Fapi%2Famp_nps_v1%2Fsurvey%2F7QBD98FWDMDQKABHCQLGZ52QEX%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946718719e0m746T-5z11I1%7Cxcs%7C757%7Cxce%7C763%2C4%7C13%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946719467%7C1624946719524%7Cdn%7C1388%7Cxu%7C%2Fwps%2Fgws%2Fcom_amp_portal_nps%2Fnps.html%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtr"
		"g%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946719472e0f0g0h0i0j0k3l48m48u1780v697w2375T-4z11I1M642068672%7Cxcs%7C55%7Cxce%7C58%2C2%7C9%7Cx%7Cxhr%7Cx%7C1624946718247%7C1624946718376%7Cdn%7C1344%7Cxu%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.asx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946718298e0m45T-7z11I1%7Cxcs%7C128%7Cxce%7C129%2C2%7C10%7Cx%7Cxhr%7Cx%7C1624946718299%7C1624946718367%7Cdn%7C1344%7"
		"Cxu%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.nzx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946718323e0m3T-8z11I1%7Cxcs%7C65%7Cxce%7C68%2C2%7C12%7Cx%7Cxhr%7Cx%7C1624946718776%7C1624946718973%7Cdn%7C1355%7Cxu%7Chttps%3A%2F%2Ftrc.taboola.com%2F1236555%2Flog%2F3%2Funip%3Fen%3Dpage_view%26item-url%3Dhttps%253A%252F%252Fwww.amp.com.au%252F%26tim%3D1624946718461%26ref%3Dhttps%253A%252F%252Fwww.amp.com.a"
		"u%252F%26cv%3D20210615-3-RELEASE%26tos%3D27920%26ssd%3D2%26scd%3D16%26vi%3D1624946718448%26ri%3Dca3a166f24493bcbc73bd7b8dd513868%26sd%3Dv2_708454af5ecb44b01dc61b48cc798c89_69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e_1624946718_1624946718_CIi3jgYQy7xLGPDt_LKlLyABKAEwEDiu_QZA8IUQSInB1wNQiZoCWABgAGiV8efG4eHrgl8%26ui%3D69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946718780e0m159T-9z11I1%7Cxcs%7C197%7Cxce%7C197%"
		"7Crc%7C204%7Crm%7CNo%20Content%2C2%7C14%7C_onload_%7C_load_%7C-%7C1624946721577%7C1624946721587%7Cdn%7C1389%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C1%7C17%7C_event_%7C1624946715171%7C_view_%7Csvn%7C%2F%7Csvt%7C1624946682624%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0$svrid=7$rId=RID_-909487734$rpId=-2036041045$domR=1624946721574$tvn=%2Fbanking$tvt=1624946715171$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1500$h=857$sw=1500$sh=1000$nt="
		"a0b1624946715171e4f4g4h4i4j4k8l451m453o2687p2687q2874r6403s6406t6416u21388v20496w168293M-2036041045$ni=4g|3.65$di=1$fd=j1.12.4^sb11-50$url=https%3A%2F%2Fwww.amp.com.au%2Fbanking$title=Banking%20-%20AMP%20Bank$latC=4$app=cd4697ba1bc4a478$visitID=KGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0$vs=2$fId=146715664_895$v=10217210531114014$vID=16249466784450Q0MQIFVSELV6Q8T30TVRP9L9CP81NSQ$time=1624946724389", 
		LAST);

	web_custom_request("rb_bf96747ztk_6", 
		"URL=https://www.amp.com.au/rb_bf96747ztk?app=cd4697ba1bc4a478;crc=2340602782;end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.amp.com.au/banking", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$svrid=7$tvn=%2Fbanking$tvt=1624946715171$tvm=i1%3Bk0%3Bh0$tvtrg=1$ni=4g|8.85$di=1$3p="
		"1-1624946715171%3Bassets.adobedtm.com%7C4%7C4%7C0%7C0%7C1%7C0%7C4%7C%7C0%7C0%7C0%7C485_485_546_2232_2687_2689_2693_2694%7C423%7C0%7C1686%3Bwww.amp.com.au%7Cu%7C12%7C0%7C0%7C7%7C0%7C12%7C%7C0%7C0%7C0%7C487_487_606_606_693_694_707_2590_6425_6428%7C425%7C0%7C1883%7C6%7C0%7C0%7C5%7C0%7C6%7C%7C0%7C0%7C0%7C485_486_611_611_2173_2545%7C62%7C0%7C372%7C4%7C0%7C0%7C3%7C485_489_616_616%7C1%7C0%7C4%7C10%7C0%7C0%7C5%7C658_658_663_663_665_665_667_667_669_669_714_2552_2705_3413_4301_4349_4355_4406_4712_4779%7C271"
		"%7C0%7C1837%3Bwww.google.com%7Ck%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C486_489%7C2%7C2%7C2%7C4%7C0%7C0%7C0%7C2868_3147_3612_6402%7C877%7C249%7C2671%3Bs.yimg.com%7Ck%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C572_2040%7C1468%7C1468%7C1468%7C1%7C0%7C0%7C0%7C2400_2433%7C33%7C33%7C33%3Bbat.bing.com%7Ck%7C2%7C0%7C0%7C0%7C0%7C2%7C%7C0%7C0%7C0%7C592_2041_2422_2437%7C732%7C15%7C1449%7C0%7C1%7C0%7C0%7C2941_3089%7C148%7C148%7C148%3Bampserviceslimited.tt.omtrdc.net%7Cg%7C1%7C0%7C0%7C0%7C604_2262%7C1658%7C16"
		"58%7C1658%3Byourir.info%7Cs%7C2%7C0%7C0%7C0%7C0%7C2%7C%7C0%7C0%7C0%7C611_2043_2407_2538%7C782%7C131%7C1433%7C1%7C0%7C0%7C0%7C2408_2437%7C29%7C29%7C29%7C2%7C0%7C0%7C0%7C3127_3172%7C24%7C3%7C45%3Bc.la1-c1-syd.salesforceliveagent.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C611_2405%7C1793%7C1793%7C1793%3Bajax.googleapis.com%7C4%7C1%7C0%7C0%7C1%7C0%7C1%7C%7C0%7C0%7C0%7C611_611%7C0%7C0%7C0%3Bhello.myfonts.net%7Cg%7C1%7C0%7C0%7C0%7C615_615%7C0%7C0%7C0%3Bfonts.googleapis.com%7Cg%7C1%7C0%7C0%7C1%7C61"
		"5_615%7C0%7C0%7C0%3Bfonts.gstatic.com%7Cg%7C2%7C0%7C0%7C2%7C651_652%7C0%7C0%7C0%3Bad.doubleclick.net%7Cg%7C1%7C0%7C0%7C0%7C677_2850%7C2173%7C2173%7C2173%3Bwww.gstatic.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C739_2078%7C1339%7C1339%7C1339%3Bsp.analytics.yahoo.com%7Cg%7C1%7C0%7C0%7C0%7C2631_2850%7C219%7C219%7C219%3Bconnect.facebook.net%7Ck%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C2669_2671%7C2%7C2%7C2%7C1%7C0%7C0%7C0%7C3190_3192%7C2%7C2%7C2%3Bd.la1-c1-syd.salesforceliveagent.com%7Cg%7C1%7C0%"
		"7C0%7C0%7C2853_2961%7C109%7C109%7C109%3Bamp.d2.sc.omtrdc.net%7Cg%7C1%7C0%7C0%7C0%7C2963_3149%7C186%7C186%7C186%3Bwww.googletagservices.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C3171_3174%7C3%7C3%7C3%3Bpagead2.googlesyndication.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C3172_3174%7C2%7C2%7C2%3Bgoogleads4.g.doubleclick.net%7Cg%7C1%7C0%7C0%7C0%7C3175_3337%7C161%7C161%7C161%3Bwww.googletagmanager.com%7Cg%7C4%7C0%7C0%7C0%7C3220_3222_3315_3319%7C3%7C2%7C4%3Bcdn.taboola.com%7C4%7C2%7C0%7C0%7"
		"C0%7C0%7C2%7C%7C0%7C0%7C0%7C3224_3226_3610_3939%7C166%7C2%7C329%3Bwww.facebook.com%7Cg%7C2%7C0%7C0%7C0%7C3275_5593%7C1171%7C23%7C2318%3Btrc.taboola.com%7Cg%7C2%7C0%7C0%7C0%7C3295_3537_3609_3768%7C201%7C159%7C242%3Bwww.googleadservices.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C3339_3341%7C2%7C2%7C2%3Bgoogleads.g.doubleclick.net%7Cg%7C3%7C0%7C0%7C0%7C3394_3688%7C227%7C148%7C292%3Bd2vj5tua97fz9h.cloudfront.net%7Cg%7C1%7C0%7C0%7C0%7C3548_4294%7C746%7C746%7C746%3Bwww.google.com.au%7Cg%7C3%7C0%7C"
		"0%7C0%7C3614_4129%7C356%7C332%7C397%3Bwww.sc.pages03.net%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C6409_6411%7C2%7C2%7C2%3Bwww.pages03.net%7C2%7C0%7C1%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C6453_9178%7C2725%7C2725%7C2725$rt="
		"1-1624946715171%3Bhttps%3A%2F%2Fassets.adobedtm.com%2F30cb14f656a0%2F7a08285d48a4%2Flaunch-36c302166c9d.min.js%7Cb485e0f0g0h0i0j0m0v98652w377849K1I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Fclientlib-site.css%7Cb485e0f0g0h0i0j0k1l1m4v43375w348255K1I11M-446851815%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc.clientlibs%2Fclientlibs%2Fgranite%2Fjquery.js%7Cb485e0f0g0h0i0j0m0v88042w294660K1I12M1038558126%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc.clientlibs%2Fclientlibs%2Fgranite%2Fut"
		"ils.js%7Cb485e0f0g0h0i0j0m0v10737w48607K1I12M-675004936%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc.clientlibs%2Fclientlibs%2Fgranite%2Fjquery%2Fgranite.js%7Cb485e0f0g0h0i0j0m0v973w2408K1I12M-1223847897%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Fswiftype-libs.js%7Cb486e0f0g0h0i0j0m0v8510w24519K1I12M254190841%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp%2FclientLibraries%2Ficons-libs.css%7Cb486e0f0g0h0i0j0m0v2180w11909K1I11M-831598683%7Chttps%3A%2F%2Fwww.amp.com.au%2Fet"
		"c%2Fdesigns%2Famp-au%2Fclientlibs%2Flegacy-nps.css%7Cb486e0f0g0h0i0j0m0v4872w38911K1I11M-1422456331%7Chttps%3A%2F%2Fwww.google.com%2Frecaptcha%2Fapi.js%3Frender%3D6Lf1YKQUAAAAAK3RIImnFOQrks8gZnrC7pObqn5q%7Cb486e0m2I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fdata%2Ficons%2Famp-logo-reversed.svg%7Cb487e0f0g0h0i0j0m0v205162w205162E1F6188O119P52I7M-1281867438%7Chttps%3A%2F%2Fassets.adobedtm.com%2Fextensions%2FEPbde2f7ca14e540399dcc1f8208860b7b%2FAppMeasurement.min.js%7Cb546e0f0g0h118"
		"i1530j1496k1531l1600m1686u378v12184w33462I12%7Chttps%3A%2F%2Fs.yimg.com%2Fwi%2Fytc.js%7Cb572e0m1468I12%7Chttps%3A%2F%2Fbat.bing.com%2Fbat.js%7Cb592e0m1449I12%7Chttps%3A%2F%2Fampserviceslimited.tt.omtrdc.net%2Frest%2Fv1%2Fdelivery%3Fclient%3Dampserviceslimited%26sessionId%3D3cc95b43f68748bfb93d005ba6dcfa05%26version%3D2.3.2%7Cb604e0m1658T-1z1I1%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fdata%2Ficons%2Famp-logo.svg%7Cb606e0f0g0h0i0j0m0v174276w174276N3O120P53Q284R125I7M-1231867539%7Cht"
		"tps%3A%2F%2Fyourir.info%2F61b218eca79bef95.js%7Cb611e0m1433I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Fclientlib-site.js%7Cb611e0f0g0h0i0j0m0v130526w431873K1I12M1189347597%7Chttps%3A%2F%2Fc.la1-c1-syd.salesforceliveagent.com%2Fcontent%2Fg%2Fjs%2F51.0%2Fdeployment.js%7Cb611e0m1793K1I12%7Chttps%3A%2F%2Fajax.googleapis.com%2Fajax%2Flibs%2Fwebfont%2F1.6%2Fwebfont.js%7Cb611e0f0g0h0i0j0m0v5437w13188K1I12%7Chttps%3A%2F%2Fhello.myfonts.net%2Fcount%2F3a2740%7Cb615e0m0I9%7Chtt"
		"ps%3A%2F%2Ffonts.googleapis.com%2Fcss%3Ffamily%3DOpen%2BSans%3A400italic%5Ec600italic%5Ec400%5Ec300%5Ec600%7Cb615e0f0g0h0i0j0m0v814w10371I9%7Chttps%3A%2F%2Fwww.amp.com.au%2Fddc%2Fpublic%2Fui%2Fassets%2Fddc-fonts%2Fddc-fonts.css%7Cb616e0f0g0h0i0j0m0v2043w10164I9M840765892%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs%2Fopensans%2Fv20%2Fmem8YaGs126MiZpBA-UFVZ0b.woff2%7Cb651e0f0g0h0i0j0m0v14440w14440I9%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs%2Fopensans%2Fv20%2Fmem5YaGs126MiZpBA-UNirkOUuhp.woff2%7Cb652e0f0g0h0i"
		"0j0m0v14956w14956I9%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2Fce62fa71a1a38af297b433e85d36d83f.woff2%7Cb658e0f0g0h0i0j0m0v76773w76773I9M1519948408%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F98c3ea22ad6bca213fa88175f7d9ffaf.woff2%7Cb663e0f0g0h0i0j0m0v96082w96082I9M-1892032532%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F33543c5cc5d88f5695dd08c87d280dfd.woff2%7Cb665e0f0g0h0i0j0m0v14380w14380I9M-1860783378%7Chttps%3A%2F%2Fwww.amp."
		"com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F819af3d3abdc9f135d49b80a91e2ff4c.woff2%7Cb667e0f0g0h0i0j0m0v14880w14880I9M-733586217%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F2525a15d1fb3ce824a7aad5e07ba2513.ttf%7Cb669e0f0g0h0i0j0m0v27480w27480I9M-835539285%7Chttps%3A%2F%2Fad.doubleclick.net%2Fddm%2Fadj%2FN962361.197812NSO.CODESRV%2FB22590592.244647881%5Essz%3D1x2%5Esord%3D275629320778%3F%7Cb677e0f0g0h1383i1890j1448k1908l2054m2173u8726v7778w20625K1I12%7Chttps%3A%2F%2Fwww.amp.co"
		"m.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Fbanner%2FBanking.svg%7Cb693e0f0g0h0i0j0m0v3076w3076I7M1715666691%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Fbanner%2Fhand-and-coin.svg%7Cb694e0f0g0h0i0j0m0v1205w1205I7M-1932096678%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Fbanner%2Fpiggy-bank-clock.svg%7Cb694e0f0g0h0i0j0m0v2386w2386I7M68765190%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Fbanner%"
		"2Fsmart-money.svg%7Cb694e0f0g0h0i0j0m0v1648w1648I7M1106042435%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fimages%2Fpage-banners%2Fbanner-product-15.jpg%7Cb707e0f0g0h0i0j0k1378l1462m1883u518019v516885w517205E1F651802O1483P440Q1920R503I9M1353598869%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fimages%2Fbanking-hub%2Fbanners%2Fkombi_5Fvan_5Fproduct_5Fpromo.jpg%7Cb710e0f0g0h0i0j0k1377l1470m1551u16578v15797w17703N3O493P276Q488I9M-803031890%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%"
		"2Fdesigns%2Famp-au%2Fassets%2F5c32de29c638fdf3bb4adc662a0ad595.woff2%7Cb714e0f0g0h0i0j0k1698l1755m1837u84114v83382w83382I9M-463698524%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fimages%2Fplaceholder%2FBusget_2520Planner_2520calculator_2520image.png.ampaurendition.1920.0.jpg%7Cb738e0f0g0h0i0j0k1356l1460m1666u73295v72441w85494I7M-681838337%7Chttps%3A%2F%2Fwww.gstatic.com%2Frecaptcha%2Freleases%2FeKRIyK-9MtX6JxeZcNZIkfUq%2Frecaptcha_5F_5Fen.js%7Cb739e0m1339I12%7Chttps%3A%2F%2Fwww.amp.co"
		"m.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Flegacy-nps.js%3F_5F%3D1624946715814%7Cb2173e0f0g0h0i0j0k236l319m372u10621v9770w50111T-2z1I1M-498705695%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fdata%2Fillustrations%2FCookies.svg%7Cb2185e0f0g0h0i0j0m0v1382w1382E1F1296O36P36Q150R150I7M-100836164%7Chttps%3A%2F%2Fs.yimg.com%2Fwi%2Fconfig%2F10092149.json%7Cb2400e0m33T-3z1I1%7Chttps%3A%2F%2Fyourir.info%2Flib%2F1.11.6%2Fyourir.js%7Cb2407e0m131I12%7Chttps%3A%2F%2Fyourir.info%2Flib%2F1.11.6%2Fy"
		"ourir.css%7Cb2408e0m29K1I11%7Chttps%3A%2F%2Fbat.bing.com%2Fp%2Faction%2F16012365.js%7Cb2422e0m15I12%7Chttps%3A%2F%2Fsp.analytics.yahoo.com%2Fsp.pl%7Cb2631e0m219N3O1P1I7%7Chttps%3A%2F%2Fconnect.facebook.net%2Fen_5FUS%2Ffbevents.js%7Cb2669e0m2I12%7Chttps%3A%2F%2Fassets.adobedtm.com%2F30cb14f656a0%2F7a08285d48a4%2F29c0db022c3d%2FRC3780d39ec03d45df99c03f86ac0bab9c-source.min.js%7Cb2687e0f0g0h0i0j0k2l2m2v413w717I12%7Chttps%3A%2F%2Fassets.adobedtm.com%2F30cb14f656a0%2F7a08285d48a4%2F29c0db022c3d%2FRC15a"
		"5c6f5e8cb4510b7d70763e430d359-source.min.js%7Cb2693e0f0g0h0i0j0k1l1m1v489w824I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fwps%2Fgws%2FNetPromoterScore%3FpageId%3Damp_253Abanking%7Cb2705e0f0g0h0i0j0k3l707m708u1138v259w312T-6z1I1M220796961%7Chttps%3A%2F%2Fd.la1-c1-syd.salesforceliveagent.com%2Fchat%2Frest%2FSystem%2FMultiNoun.jsonp%7Cb2853e0m109I12%7Chttps%3A%2F%2Fwww.google.com%2Frecaptcha%2Fapi2%2Fanchor%3Far%3D1%26k%3D6Lf1YKQUAAAAAK3RIImnFOQrks8gZnrC7pObqn5q%26co%3DaHR0cHM6Ly93d3cuYW1wLmNvbS5hdTo0NDM.%26"
		"hl%3Den%26v%3DeKRIyK-9MtX6JxeZcNZIkfUq%26size%3Dinvisible%26cb%3Dd8ntgfzedi49%7Cb2868e0m278F5220N1Bi0I4%7Chttps%3A%2F%2Fbat.bing.com%2Faction%2F0%7Cb2941e0m148A1N3I7%7Chttps%3A%2F%2Famp.d2.sc.omtrdc.net%2Fb%2Fss%2Famp-dtm-prd%2F1%2FJS-2.22.0-LBSQ%2Fs89864429528600%7Cb2963e0m186I7%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.asx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Cb3127e0m45T-7z1I1%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.nzx%3FappID%3D61b218eca79bef95%26livene"
		"ss%3Ddelayed%7Cb3152e0m3T-8z1I1%7Chttps%3A%2F%2Fwww.googletagservices.com%2Factiveview%2Fjs%2Fcurrent%2Frx_5Flidar.js%3Fcache%3Dr20110914%7Cb3171e0m3I12%7Chttps%3A%2F%2Fpagead2.googlesyndication.com%2Fpagead%2Fjs%2Fr20210624%2Fr20110914%2Felements%2Fhtml%2Fomrhp.js%7Cb3172e0f0g0h0i0j0k1l2m2v3124w7957K1I12%7Chttps%3A%2F%2Fgoogleads4.g.doubleclick.net%2Fpcs%2Fview%7Cb3175e0f0g0h0i0j0k3l161m161u818I3%7Chttps%3A%2F%2Fconnect.facebook.net%2Fsignals%2Fconfig%2F131169910928083%3Fv%3D2.9.42%26r%3Dstable%7"
		"Cb3190e0m2I12%7Chttps%3A%2F%2Fwww.googletagmanager.com%2Fgtag%2Fjs%3Fid%3DDC-8836193%7Cb3220e0m2I12%7Chttps%3A%2F%2Fcdn.taboola.com%2Flibtrc%2Funip%2F1236555%2Ftfa.js%7Cb3224e0m2I12%7Chttps%3A%2F%2Fwww.facebook.com%2Ftr%2F%7Cb3275e0m2318I7%7Chttps%3A%2F%2Fwww.facebook.com%2Ftr%2F%7Cb3275e0m23I7%7Chttps%3A%2F%2Ftrc.taboola.com%2F1236555%2Ftrc%2F3%2Fjson%7Cb3295e0m242I12%7Chttps%3A%2F%2Fwww.googletagmanager.com%2Fgtag%2Fjs%3Fid%3DAW-751278354%26l%3DdataLayer%26cx%3Dc%7Cb3315e0m2I12%7Chttps%3A%2F%2Fw"
		"ww.googletagmanager.com%2Fgtag%2Fjs%3Fid%3DAW-684022622%26l%3DdataLayer%26cx%3Dc%7Cb3315e0m4I12%7Chttps%3A%2F%2Fwww.googletagmanager.com%2Fgtag%2Fjs%3Fid%3DAW-711997817%26l%3DdataLayer%26cx%3Dc%7Cb3316e0m3I12%7Chttps%3A%2F%2Fwww.googleadservices.com%2Fpagead%2Fconversion_5Fasync.js%7Cb3339e0f0g0h0i0j0k1l1m2v14015w36813I12%7Chttps%3A%2F%2Fgoogleads.g.doubleclick.net%2Fpagead%2Fviewthroughconversion%2F751278354%2F%7Cb3394e0f0g0h0i0j0k3l138m148u2086v1046w2340K1I12%7Chttps%3A%2F%2Fgoogleads.g.doublecl"
		"ick.net%2Fpagead%2Fviewthroughconversion%2F684022622%2F%7Cb3397e0f0g0h0i0j0k140l291m292u2217v1046w2340K1I12%7Chttps%3A%2F%2Fgoogleads.g.doubleclick.net%2Fpagead%2Fviewthroughconversion%2F711997817%2F%7Cb3399e0f0g0h0i0j0k16l228m240u2055v1046w2342K1I12%7Chttps%3A%2F%2Fd2vj5tua97fz9h.cloudfront.net%2Fnuassist%2Frest%2Fin%2Fapi%2Famp_5Fnps_5Fv1%2Fsurvey%2F7QBD98FWDMDQKABHCQLGZ52QEX%7Cb3548e0m746T-5z1I1%7Chttps%3A%2F%2Ftrc.taboola.com%2F1236555%2Flog%2F3%2Funip%7Cb3609e0m159T-9z1I1%7Chttps%3A%2F%2Fcdn."
		"taboola.com%2Fscripts%2Fcds-pips.js%7Cb3610e0m329I12%7Chttps%3A%2F%2Fwww.google.com%2Fpagead%2F1p-user-list%2F751278354%2F%7Cb3612e0f0g0h0i0j0k76l296m309u768v42w42I7%7Chttps%3A%2F%2Fwww.google.com.au%2Fpagead%2F1p-user-list%2F751278354%2F%7Cb3614e0m332I7%7Chttps%3A%2F%2Fwww.google.com%2Fpagead%2F1p-user-list%2F711997817%2F%7Cb3690e0f0g0h0i0j0k100l248m249u768v42w42I7%7Chttps%3A%2F%2Fwww.google.com.au%2Fpagead%2F1p-user-list%2F711997817%2F%7Cb3691e0m338I7%7Chttps%3A%2F%2Fwww.google.com%2Fpagead%2F1p"
		"-user-list%2F684022622%2F%7Cb3731e0f0g0h0i0j0k2555l2671m2671u768v42w42I7%7Chttps%3A%2F%2Fwww.google.com.au%2Fpagead%2F1p-user-list%2F684022622%2F%7Cb3732e0m397I7%7Chttps%3A%2F%2Fwww.amp.com.au%2Fwps%2Fgws%2Fcom_5Famp_5Fportal_5Fnps%2Fnps.html%7Cb4301e0f0g0h0i0j0k3l48m48u1780v697w2375T-4z1I1M642068672%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp%2Fassets%2Ffonts%2Fxtreme.woff%7Cb4355e0f0g0h0i0j0k15l41m50u27177v26408w26408I9M2047052215%7Chttps%3A%2F%2Fwww.amp.com.au%2Fddc%2Fpublic%2Fui%2Fass"
		"ets%2Fddc-fonts%2Fddc-icons.ttf%7Cb4712e0f0g0h0i0j0k9l49m67u59096v58104w58104I9M-1675776017%7Chttps%3A%2F%2Fwww.sc.pages03.net%2Flp%2Fstatic%2Fjs%2FiMAWebCookie.js%3F18560ebc-14a40f8eab9-943e27de0c8b91cc3fcf1475c3e5d726%26h%3Dwww.pages03.net%7Cb6409e0m2K1I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Ffavicon.ico%7Cb6425e0f0g0h0i0j0k1l1m2v1406w1406I22M265790923%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Ffavicon.ico%7Cb6427e0f0g0h"
		"0i0j0k1l1m1v1406w1406I22M265790923%7Chttps%3A%2F%2Fwww.pages03.net%2FWTS%2Fevent.jpeg%7Cb6453e0m2725A1N3S2726I7$url=https%3A%2F%2Fwww.amp.com.au%2Fbanking$title=Banking%20-%20AMP%20Bank$latC=1$app=cd4697ba1bc4a478$visitID=KGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0$vs=2$fId=146715664_895$v=10217210531114014$vID=16249466784450Q0MQIFVSELV6Q8T30TVRP9L9CP81NSQ$time=1624946726451", 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("X-Goog-Update-AppId", 
		"ihnlcenocehgdaegdmhbidjhnhdchfmm,oimompecagnajdejgnnjijobebaeigek,obedbbhbpmojnkanicioggnmelmoomoc,cmahhnpholdijhjokonmfdjbfmklppij,lmelglejhemejginpboagddgdfbepgmp,kiabhabjdbkjdpjbpigfodbdjmbglcoo,hnimpnehoodheedghdeeijklkeaacbdc,giekcmmlnklenlaomppkphknjmnnpneh,dhlpobdgcjafebgbbhjdnapejmpkgiie,gcmjkmgdlgnkkcocmoeiminaijmmjnii,aemomkdncapdnfajjbbcbdebjljbpmpj,gkmgaooipdjhmangpemjhigmamcehddo,khaoiebndkojlmppeemjhbpbandiljpe,ehgidpndbllacpjalkiimkbadgjfnnmc,llkgjffcdpffmhiakmfcdcblohccpfmo,"
		"pdafiollngonhoadbmdoemagnfpdphbe,jflookgnkcckhobaglndicnbbgbonegd,ggkkehgbnfjpeggfpleeakpidbkibbmn,ojhpjlocmbogdgmfpkhlaaeamibhnphh,eeigpngbgcognadeebkilcpcaedhellh,hfnkpimlhhgieaddgfemjhofmfblmnib,jamhcnnkihinmdlkakkaopbjbbcngflc");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chrome-91.0.4472.114");

	web_custom_request("json_2", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=10:2142856295&cup2hreq=1ff27f0abd345aeedac80a805682ac0e125fdd789ddacabf49379068095f3ca3", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{273d0ff9-0591-4cb5-96f6-10924e213a0c}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{6e57a643-9581-4091-b0ad-563c41d83cd7"
		"}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"4.10.2209.0\"},{\"accept_locale\":\"ENGB\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"RXQR\",\"cohort\":\"1:s6f:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{a590c939-22eb-40bf-8776-1acd369d0edd}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"cmahhnpholdijhjokonmfdjbfmklppij\",\"brand\":\"RXQR\",\"cohort\":\"1:wr3:\",\"cohorthint\":\"Auto\",\"cohortname\""
		":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.b4ddbdce4f8d5c080328aa34c19cb533f2eedec580b5d97dc14f74935e4756b7\"}]},\"ping\":{\"ping_freshness\":\"{41aba2a1-6035-4e99-a27a-985216c98b75}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"1.0.6\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"RXQR\",\"cohort\":\"1:lwl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.d36e34ff48b9ee4a4361007c63aebae5f66afbf9379436f2649b414d802e1f5e\"}]},\"ping\":{\"ping_freshness\":\"{331b1165-2e9a-42a4-91fa-983d76191bda}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"286\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"RXQR\",\"enabled\":true,\"ping\":{\"r\":-2},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{ef633878-5b82-47c3-bf36-a3c3a1ec21df}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"RXQR\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\""
		"{454b2ba2-db21-443e-9a3f-dd765dc8a1fb}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"dhlpobdgcjafebgbbhjdnapejmpkgiie\",\"brand\":\"RXQR\",\"cohort\":\"1:z9x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3eeded944371798374de67d1fa7bb8f32f90a7cd502b04ee71e0de0cf79e2a11\"}]},\"ping\":{\"ping_freshness\":\"{c588c84d-6c85-4352-b228-b32a8f475c5d}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"20210609.1\"},{\"appid\":\""
		"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"RXQR\",\"cohort\":\"1:bm1:1069@0.01,1089@0.1\",\"cohorthint\":\"M54ToM99\",\"cohortname\":\"M54ToM99\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.91ee417000553ca22ed67530545c4177a08e7ffcf602c292a71bd89ecd0568a5\"}]},\"ping\":{\"ping_freshness\":\"{8eb53dda-414e-4620-81ee-ab1dd17ab6eb}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"9.28.0\"},{\"appid\":\"aemomkdncapdnfajjbbcbdebjljbpmpj\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\""
		":true,\"ping\":{\"ping_freshness\":\"{af234039-51f7-4a77-9b29-81a95bd51557}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"1.0.5.0\"},{\"appid\":\"gkmgaooipdjhmangpemjhigmamcehddo\",\"brand\":\"RXQR\",\"cohort\":\"1:pw3:\",\"cohorthint\":\"Stable\",\"cohortname\":\"Stable\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.704aaf12fe9f50a2721c64f17a6935718875b44033cfb6dd1f043f865d2fc052\"}]},\"ping\":{\"ping_freshness\":\"{11b6db4d-551f-46ec-b6a4-9c835ab8e02a}\",\"rd\":5292},\"tag\":\""
		"eset_exp_b\",\"updatecheck\":{},\"version\":\"91.263.200\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"RXQR\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.ffd1d2d75a8183b0a1081bd03a7ce1d140fded7a9fb52cf3ae864cd4d408ceb4\"}]},\"ping\":{\"ping_freshness\":\"{45fb3634-fba4-4cb1-a008-90133616ca03}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"43\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\""
		"brand\":\"RXQR\",\"cohort\":\"1:ofl:\",\"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{d913b367-55c3-483a-863b-b03f58402d73}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.2731bdeddb1470bf2f7ae9c585e7315be52a8ce98b8af698ece8e500426e378a\"}]},\"ping\":{\"ping_freshness\":\"{d2fe5a2e-b4a3-4a71-baef-4dd4074599d0}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"1.0.0.8\"},{\"appid\":\"pdafiollngonhoadbmdoemagnfpdphbe\",\"brand\":\"RXQR\",\"cohort\":\"1:vz3:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.baeb7c645c7704139756b02bf2741430d94ea3835fb1de77fef1057d8c844655\"}]},\"ping\":{\"ping_freshness\":\""
		"{57476a66-c44b-45b4-ad51-e48f746a0f74}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"2021.2.22.1142\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"RXQR\",\"cohort\":\"1:s7x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.c216fb19f03de50e1db698eb9df0550f6b1d0fc0f9cba19af2e7a8e55a8c1e7f\"}]},\"ping\":{\"ping_freshness\":\"{3ffe5d4c-a940-4a07-82f4-65bb6cb991d6}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"2655\"},{\""
		"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"RXQR\",\"cohort\":\"1:ut9:\",\"cohorthint\":\"M80ToM99\",\"cohortname\":\"M80ToM99\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.e03336cad15559578407db3fc7c08de34022cd38341bcf10f88b6ff93cf0d9b9\"}]},\"ping\":{\"ping_freshness\":\"{b859bca6-b23c-4bb8-a19b-b761cacc083c}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"2021.6.21.1141\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"RXQR\",\"cohort\":\"1:w0x:\",\""
		"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.478aa915e78878e332a0b4bb4d2a6fb67ff1c7f7b62fe906f47095ba5ae112d0\"}]},\"ping\":{\"ping_freshness\":\"{34536b1b-b878-4f6a-808b-c9c6abeaedc4}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"1\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"RXQR\",\"cohort\":\"1:w59:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{950f1d48-f395-4879-8127-23b5945ef6e9}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"RXQR\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.1f622a9619bd097a7bb81ea475b58ee977f5d6e9bb3f16d07f722c069aec2b37\"}]},\"ping\":{\"ping_freshness\""
		":\"{d88687da-bd9e-414d-8b0b-0c68c4c06c5f}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"6698\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"RXQR\",\"cohort\":\"1:wvr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6a6bd7badce42b5718a6737a358db760a8f130edbdcc8ada9c9cdee2b5e0153f\"}]},\"ping\":{\"ping_freshness\":\"{0236d73e-f056-41bd-adfc-9c7b8bb35711}\",\"rd\":5292},\"updatecheck\":{},\"version\":\"93.0.4557.4\"}],\"arch"
		"\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"physmemory\":8},\"lang\":\"en-GB\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.18363.1500\"},\"prodversion\":\"91.0.4472.114\",\"protocol\":\"3.1\",\"requestid\":\"{610a8986-bf34-4ee8-8ae7-f3ea75088d43}\",\"sessionid\":\"{f0490f76-45ef-4e36-b487-2b572bac96eb}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\""
		"updatepolicy\":-1,\"version\":\"1.3.36.82\"},\"updaterversion\":\"91.0.4472.114\"}}", 
		LAST);

	web_custom_request("json_3", 
		"URL=https://update.googleapis.com/service/update2/json", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"event\":[{\"download_time_ms\":4122,\"downloaded\":11136,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"2021.6.21.1\",\"previousversion\":\"0.0.0.0\",\"total\":11136,\"url\":\"http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/aHr5iG1xkBq3qFaqADC5PA_2021.6.21.1/OuEtkq2H3NgUO2sO-E5rJQ\"},{\"eventresult\":1,\""
		"eventtype\":3,\"nextfp\":\"1.3f9586c98c873f7ef653c121b08e729c35f4871bcd1181bdadb45e8199b7935c\",\"nextversion\":\"2021.6.21.1\",\"previousversion\":\"0.0.0.0\"}],\"version\":\"2021.6.21.1\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"hw\":{\"physmemory\":8},\"lang\":\"en-GB\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.18363.1500\"},\"prodversion\":\"91.0.4472.114\",\"protocol\":\"3.1\",\"requestid\":\"{5c95961e-6916-4c54-ae82-5bd6b270cac9}\",\""
		"sessionid\":\"{f0490f76-45ef-4e36-b487-2b572bac96eb}\",\"updaterversion\":\"91.0.4472.114\"}}", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Origin", 
		"https://www.amp.com.au");

	web_add_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_custom_request("rb_bf96747ztk_7", 
		"URL=https://www.amp.com.au/rb_bf96747ztk?app=cd4697ba1bc4a478;crc=4174553802;end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.amp.com.au/banking", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C18%7C_event_%7C1624946732998%7C_wv_%7CAAI%7C1%7CfIS%7C17822%7CfID%7C5%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0$svrid=7$rId=RID_-909487734$rpId=-2036041045$domR=1624946721574$tvn=%2Fbanking$tvt=1624946715171$tvm=i1%3Bk0%3Bh0$tvtrg=1$ni=4g|8.85$di=1$url=https%3A%2F%2Fwww.amp.com.au%2Fbanking$title=Banking%20-%20AMP%20Bank$latC=1$app=cd4697ba1bc4a478$visitID=KGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0$vs=2$fId=146715664_895$v=10217210531114014$vID=16249466784450Q0MQIFVSELV6Q8T30TVRP9L9CP81NSQ$time="
		"1624946735007", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_custom_request("json_4", 
		"URL=https://update.googleapis.com/service/update2/json", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"event\":[{\"download_time_ms\":4074,\"downloaded\":19026,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"2656\",\"previousversion\":\"2655\",\"total\":19026,\"url\":\"http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/AJJzcnk6toJWQnhfTskKN7c_2656/OxkWE_FYCSHBJpjNpenLjA\"},{\"eventresult\":1,\"eventtype\":3,\""
		"nextfp\":\"1.9fdd2a3fca96a98759c9befadc1906d5f5ee20c3ea6f8bf7fcc2b7aa7acb4244\",\"nextversion\":\"2656\",\"previousfp\":\"1.c216fb19f03de50e1db698eb9df0550f6b1d0fc0f9cba19af2e7a8e55a8c1e7f\",\"previousversion\":\"2655\"}],\"version\":\"2656\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"hw\":{\"physmemory\":8},\"lang\":\"en-GB\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.18363.1500\"},\"prodversion\":\"91.0.4472.114\",\"protocol\":\"3.1\",\"requestid"
		"\":\"{4bcb5c4c-edaf-4bbe-97cc-fd8aa8042f62}\",\"sessionid\":\"{f0490f76-45ef-4e36-b487-2b572bac96eb}\",\"updaterversion\":\"91.0.4472.114\"}}", 
		LAST);

	web_custom_request("json_5", 
		"URL=https://update.googleapis.com/service/update2/json", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"event\":[{\"download_time_ms\":4060,\"downloaded\":818376,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"93.0.4558.0\",\"previousversion\":\"93.0.4557.4\",\"total\":818376,\"url\":\"http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/cyXPLOLYrIscIRBrUWSxJw_93.0.4558.0/APwRNK6N6NIiu5FqdIRf6YA\"},{\"eventresult\":1,"
		"\"eventtype\":3,\"nextfp\":\"1.bbe0aeac658e0f51573b7b9400091b04c96139278c2f1629bf331d7869989e9e\",\"nextversion\":\"93.0.4558.0\",\"previousfp\":\"1.6a6bd7badce42b5718a6737a358db760a8f130edbdcc8ada9c9cdee2b5e0153f\",\"previousversion\":\"93.0.4557.4\"}],\"version\":\"93.0.4558.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"hw\":{\"physmemory\":8},\"lang\":\"en-GB\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.18363.1500\"},\"prodversion\":\""
		"91.0.4472.114\",\"protocol\":\"3.1\",\"requestid\":\"{490fd6c0-fe6d-4257-b7ef-ea66222b6318}\",\"sessionid\":\"{f0490f76-45ef-4e36-b487-2b572bac96eb}\",\"updaterversion\":\"91.0.4472.114\"}}", 
		LAST);

	lr_start_transaction("03_Click on Saving accounts");

	web_reg_find("Text=High Interest Saving Accounts - AMP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_url("savings-accounts", 
		"URL=https://www.amp.com.au/banking/savings-accounts", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.amp.com.au/banking", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../content/dam/amp-au/images/thumbnail/debit-card.jpg", ENDITEM, 
		"Url=../content/dam/amp-au/images/thumbnail/savings-calculator.jpg", ENDITEM, 
		"Url=../content/dam/amp-au/images/thumbnail/my-amp.jpg", ENDITEM, 
		"Url=../content/dam/amp-au/images/page-banners/banner-product-page-1.jpg", ENDITEM, 
		"Url=https://assets.adobedtm.com/extensions/EPbde2f7ca14e540399dcc1f8208860b7b/AppMeasurement.min.js", ENDITEM, 
		"Url=../etc/designs/amp-au/clientlibs/legacy-nps.js?_=1624946759643", ENDITEM, 
		"Url=https://ad.doubleclick.net/ddm/adj/N962361.197812NSO.CODESRV/B22590592.244647881;sz=1x2;ord=303830610296?", ENDITEM, 
		"Url=https://d.la1-c1-syd.salesforceliveagent.com/chat/rest/Visitor/Settings.jsonp?sid=2bfccc79-9c9b-4385-bbf9-66202b1350b7&Settings.prefix=Visitor&Settings.buttonIds=[5732P000000004W]&Settings.updateBreadcrumb=1&Settings.urlPrefix=undefined&callback=liveagent._.handlePing&deployment_id=5722P000000004b&org_id=00D7F0000001MC1&version=51", ENDITEM, 
		"Url=https://sp.analytics.yahoo.com/sp.pl?a=10000&d=Tue%2C%2029%20Jun%202021%2006%3A06%3A01%20GMT&n=-10&b=High%20Interest%20Saving%20Accounts%20-%20AMP&.yp=10092149&f=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&e=https%3A%2F%2Fwww.amp.com.au%2Fbanking&enc=UTF-8&yv=1.10.1&tagmgr=adobe", ENDITEM, 
		"Url=https://www.facebook.com/tr/?id=131169910928083&ev=ViewContent&dl=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&rl=https%3A%2F%2Fwww.amp.com.au%2Fbanking&if=false&ts=1624946761835&sw=1500&sh=1000&v=2.9.42&r=stable&ec=1&o=28&fbp=fb.2.1624946684859.99642261&it=1624946761582&coo=false&rqm=GET", ENDITEM, 
		"Url=https://www.facebook.com/tr/?id=131169910928083&ev=PageView&dl=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&rl=https%3A%2F%2Fwww.amp.com.au%2Fbanking&if=false&ts=1624946761831&sw=1500&sh=1000&v=2.9.42&r=stable&ec=0&o=28&fbp=fb.2.1624946684859.99642261&it=1624946761582&coo=false&rqm=GET", ENDITEM, 
		"Url=https://trc.taboola.com/1236555/trc/3/json?tim=1624946761872&data="
		"%7B%22id%22%3A766%2C%22ii%22%3A%22%2Fbanking%2Fsavings-accounts%22%2C%22it%22%3A%22video%22%2C%22sd%22%3A%22v2_708454af5ecb44b01dc61b48cc798c89_69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e_1624946718_1624946718_CIi3jgYQy7xLGPDt_LKlLyABKAEwEDiu_QZA8IUQSInB1wNQiZoCWABgAGiV8efG4eHrgl8%22%2C%22ui%22%3A%2269eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e%22%2C%22vi%22%3A1624946761863%2C%22cv%22%3A%2220210615-3-RELEASE%22%2C%22uiv%22%3A%22default%22%2C%22u%22%3A%22https%3A%2F%2Fwww.amp.com.au%2Fbanki"
		"ng%2Fsavings-accounts%22%2C%22e%22%3A%22https%3A%2F%2Fwww.amp.com.au%2Fbanking%22%2C%22cb%22%3A%22TFASC.trkCallback%22%2C%22qs%22%3A%22%22%2C%22r%22%3A%5B%7B%22li%22%3A%22rbox-tracking%22%2C%22s%22%3A0%2C%22uim%22%3A%22rbox-tracking%3Apub%3Dreprisemelb-amp-au-sc%3Aabp%3D0%22%2C%22uip%22%3A%22rbox-tracking%22%2C%22orig_uip%22%3A%22rbox-tracking%22%7D%5D%2C%22mpv%22%3Atrue%2C%22mpvd%22%3A%7B%22en%22%3A%22page_view%22%2C%22item-url%22%3A%22https%3A%2F%2Fwww.amp.com.au%2Fbanking%22%2C%22tim%22%3A16249"
		"46761871%2C%22ref%22%3A%22https%3A%2F%2Fwww.amp.com.au%2Fbanking%22%2C%22tos%22%3A68515%2C%22ssd%22%3A3%2C%22scd%22%3A25%7D%7D&pubit=i", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/684022622/?random=1624946762125&cv=9&fst=1624946762125&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=2505059651&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=3&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&ref=https%3A%2F%2Fwww.amp.com.au%2Fbanking&tiba=High%20Interest%20Saving%20Accounts%20-%20AMP&hn="
		"www.googleadservices.com&async=1&rfmt=3&fmt=4", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/711997817/?random=1624946762129&cv=9&fst=1624946762129&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=3&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&ref=https%3A%2F%2Fwww.amp.com.au%2Fbanking&tiba=High%20Interest%20Saving%20Accounts%20-%20AMP&hn="
		"www.googleadservices.com&async=1&rfmt=3&fmt=4", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/751278354/?random=1624946762131&cv=9&fst=1624946762131&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=3&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&ref=https%3A%2F%2Fwww.amp.com.au%2Fbanking&tiba=High%20Interest%20Saving%20Accounts%20-%20AMP&hn="
		"www.googleadservices.com&async=1&rfmt=3&fmt=4", ENDITEM, 
		"Url=https://trc.taboola.com/1236555/log/3/unip?en=page_view&item-url=https%3A%2F%2Fwww.amp.com.au%2Fbanking&tim=1624946761871&ui=69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e&ref=https%3A%2F%2Fwww.amp.com.au%2Fbanking&cv=20210615-3-RELEASE&tos=68859&ssd=3&scd=25&vi=1624946761863&ri=6118ecf4764ed802ce8b500e39ffcad2&sd=v2_708454af5ecb44b01dc61b48cc798c89_69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e_1624946718_1624946762_CIi3jgYQy7xLGIfB_7KlLyACKAEwEDiu_QZA8IUQSInB1wNQiZoCWABgAGiV8efG4eHrgl8", ENDITEM, 
		"Url=https://cdn.taboola.com/scripts/cds-pips.js", ENDITEM, 
		"Url=https://www.google.com/pagead/1p-user-list/711997817/?random=1624946762129&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=3&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&ref=https%3A%2F%2Fwww.amp.com.au%2Fbanking&tiba=High%20Interest%20Saving%20Accounts%20-%20AMP&async=1&fmt=3&is_vtc=1&random=3018688525&resp="
		"GooglemKTybQhCsO&rmt_tld=0&ipr=y", ENDITEM, 
		"Url=https://www.google.com/pagead/1p-user-list/751278354/?random=1624946762131&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=3&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&ref=https%3A%2F%2Fwww.amp.com.au%2Fbanking&tiba=High%20Interest%20Saving%20Accounts%20-%20AMP&async=1&fmt=3&is_vtc=1&random=392791038&resp="
		"GooglemKTybQhCsO&rmt_tld=0&ipr=y", ENDITEM, 
		"Url=https://www.google.com/pagead/1p-user-list/684022622/?random=1624946762125&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=2505059651&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=3&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&ref=https%3A%2F%2Fwww.amp.com.au%2Fbanking&tiba=High%20Interest%20Saving%20Accounts%20-%20AMP&async=1&fmt=3&is_vtc=1&random=3255784202&resp="
		"GooglemKTybQhCsO&rmt_tld=0&ipr=y", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s87327566055510?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A6%3A1%202%20-600&sdid=30A363A18B18FC4D-52A25489DDD5D573&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=banking%3Asavings%20accounts&g=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&r=https%3A%2F%2Fwww.amp.com.au%2Fbanking&cc=AUD&ch=amp&events=event75%3D23&aamb=6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y&c1"
		"=web&v1=D%3Dc1&h1=banking%7Csavings%20accounts&c2=banking&v2=D%3Dc2&c3=banking%3Asavings%20accounts&v3=D%3Dc3&v6=false&v7=banking%3Asavings%20accounts&c12=1624946761522&v12=4%3A06PM%7C4%3A00PM%7CTuesday%7C29%2F6%2F2021&c16=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&v16=D%3Dc16&c30=23569144125047983874531016401195797023&v30=D%3Dc30&c32=banking&c33=25&v46=savings-accounts&v47=personal&v49=consideration&c74=AMP%20PUBLIC%20SITE%20Launch&c75=23&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh="
		"857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&AQE=1", ENDITEM, 
		"Url=https://www.pages03.net/WTS/event.jpeg?accesskey=18560ebc-14a40f8eab9-943e27de0c8b91cc3fcf1475c3e5d726&v=1.31&isNewSession=0&type=pageview&isNewVisitor=0&sessionGUID=bb945113-85bc-a875-4ddc-6479ec5c1c79&webSyncID=ac130211-93c1-63b2-1ca5-a0d58d000ac2&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&newSiteVisit=0&referringURL=https%3A%2F%2Fwww.amp.com.au%2Fbanking&hostname=www.amp.com.au&pathname=%2Fbanking%2Fsavings-accounts&newPageVisit=1&eventKey="
		"4151ddae-5061-c540-660a-25095d342236", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s86904118399947?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A6%3A35%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=banking%3Asavings%20accounts&g=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&cc=AUD&events=event52&c28=banking%3Asavings%20accounts%3Aproduct-cards%20cta%3AAMP%20Saver%20Account%3ALearn%20more&v28=D%3Dc28&pe=lnk_o&pev1="
		"https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&pev2=product-cards%20cta%3ALearn%20more&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=2728&AQE=1", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_custom_request("0_4", 
		"URL=https://bat.bing.com/actionp/0?ti=16012365&Ver=2&mid=788691d3-6609-4a79-a2eb-73b79bc044bd&sid=e6578fe0d89f11eb98165deac4f355a8&vid=e657ca70d89f11eb8fe68f742e2032a1&vids=0&evt=pageHide", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/banking", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_custom_request("delivery_4", 
		"URL=https://ampserviceslimited.tt.omtrdc.net/rest/v1/delivery?client=ampserviceslimited&sessionId=3cc95b43f68748bfb93d005ba6dcfa05&version=2.3.2", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t48.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body={\"requestId\":\"624b0fe00f2d46cd983eb46ba1406b38\",\"context\":{\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36\",\"timeOffsetInMinutes\":600,\"channel\":\"web\",\"screen\":{\"width\":1500,\"height\":1000,\"orientation\":\"landscape\",\"colorDepth\":24,\"pixelRatio\":1},\"window\":{\"width\":1500,\"height\":857},\"browser\":{\"host\":\"www.amp.com.au\",\"webGLRenderer\":\"Google SwiftShader\"},\"address\":{\""
		"url\":\"https://www.amp.com.au/banking/savings-accounts\",\"referringUrl\":\"https://www.amp.com.au/banking\"}},\"id\":{\"tntId\":\"3cc95b43f68748bfb93d005ba6dcfa05.36_0\",\"marketingCloudVisitorId\":\"23569144125047983874531016401195797023\"},\"experienceCloud\":{\"audienceManager\":{\"locationHint\":8,\"blob\":\"6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y\"},\"analytics\":{\"logging\":\"server_side\",\"supplementalDataId\":\"30A363A18B18FC4D-52A25489DDD5D573\",\"trackingServer\":\""
		"amp.d2.sc.omtrdc.net\",\"trackingServerSecure\":\"amp.d2.sc.omtrdc.net\"}},\"execute\":{\"pageLoad\":{\"parameters\":{\"user.categoryId\":\"banking\"},\"profileParameters\":{\"pageName\":\"banking:savings accounts\"}}},\"prefetch\":{\"views\":[{\"parameters\":{\"user.categoryId\":\"banking\"},\"profileParameters\":{\"pageName\":\"banking:savings accounts\"}}]}}", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_url("0_5", 
		"URL=https://bat.bing.com/action/0?ti=16012365&Ver=2&mid=03606a67-d2ab-49c0-94bb-a840672ad93b&sid=e6578fe0d89f11eb98165deac4f355a8&vid=e657ca70d89f11eb8fe68f742e2032a1&vids=0&pi=1200101525&lg=en-GB&sw=1500&sh=1000&sc=24&tl=High%20Interest%20Saving%20Accounts%20-%20AMP&p=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&r=https%3A%2F%2Fwww.amp.com.au%2Fbanking&lt=2163&evt=pageLoad&msclkid=N&sv=1&rn=854295", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://fonts.gstatic.com/s/opensans/v20/mem5YaGs126MiZpBA-UN_r8OUuhp.woff2", "Referer=https://fonts.googleapis.com/", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Origin", 
		"https://www.amp.com.au");

	web_custom_request("view_3", 
		"URL=https://googleads4.g.doubleclick.net/pcs/view?xai=AKAOjstXpjQNNxv_GF-rJrlyTcweYywx65i3CwwQhnUSl6S6JJJX9RYgiOgZv5KHb9EMoNKNWBIEMClgzyC46wuBxUlhAdLsklHQ2c_p3Vh_jL6R3M2tjnlHgIhV9o9brRKP&sig=Cg0ArKJSzLVMO4dlYBUOEAE&fbs_aeid=[gw_fbsaeid]&urlfix=1&omid=0&rm=1&ctpt=2&cbvp=1&cisv=r20210624.45348&adurl=", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t50.inf", 
		"EncType=text/plain;charset=UTF-8", 
		LAST);

	web_reg_find("Text=reCAPTCHA", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"iframe");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("anchor_3", 
		"URL=https://www.google.com/recaptcha/api2/anchor?ar=1&k=6Lf1YKQUAAAAAK3RIImnFOQrks8gZnrC7pObqn5q&co=aHR0cHM6Ly93d3cuYW1wLmNvbS5hdTo0NDM.&hl=en&v=eKRIyK-9MtX6JxeZcNZIkfUq&size=invisible&cb=w9z0i87xkfcn", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t51.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"https://www.amp.com.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_url("amp.asx_3", 
		"URL=https://yourir.info/api/v5/symbols/amp.asx?appID=61b218eca79bef95&liveness=delayed", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t52.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_header("x-dtpc", 
		"7$146759505_475h5vKGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0e4");

	web_url("NetPromoterScore_3", 
		"URL=https://www.amp.com.au/wps/gws/NetPromoterScore?pageId=amp%3Abanking%3Asavings-accounts&userIdentifier=27405bde14c20c2e40f716f95415ce9b", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t53.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_url("cds.taboola.com", 
		"URL=https://cds.taboola.com/?uid=69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e&src=tfa", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t54.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_url("pips.taboola.com", 
		"URL=https://pips.taboola.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t55.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_add_header("Access-Control-Request-Headers", 
		"content-type,x-requested-with");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_custom_request("7QBD98FWDMDQKABHCQLGZ52QEX_3", 
		"URL=https://d2vj5tua97fz9h.cloudfront.net/nuassist/rest/in/api/amp_nps_v1/survey/7QBD98FWDMDQKABHCQLGZ52QEX", 
		"Method=OPTIONS", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t56.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_custom_request("7QBD98FWDMDQKABHCQLGZ52QEX_4", 
		"URL=https://d2vj5tua97fz9h.cloudfront.net/nuassist/rest/in/api/amp_nps_v1/survey/7QBD98FWDMDQKABHCQLGZ52QEX", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t57.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"npsSessionId\":\"6e1b3a44-0b22-430c-aff1-379aa4aeb8ae\",\"parameters\":[{\"key\":\"channelname\",\"value\":\"anon-portal\"},{\"key\":\"device\",\"value\":\"desktop\"},{\"key\":\"browser\",\"value\":\"Chrome/91.0\"},{\"key\":\"pageId\",\"value\":\"amp:banking:savings-accounts\"}]}", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("x-dtpc", 
		"7$146759505_475h13vKGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0e4");

	web_url("nps.html_2", 
		"URL=https://www.amp.com.au/wps/gws/com_amp_portal_nps/nps.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t58.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_url("cds.taboola.com_2", 
		"URL=https://cds.taboola.com/?uid=69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t59.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_custom_request("rb_bf96747ztk_8", 
		"URL=https://www.amp.com.au/rb_bf96747ztk?app=cd4697ba1bc4a478;crc=2076986225;end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t60.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a="
		"d%7C-1%7CSavings%20accounts%7CC%7C-%7C146715664_895%7C1624946758306%7Chttps%3A%2F%2Fwww.amp.com.au%2Fbanking%7CBanking%20-%20AMP%20Bank%7C%7C%2Fbanking%7C1624946715171%2C1%7C1%7C_load_%7C_load_%7C-%7C1624946759265%7C1624946765441%7Cdn%7C1265%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Clr%7Chttps%3A%2F%2Fwww.amp.com.au%2Fbanking%2C2%7C14%7C_event_%7C1624946759265%7C_vc_%7CV%7C6165%5Epc%7CVCD%7C2929%7CVCDS%7C10%7CVCS%7C6233%7CVCO%7C7250%7CVCI%7C0%7CVE%7C1313%5Ep313%5Ep540"
		"%5Eps%5Esspan.icon.icon--plus.icon--plus-rotated%7CS%7C613%2C2%7C15%7C_event_%7C1624946759265%7C_wv_%7ClcpE%7CDIV%7ClcpSel%7Cdiv.banner-wrapper.banner-wrapper--image%7ClcpS%7C652520%7ClcpT%7C2305%7ClcpU%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fimages%2Fpage-banners%2Fbanner-product-page-1.jpg%7Cfcp%7C2223%7Cfp%7C2223%7Ccls%7C0.021%7Clt%7C4021%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C2%7C2%7Cx%7Cxhr%7Cx%7C1624946759602%7C1624946761367%7Cdn%7C1197%7Cxu%7Chttps%3A%2F%2Fampserviceslimited"
		".tt.omtrdc.net%2Frest%2Fv1%2Fdelivery%3Fclient%3Dampserviceslimited%26sessionId%3D3cc95b43f68748bfb93d005ba6dcfa05%26version%3D2.3.2%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946759606e0m412T-1z11I1%7Cxcs%7C1765%7Cxce%7C1765%2C2%7C3%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946759784%7C1624946761390%7Cdn%7C1206%7Cxu%7C%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Flegacy-nps.js%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb162494676"
		"0062e0f0g0h0i0j0k67l1288m1291u10621v9770w50111T-2z11I1M1950570371%7Cxcs%7C1602%7Cxce%7C1607%2C2%7C4%7Cx%7Cxhr%7Cx%7C1624946761362%7C1624946761558%7Cdn%7C1207%7Cxu%7Chttps%3A%2F%2Fs.yimg.com%2Fwi%2Fconfig%2F10092149.json%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946761365e0m1T-3z11I1%7Cxcs%7C192%7Cxce%7C196%2C2%7C5%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946761406%7C1624946765428%7Cdn%7C1265%7Cxu%7C%2Fwps%2Fgws%2FNetPromoterScore%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0"
		"%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946761413e0f0g0h0i0j0k3l2671m2672u1139v259w312T-6z11I1M-387784139%7Cxcs%7C2819%7Cxce%7C2834%2C3%7C10%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946764234%7C1624946765428%7Cdn%7C1265%7Cxu%7Chttps%3A%2F%2Fd2vj5tua97fz9h.cloudfront.net%2Fnuassist%2Frest%2Fin%2Fapi%2Famp_nps_v1%2Fsurvey%2F7QBD98FWDMDQKABHCQLGZ52QEX%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946764239e0m1140T-5z11I1%7Cxcs%7C1146%7Cxce%7C1153%2C4"
		"%7C13%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946765381%7C1624946765428%7Cdn%7C1265%7Cxu%7C%2Fwps%2Fgws%2Fcom_amp_portal_nps%2Fnps.html%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946765387e0f0g0h0i0j0k3l37m38u476v697w2375T-4z11I1M642068672%7Cxcs%7C45%7Cxce%7C49%2C2%7C6%7Cx%7Cxhr%7Cx%7C1624946761779%7C1624946762084%7Cdn%7C1226%7Cxu%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.asx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Csvtrg%7C1%7Csvm%7Ci1"
		"%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946761783e0m172T-7z11I1%7Cxcs%7C304%7Cxce%7C305%2C2%7C7%7Cx%7Cxhr%7Cx%7C1624946761783%7C1624946761839%7Cdn%7C1214%7Cxu%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.nzx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946761788e0m1T-8z11I1%7Cxcs%7C54%7Cxce%7C56%2C2%7C8%7Cx%7Cxhr%7Cx%7C1624946762215%7C1624946762408%7Cdn%7C1230%7Cxu%7Chttps%3A%2F%2Ft"
		"rc.taboola.com%2F1236555%2Flog%2F3%2Funip%3Fen%3Dpage_view%26item-url%3Dhttps%253A%252F%252Fwww.amp.com.au%252Fbanking%26tim%3D1624946761871%26ui%3D69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e%26ref%3Dhttps%253A%252F%252Fwww.amp.com.au%252Fbanking%26cv%3D20210615-3-RELEASE%26tos%3D68859%26ssd%3D3%26scd%3D25%26vi%3D1624946761863%26ri%3D6118ecf4764ed802ce8b500e39ffcad2%26sd%3Dv2_708454af5ecb44b01dc61b48cc798c89_69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e_1624946718_1624946762_CIi3jgYQy7xLGI"
		"fB_7KlLyACKAEwEDiu_QZA8IUQSInB1wNQiZoCWABgAGiV8efG4eHrgl8%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946762219e0m185T-9z11I1%7Cxcs%7C193%7Cxce%7C193%7Crc%7C204%7Crm%7CNo%20Content%2C2%7C9%7Cx%7Cxhr%7Cx%7C1624946762444%7C1624946764562%7Cdn%7C1231%7Cxu%7Chttps%3A%2F%2Fpips.taboola.com%2F%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946764211e0m346T-10z11I1%7Cxcs%7C2117%7Cxce%7C2118%2C2%7C11%7C_onload_%7C_load_%7C-%7C162494"
		"6764542%7C1624946764548%7Cdn%7C1231%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C2%7C12%7Cx%7Cxhr%7Cx%7C1624946764562%7C1624946765441%7Cdn%7C1265%7Cxu%7Chttps%3A%2F%2Fcds.taboola.com%2F%3Fuid%3D69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946764565e0m874T-11z11I1%7Cxcs%7C879%7Cxce%7C879%7Crc%7C204%7Crm%7CNo%20Content%2C1%7C16%7C_event_%7C1624946759265%7C_view_%7Csvn%7C%2Fbanking%7Csvt%"
		"7C1624946715171%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0$svrid=7$rId=RID_-788520561$rpId=-666574319$domR=1624946764435$tvn=%2Fbanking%2Fsavings-accounts$tvt=1624946759265$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1500$h=857$sw=1500$sh=1000$nt=a0b1624946759265e4f4g4h4i4j4k7l91m93o2126p2126q2163r5170s5277t5283u20735v19844w158926M-666574319$ni=4g|8.85$di=1$fd=j1.12.4^sb11-50$url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts$title="
		"High%20Interest%20Saving%20Accounts%20-%20AMP$latC=4$app=cd4697ba1bc4a478$visitID=KGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0$vs=2$fId=146759505_475$v=10217210531114014$vID=16249466784450Q0MQIFVSELV6Q8T30TVRP9L9CP81NSQ$time=1624946768460", 
		LAST);

	lr_end_transaction("03_Click on Saving accounts",LR_AUTO);

	web_custom_request("rb_bf96747ztk_9", 
		"URL=https://www.amp.com.au/rb_bf96747ztk?app=cd4697ba1bc4a478;crc=1917520707;end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t61.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a=1%7C17%7C_event_%7C1624946769952%7C_wv_%7CAAI%7C1%7CfIS%7C10684%7CfID%7C3%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0$svrid=7$rId=RID_-788520561$rpId=-666574319$domR=1624946764435$tvn=%2Fbanking%2Fsavings-accounts$tvt=1624946759265$tvm=i1%3Bk0%3Bh0$tvtrg=1$ni=4g|8.85$di=1$url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts$title=High%20Interest%20Saving%20Accounts%20-%20AMP$latC=1$app=cd4697ba1bc4a478$visitID=KGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0$vs=2$fId=146759505_475$v="
		"10217210531114014$vID=16249466784450Q0MQIFVSELV6Q8T30TVRP9L9CP81NSQ$time=1624946770454", 
		LAST);

	web_custom_request("rb_bf96747ztk_10", 
		"URL=https://www.amp.com.au/rb_bf96747ztk?app=cd4697ba1bc4a478;crc=1262334387;end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t62.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$svrid=7$tvn=%2Fbanking%2Fsavings-accounts$tvt=1624946759265$tvm=i1%3Bk0%3Bh0$tvtrg=1$ni=4g|8.85$di=1$3p="
		"1-1624946759265%3Bassets.adobedtm.com%7C4%7C4%7C0%7C0%7C1%7C0%7C4%7C%7C0%7C0%7C0%7C231_231_289_796_2127_2131%7C128%7C0%7C507%3Bwww.amp.com.au%7Cu%7C9%7C0%7C0%7C3%7C0%7C9%7C%7C0%7C0%7C0%7C235_235_343_343_424_861_5286_5293_5315_5317%7C158%7C0%7C438%7C6%7C0%7C0%7C5%7C0%7C6%7C%7C0%7C0%7C0%7C231_233_349_349_797_2088%7C215%7C0%7C1291%7C4%7C0%7C0%7C3%7C231_234_356_356%7C1%7C0%7C3%7C13%7C0%7C0%7C11%7C387_387_419_419_2135_2135_2148_4820_6122_6159%7C209%7C0%7C2672%3Bwww.google.com%7Ck%7C1%7C0%7C0%7C0%7C0%7C"
		"1%7C%7C0%7C0%7C0%7C234_236%7C2%7C2%7C2%7C4%7C0%7C0%7C0%7C2356_2801_3147_5050%7C1410%7C445%7C1874%3Bs.yimg.com%7Ck%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C309_407%7C98%7C98%7C98%7C1%7C0%7C0%7C0%7C2100_2101%7C1%7C1%7C1%3Bbat.bing.com%7Ck%7C2%7C0%7C0%7C0%7C0%7C2%7C%7C0%7C0%7C0%7C328_410_2229_2231%7C42%7C2%7C82%7C0%7C1%7C0%7C0%7C2243_2393%7C150%7C150%7C150%3Bampserviceslimited.tt.omtrdc.net%7Cg%7C1%7C0%7C0%7C0%7C341_752%7C412%7C412%7C412%3Byourir.info%7Cs%7C2%7C0%7C0%7C0%7C0%7C2%7C%7C0%7C0%7C0%7C348_"
		"410_2221_2225%7C33%7C4%7C62%7C1%7C0%7C0%7C0%7C2222_2224%7C2%7C2%7C2%7C2%7C0%7C0%7C0%7C2518_2690%7C87%7C1%7C172%3Bc.la1-c1-syd.salesforceliveagent.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C351_351%7C0%7C0%7C0%3Bajax.googleapis.com%7C4%7C1%7C0%7C0%7C1%7C0%7C1%7C%7C0%7C0%7C0%7C351_351%7C0%7C0%7C0%3Bhello.myfonts.net%7Cg%7C1%7C0%7C0%7C0%7C355_355%7C0%7C0%7C0%3Bfonts.googleapis.com%7Cg%7C1%7C0%7C0%7C1%7C355_355%7C0%7C0%7C0%3Bfonts.gstatic.com%7Cg%7C3%7C0%7C0%7C2%7C386_387_433_2505%7C691%7C0%7C20"
		"72%3Bad.doubleclick.net%7Cg%7C1%7C0%7C0%7C0%7C395_2089%7C1694%7C1694%7C1694%3Bwww.gstatic.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C494_861%7C367%7C367%7C367%3Bconnect.facebook.net%7Ck%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C866_2091%7C1225%7C1225%7C1225%7C1%7C0%7C0%7C0%7C2318_2320%7C2%7C2%7C2%3Bd.la1-c1-syd.salesforceliveagent.com%7Cg%7C1%7C0%7C0%7C0%7C2163_2393%7C230%7C230%7C230%3Bwww.googletagservices.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C2272_2276%7C4%7C4%7C4%3Bpagead2.googl"
		"esyndication.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C2273_2277%7C4%7C4%7C4%3Bgoogleads4.g.doubleclick.net%7Cg%7C1%7C0%7C0%7C0%7C2277_2436%7C159%7C159%7C159%3Bsp.analytics.yahoo.com%7Cg%7C1%7C0%7C0%7C0%7C2293_2415%7C122%7C122%7C122%3Bwww.googletagmanager.com%7Cg%7C4%7C0%7C0%7C0%7C2379_2382_2628_2635%7C4%7C3%7C6%3Bcdn.taboola.com%7C4%7C2%7C0%7C0%7C0%7C0%7C2%7C%7C0%7C0%7C0%7C2386_2395_2955_3142%7C98%7C9%7C186%3Bamp.d2.sc.omtrdc.net%7Cg%7C1%7C0%7C0%7C0%7C2430_5153%7C2722%7C2722%7C2722%3Bwww.f"
		"acebook.com%7Cg%7C2%7C0%7C0%7C0%7C2570_2801%7C228%7C225%7C231%3Btrc.taboola.com%7Cg%7C2%7C0%7C0%7C0%7C2611_2948_2954_3138%7C261%7C185%7C337%3Bcds.taboola.com%7Cg%7C2%7C0%7C0%7C0%7C2613_5167_5300_6174%7C1715%7C874%7C2555%3Bwww.googleadservices.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C2697_2756%7C59%7C59%7C59%3Bgoogleads.g.doubleclick.net%7Cg%7C3%7C0%7C0%7C0%7C2863_3140%7C275%7C272%7C277%3Bwww.google.com.au%7Cg%7C3%7C0%7C0%7C0%7C3147_5127%7C1863%7C1806%7C1951%3Bpips.taboola.com%7Cg%7C1%7C0%7"
		"C0%7C0%7C4946_5292%7C346%7C346%7C346%3Bd2vj5tua97fz9h.cloudfront.net%7Cg%7C1%7C0%7C0%7C0%7C4974_6114%7C1140%7C1140%7C1140%3Bwww.sc.pages03.net%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C5278_5280%7C2%7C2%7C2%3Bwww.pages03.net%7C2%7C0%7C1%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C5342_9157%7C3815%7C3815%7C3815$rt="
		"1-1624946759265%3Bhttps%3A%2F%2Fassets.adobedtm.com%2F30cb14f656a0%2F7a08285d48a4%2Flaunch-36c302166c9d.min.js%7Cb231e0f0g0h0i0j0m0v98652w377849K1I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Fclientlib-site.css%7Cb231e0f0g0h0i0j0k1l1m3v43375w348255K1I11M-446851815%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc.clientlibs%2Fclientlibs%2Fgranite%2Fjquery.js%7Cb231e0f0g0h0i0j0m0v88042w294660K1I12M1038558126%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc.clientlibs%2Fclientlibs%2Fgranite%2Fut"
		"ils.js%7Cb231e0f0g0h0i0j0m0v10737w48607K1I12M-675004936%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc.clientlibs%2Fclientlibs%2Fgranite%2Fjquery%2Fgranite.js%7Cb232e0f0g0h0i0j0m0v973w2408K1I12M-1223847897%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Fswiftype-libs.js%7Cb233e0f0g0h0i0j0m0v8510w24519K1I12M254190841%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp%2FclientLibraries%2Ficons-libs.css%7Cb233e0f0g0h0i0j0m0v2180w11909K1I11M-831598683%7Chttps%3A%2F%2Fwww.amp.com.au%2Fet"
		"c%2Fdesigns%2Famp-au%2Fclientlibs%2Flegacy-nps.css%7Cb234e0f0g0h0i0j0m0v4872w38911K1I11M-1422456331%7Chttps%3A%2F%2Fwww.google.com%2Frecaptcha%2Fapi.js%3Frender%3D6Lf1YKQUAAAAAK3RIImnFOQrks8gZnrC7pObqn5q%7Cb234e0m2I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fdata%2Ficons%2Famp-logo-reversed.svg%7Cb235e0f0g0h0i0j0m0v205162w205162E1F6188O119P52I7M-1281867438%7Chttps%3A%2F%2Fassets.adobedtm.com%2Fextensions%2FEPbde2f7ca14e540399dcc1f8208860b7b%2FAppMeasurement.min.js%7Cb289e0f0g0h80i"
		"225j153k409l475m507u378v12184w33462I12%7Chttps%3A%2F%2Fs.yimg.com%2Fwi%2Fytc.js%7Cb309e0m98I12%7Chttps%3A%2F%2Fbat.bing.com%2Fbat.js%7Cb328e0m82I12%7Chttps%3A%2F%2Fampserviceslimited.tt.omtrdc.net%2Frest%2Fv1%2Fdelivery%3Fclient%3Dampserviceslimited%26sessionId%3D3cc95b43f68748bfb93d005ba6dcfa05%26version%3D2.3.2%7Cb341e0m412T-1z1I1%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fdata%2Ficons%2Famp-logo.svg%7Cb343e0f0g0h0i0j0m0v174276w174276N3O120P53Q284R125I7M-1231867539%7Chttps%3A%2F%2"
		"Fyourir.info%2F61b218eca79bef95.js%7Cb348e0m62I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Fclientlib-site.js%7Cb349e0f0g0h0i0j0m0v130526w431873K1I12M1189347597%7Chttps%3A%2F%2Fc.la1-c1-syd.salesforceliveagent.com%2Fcontent%2Fg%2Fjs%2F51.0%2Fdeployment.js%7Cb351e0m0K1I12%7Chttps%3A%2F%2Fajax.googleapis.com%2Fajax%2Flibs%2Fwebfont%2F1.6%2Fwebfont.js%7Cb351e0f0g0h0i0j0m0v5437w13188K1I12%7Chttps%3A%2F%2Fhello.myfonts.net%2Fcount%2F3a2740%7Cb355e0m0I9%7Chttps%3A%2F%2Ffonts"
		".googleapis.com%2Fcss%3Ffamily%3DOpen%2BSans%3A400italic%5Ec600italic%5Ec400%5Ec300%5Ec600%7Cb355e0f0g0h0i0j0m0v814w10371I9%7Chttps%3A%2F%2Fwww.amp.com.au%2Fddc%2Fpublic%2Fui%2Fassets%2Fddc-fonts%2Fddc-fonts.css%7Cb356e0f0g0h0i0j0m0v2043w10164I9M840765892%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs%2Fopensans%2Fv20%2Fmem8YaGs126MiZpBA-UFVZ0b.woff2%7Cb386e0f0g0h0i0j0m0v14440w14440I9%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs%2Fopensans%2Fv20%2Fmem5YaGs126MiZpBA-UNirkOUuhp.woff2%7Cb387e0f0g0h0i0j0m0v14956w1495"
		"6I9%7Chttps%3A%2F%2Fwww.amp.com.au%2Fddc%2Fpublic%2Fui%2Fassets%2Fddc-fonts%2Fddc-icons.ttf%7Cb387e0f0g0h0i0j0m0v58104w58104I9M-1675776017%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F5c32de29c638fdf3bb4adc662a0ad595.woff2%7Cb387e0f0g0h0i0j0m0v83382w83382I9M-463698524%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2Fce62fa71a1a38af297b433e85d36d83f.woff2%7Cb387e0f0g0h0i0j0m0v76773w76773I9M1519948408%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fa"
		"ssets%2F98c3ea22ad6bca213fa88175f7d9ffaf.woff2%7Cb387e0f0g0h0i0j0m0v96082w96082I9M-1892032532%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F33543c5cc5d88f5695dd08c87d280dfd.woff2%7Cb387e0f0g0h0i0j0m0v14380w14380I9M-1860783378%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F819af3d3abdc9f135d49b80a91e2ff4c.woff2%7Cb387e0f0g0h0i0j0m0v14880w14880I9M-733586217%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F2525a15d1fb3ce824a7aad5e07ba2513.ttf"
		"%7Cb387e0f0g0h0i0j0m0v27480w27480I9M-835539285%7Chttps%3A%2F%2Fad.doubleclick.net%2Fddm%2Fadj%2FN962361.197812NSO.CODESRV%2FB22590592.244647881%5Essz%3D1x2%5Esord%3D303830610296%3F%7Cb395e0f0g0h17i357j60k395l1692m1694u8735v7787w20600K1I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp%2Fassets%2Ffonts%2Fxtreme.woff%7Cb419e0f0g0h0i0j0m0v26408w26408I9M2047052215%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fimages%2Fpage-banners%2Fbanner-product-page-1.jpg%7Cb424e0f0g0h0i0j0k45l268"
		"m438u281070v280097w281079E1F651802O1483P440Q1920I9M1354076578%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fimages%2Fthumbnail%2Fmy-amp.jpg%7Cb429e0f0g0h0i0j0k31l249m336u17390v16609w16798N3O389P276Q488I9M1238990580%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fimages%2Fthumbnail%2Fdebit-card.jpg%7Cb430e0f0g0h0i0j0k29l111m311u14480v13699w13869N3O389P276Q488I9M1412084723%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fimages%2Fthumbnail%2Fsavings-calculator.jpg%7Cb4"
		"30e0f0g0h0i0j0k38l237m325u22609v21828w21977N3O389P276Q488I9M-103777653%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs%2Fopensans%2Fv20%2Fmem5YaGs126MiZpBA-UN_5Fr8OUuhp.woff2%7Cb433e0f0g0h437i1899j1767k1899l2023m2072u15755v14992w14992I9%7Chttps%3A%2F%2Fwww.gstatic.com%2Frecaptcha%2Freleases%2FeKRIyK-9MtX6JxeZcNZIkfUq%2Frecaptcha_5F_5Fen.js%7Cb494e0m367I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Flegacy-nps.js%3F_5F%3D1624946759643%7Cb797e0f0g0h0i0j0k67l1288m1291u10621v9770w5011"
		"1T-2z1I1M1950570371%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fdata%2Fillustrations%2FCookies.svg%7Cb799e0f0g0h0i0j0m0v1382w1382E1F1296O36P36Q150R150I7M-100836164%7Chttps%3A%2F%2Fconnect.facebook.net%2Fen_5FUS%2Ffbevents.js%7Cb866e0m1225I12%7Chttps%3A%2F%2Fs.yimg.com%2Fwi%2Fconfig%2F10092149.json%7Cb2100e0m1T-3z1I1%7Chttps%3A%2F%2Fassets.adobedtm.com%2F30cb14f656a0%2F7a08285d48a4%2F29c0db022c3d%2FRC3780d39ec03d45df99c03f86ac0bab9c-source.min.js%7Cb2127e0f0g0h0i0j0k1l1m2v413w717I12%7"
		"Chttps%3A%2F%2Fassets.adobedtm.com%2F30cb14f656a0%2F7a08285d48a4%2F29c0db022c3d%2FRC15a5c6f5e8cb4510b7d70763e430d359-source.min.js%7Cb2130e0f0g0h0i0j0k1l1m1v489w824I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp%2Fassets%2Ffonts%2Fxtreme.woff%7Cb2135e0f0g0h0i0j0m0v26408w26408I9M2047052215%7Chttps%3A%2F%2Fwww.amp.com.au%2Fwps%2Fgws%2FNetPromoterScore%3FpageId%3Damp_253Abanking_253Asavings-accounts%26userIdentifier%3D27405bde14c20c2e40f716f95415ce9b%7Cb2148e0f0g0h0i0j0k3l2671m2672u1139v259w"
		"312T-6z1I1M-387784139%7Chttps%3A%2F%2Fd.la1-c1-syd.salesforceliveagent.com%2Fchat%2Frest%2FVisitor%2FSettings.jsonp%7Cb2163e0m230I12%7Chttps%3A%2F%2Fyourir.info%2Flib%2F1.11.6%2Fyourir.js%7Cb2221e0m4I12%7Chttps%3A%2F%2Fyourir.info%2Flib%2F1.11.6%2Fyourir.css%7Cb2222e0m2K1I11%7Chttps%3A%2F%2Fbat.bing.com%2Fp%2Faction%2F16012365.js%7Cb2229e0m2I12%7Chttps%3A%2F%2Fbat.bing.com%2Faction%2F0%7Cb2243e0m150A1N3I7%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp%2Fassets%2Ffonts%2Fxtreme.woff%7Cb2261e0"
		"f0g0h0i0j0m0v26408w26408I9M2047052215%7Chttps%3A%2F%2Fwww.googletagservices.com%2Factiveview%2Fjs%2Fcurrent%2Frx_5Flidar.js%3Fcache%3Dr20110914%7Cb2272e0m4I12%7Chttps%3A%2F%2Fpagead2.googlesyndication.com%2Fpagead%2Fjs%2Fr20210624%2Fr20110914%2Felements%2Fhtml%2Fomrhp.js%7Cb2273e0f0g0h0i0j0k3l3m4v3124w7957K1I12%7Chttps%3A%2F%2Fgoogleads4.g.doubleclick.net%2Fpcs%2Fview%7Cb2277e0f0g0h0i0j0k3l159m159u818I3%7Chttps%3A%2F%2Fsp.analytics.yahoo.com%2Fsp.pl%7Cb2293e0m122N3O1P1I7%7Chttps%3A%2F%2Fconnect.fa"
		"cebook.net%2Fsignals%2Fconfig%2F131169910928083%3Fv%3D2.9.42%26r%3Dstable%7Cb2318e0m2I12%7Chttps%3A%2F%2Fwww.google.com%2Frecaptcha%2Fapi2%2Fanchor%3Far%3D1%26k%3D6Lf1YKQUAAAAAK3RIImnFOQrks8gZnrC7pObqn5q%26co%3DaHR0cHM6Ly93d3cuYW1wLmNvbS5hdTo0NDM.%26hl%3Den%26v%3DeKRIyK-9MtX6JxeZcNZIkfUq%26size%3Dinvisible%26cb%3Dw9z0i87xkfcn%7Cb2356e0m445F5220N1Bi0I4%7Chttps%3A%2F%2Fwww.googletagmanager.com%2Fgtag%2Fjs%3Fid%3DDC-8836193%7Cb2379e0m3I12%7Chttps%3A%2F%2Fcdn.taboola.com%2Flibtrc%2Funip%2F1236555%2Ftf"
		"a.js%7Cb2386e0m9I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp%2Fassets%2Ffonts%2Fxtreme.woff%7Cb2399e0f0g0h0i0j0m0v26408w26408I9M2047052215%7Chttps%3A%2F%2Famp.d2.sc.omtrdc.net%2Fb%2Fss%2Famp-dtm-prd%2F1%2FJS-2.22.0-LBSQ%2Fs87327566055510%7Cb2430e0m2722I7%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.asx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Cb2518e0m172T-7z1I1%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.nzx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%"
		"7Cb2523e0m1T-8z1I1%7Chttps%3A%2F%2Fwww.facebook.com%2Ftr%2F%7Cb2570e0m231I7%7Chttps%3A%2F%2Fwww.facebook.com%2Ftr%2F%7Cb2570e0m225I7%7Chttps%3A%2F%2Ftrc.taboola.com%2F1236555%2Ftrc%2F3%2Fjson%7Cb2611e0m337I12%7Chttps%3A%2F%2Fcds.taboola.com%2F%3Fuid%3D69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e%26src%3Dtfa%7Cb2613e0m2555I7%7Chttps%3A%2F%2Fwww.googletagmanager.com%2Fgtag%2Fjs%3Fid%3DAW-751278354%26l%3DdataLayer%26cx%3Dc%7Cb2628e0m3I12%7Chttps%3A%2F%2Fwww.googletagmanager.com%2Fgtag%2Fjs%3Fid%3"
		"DAW-684022622%26l%3DdataLayer%26cx%3Dc%7Cb2629e0m6I12%7Chttps%3A%2F%2Fwww.googletagmanager.com%2Fgtag%2Fjs%3Fid%3DAW-711997817%26l%3DdataLayer%26cx%3Dc%7Cb2630e0m5I12%7Chttps%3A%2F%2Fwww.googleadservices.com%2Fpagead%2Fconversion_5Fasync.js%7Cb2697e0f0g0h0i0j0k5l15m59v14015w36813I12%7Chttps%3A%2F%2Fgoogleads.g.doubleclick.net%2Fpagead%2Fviewthroughconversion%2F684022622%2F%7Cb2863e0f0g0h0i0j0k3l238m277u2183v1073w2436K1I12%7Chttps%3A%2F%2Fgoogleads.g.doubleclick.net%2Fpagead%2Fviewthroughconversion"
		"%2F711997817%2F%7Cb2865e0f0g0h0i0j0k8l258m275u2211v1073w2436K1I12%7Chttps%3A%2F%2Fgoogleads.g.doubleclick.net%2Fpagead%2Fviewthroughconversion%2F751278354%2F%7Cb2867e0f0g0h0i0j0k6l270m272u2173v1073w2434K1I12%7Chttps%3A%2F%2Ftrc.taboola.com%2F1236555%2Flog%2F3%2Funip%7Cb2954e0m185T-9z1I1%7Chttps%3A%2F%2Fcdn.taboola.com%2Fscripts%2Fcds-pips.js%7Cb2955e0m186I12%7Chttps%3A%2F%2Fwww.google.com%2Fpagead%2F1p-user-list%2F711997817%2F%7Cb3147e0f0g0h0i0j0k3l1671m1673u768v42w42I7%7Chttps%3A%2F%2Fwww.google."
		"com.au%2Fpagead%2F1p-user-list%2F711997817%2F%7Cb3147e0m1831I7%7Chttps%3A%2F%2Fwww.google.com%2Fpagead%2F1p-user-list%2F751278354%2F%7Cb3172e0f0g0h0i0j0k7l1645m1647u768v42w42I7%7Chttps%3A%2F%2Fwww.google.com.au%2Fpagead%2F1p-user-list%2F751278354%2F%7Cb3173e0m1806I7%7Chttps%3A%2F%2Fwww.google.com%2Fpagead%2F1p-user-list%2F684022622%2F%7Cb3175e0f0g0h0i0j0k1753l1874m1874u768v42w42I7%7Chttps%3A%2F%2Fwww.google.com.au%2Fpagead%2F1p-user-list%2F684022622%2F%7Cb3176e0m1951I7%7Chttps%3A%2F%2Fpips.taboola"
		".com%2F%7Cb4946e0m346T-10z1I1%7Chttps%3A%2F%2Fd2vj5tua97fz9h.cloudfront.net%2Fnuassist%2Frest%2Fin%2Fapi%2Famp_5Fnps_5Fv1%2Fsurvey%2F7QBD98FWDMDQKABHCQLGZ52QEX%7Cb4974e0m1140T-5z1I1%7Chttps%3A%2F%2Fwww.sc.pages03.net%2Flp%2Fstatic%2Fjs%2FiMAWebCookie.js%3F18560ebc-14a40f8eab9-943e27de0c8b91cc3fcf1475c3e5d726%26h%3Dwww.pages03.net%7Cb5278e0m2K1I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Ffavicon.ico%7Cb5286e0f0g0h0i0j0k6l6m7v1406w1406I22M265790923%7Chttps%3A%2F%"
		"2Fcds.taboola.com%2F%3Fuid%3D69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e%7Cb5300e0m874T-11z1I1%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Ffavicon.ico%7Cb5315e0f0g0h0i0j0k1l1m2v1406w1406I22M265790923%7Chttps%3A%2F%2Fwww.pages03.net%2FWTS%2Fevent.jpeg%7Cb5342e0m3815A1N3S3818I7%7Chttps%3A%2F%2Fwww.amp.com.au%2Fwps%2Fgws%2Fcom_5Famp_5Fportal_5Fnps%2Fnps.html%7Cb6122e0f0g0h0i0j0k3l37m38u476v697w2375T-4z1I1M642068672$url="
		"https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts$title=High%20Interest%20Saving%20Accounts%20-%20AMP$latC=1$app=cd4697ba1bc4a478$visitID=KGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0$vs=2$fId=146759505_475$v=10217210531114014$vID=16249466784450Q0MQIFVSELV6Q8T30TVRP9L9CP81NSQ$time=1624946770601", 
		LAST);

	lr_start_transaction("04_Click on AMP saver account_learn more");

	web_revert_auto_header("Origin");

	web_reg_find("Text=AMP Saver Account - AMP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("amp-saver-account", 
		"URL=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t63.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://assets.adobedtm.com/extensions/EPbde2f7ca14e540399dcc1f8208860b7b/AppMeasurement.min.js", ENDITEM, 
		"Url=/content/dam/amp-au/authoring/promotion-banner/banner-background-2.jpg", ENDITEM, 
		"Url=/etc/designs/amp-au/clientlibs/legacy-nps.js?_=1624946796555", ENDITEM, 
		"Url=https://assets.adobedtm.com/30cb14f656a0/7a08285d48a4/29c0db022c3d/RCdec9800f73ea4a7e826731b56050a137-source.min.js", ENDITEM, 
		"Url=https://sp.analytics.yahoo.com/sp.pl?a=10000&d=Tue%2C%2029%20Jun%202021%2006%3A06%3A37%20GMT&n=-10&b=AMP%20Saver%20Account%20-%20AMP&.yp=10092149&f=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&e=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&enc=UTF-8&yv=1.10.1&tagmgr=adobe", ENDITEM, 
		"Url=https://ad.doubleclick.net/ddm/adj/N962361.197812NSO.CODESRV/B22590592.244647881;sz=1x2;ord=934547106417?", ENDITEM, 
		"Url=https://www.facebook.com/tr/?id=131169910928083&ev=ViewContent&dl=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&rl=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&if=false&ts=1624946797362&sw=1500&sh=1000&v=2.9.42&r=stable&ec=1&o=28&fbp=fb.2.1624946684859.99642261&it=1624946797288&coo=false&rqm=GET", ENDITEM, 
		"Url=https://www.facebook.com/tr/?id=131169910928083&ev=PageView&dl=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&rl=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&if=false&ts=1624946797359&sw=1500&sh=1000&v=2.9.42&r=stable&ec=0&o=28&fbp=fb.2.1624946684859.99642261&it=1624946797288&coo=false&rqm=GET", ENDITEM, 
		"Url=https://trc.taboola.com/1236555/trc/3/json?tim=1624946797662&data="
		"%7B%22id%22%3A631%2C%22ii%22%3A%22%2Fbanking%2Fsavings-accounts%2Famp-saver-account%22%2C%22it%22%3A%22video%22%2C%22sd%22%3A%22v2_708454af5ecb44b01dc61b48cc798c89_69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e_1624946718_1624946762_CIi3jgYQy7xLGIfB_7KlLyACKAEwEDiu_QZA8IUQSInB1wNQiZoCWABgAGiV8efG4eHrgl8%22%2C%22ui%22%3A%2269eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e%22%2C%22vi%22%3A1624946797640%2C%22cv%22%3A%2220210615-3-RELEASE%22%2C%22uiv%22%3A%22default%22%2C%22u%22%3A%22https%3A%2F%2Fww"
		"w.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account%22%2C%22e%22%3A%22https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%22%2C%22cb%22%3A%22TFASC.trkCallback%22%2C%22qs%22%3A%22%22%2C%22r%22%3A%5B%7B%22li%22%3A%22rbox-tracking%22%2C%22s%22%3A0%2C%22uim%22%3A%22rbox-tracking%3Apub%3Dreprisemelb-amp-au-sc%3Aabp%3D0%22%2C%22uip%22%3A%22rbox-tracking%22%2C%22orig_uip%22%3A%22rbox-tracking%22%7D%5D%2C%22mpv%22%3Atrue%2C%22mpvd%22%3A%7B%22en%22%3A%22page_view%22%2C%22item-url%22%3A%22ht"
		"tps%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%22%2C%22tim%22%3A1624946797661%2C%22ref%22%3A%22https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%22%2C%22tos%22%3A102935%2C%22ssd%22%3A4%2C%22scd%22%3A27%7D%7D&pubit=i", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s89098107275091?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A6%3A37%202%20-600&sdid=1B4E6B6346B9E491-0155CB70FA9E9300&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=banking%3Asavings%20accounts%3Aamp%20saver%20account&g=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&r=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&cc=AUD&ch=amp&events="
		"event75%3D14&aamb=6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y&c1=web&v1=D%3Dc1&h1=banking%7Csavings%20accounts%7Camp%20saver%20account&c2=banking&v2=D%3Dc2&c3=banking%3Asavings%20accounts&v3=D%3Dc3&v6=false&v7=banking%3Asavings%20accounts%3Aamp%20saver%20account&c12=1624946797234&v12=4%3A06PM%7C4%3A00PM%7CTuesday%7C29%2F6%2F2021&c16=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&v16=D%3Dc16&c30=23569144125047983874531016401195797023&v30=D%3Dc30&c32="
		"banking%3Asavings%20accounts&c33=27&v46=savings-accounts&v47=personal&v48=money-basics&v49=intent&c74=AMP%20PUBLIC%20SITE%20Launch&c75=14&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&AQE=1", ENDITEM, 
		"Url=https://trc.taboola.com/1236555/log/3/unip?en=page_view&item-url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&tim=1624946797661&ui=69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e&ref=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&cv=20210615-3-RELEASE&tos=103217&ssd=4&scd=27&vi=1624946797640&ri=30cb7f76d9d6019f3da262c68a2f8525&sd="
		"v2_708454af5ecb44b01dc61b48cc798c89_69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e_1624946718_1624946797_CIi3jgYQy7xLGMjYgbOlLyADKAEwEDiu_QZA8IUQSInB1wNQiZoCWABgAGiV8efG4eHrgl8", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/684022622/?random=1624946799717&cv=9&fst=1624946799717&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=2505059651&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=4&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&ref=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&tiba="
		"AMP%20Saver%20Account%20-%20AMP&hn=www.googleadservices.com&async=1&rfmt=3&fmt=4", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/711997817/?random=1624946799722&cv=9&fst=1624946799722&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=4&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&ref=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&tiba="
		"AMP%20Saver%20Account%20-%20AMP&hn=www.googleadservices.com&async=1&rfmt=3&fmt=4", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/751278354/?random=1624946799724&cv=9&fst=1624946799724&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=4&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&ref=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&tiba="
		"AMP%20Saver%20Account%20-%20AMP&hn=www.googleadservices.com&async=1&rfmt=3&fmt=4", ENDITEM, 
		"Url=https://cdn.taboola.com/scripts/cds-pips.js", ENDITEM, 
		"Url=https://www.google.com/pagead/1p-user-list/684022622/?random=1624946799717&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=2505059651&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=4&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&ref=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&tiba=AMP%20Saver%20Account%20-%20AMP&async=1&fmt=3&is_vtc=1&random="
		"1295916563&resp=GooglemKTybQhCsO&rmt_tld=0&ipr=y", ENDITEM, 
		"Url=https://www.google.com/pagead/1p-user-list/751278354/?random=1624946799724&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=4&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&ref=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&tiba=AMP%20Saver%20Account%20-%20AMP&async=1&fmt=3&is_vtc=1&random="
		"1406533966&resp=GooglemKTybQhCsO&rmt_tld=0&ipr=y", ENDITEM, 
		"Url=https://www.google.com/pagead/1p-user-list/711997817/?random=1624946799722&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=4&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&ref=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&tiba=AMP%20Saver%20Account%20-%20AMP&async=1&fmt=3&is_vtc=1&random="
		"752091571&resp=GooglemKTybQhCsO&rmt_tld=0&ipr=y", ENDITEM, 
		"Url=/content/dam/amp-au/data/icons/doc-pdf.svg", ENDITEM, 
		"Url=https://www.pages03.net/WTS/event.jpeg?accesskey=18560ebc-14a40f8eab9-943e27de0c8b91cc3fcf1475c3e5d726&v=1.31&isNewSession=0&type=pageview&isNewVisitor=0&sessionGUID=bb945113-85bc-a875-4ddc-6479ec5c1c79&webSyncID=ac130211-93c1-63b2-1ca5-a0d58d000ac2&url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&newSiteVisit=0&referringURL=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&hostname=www.amp.com.au&pathname="
		"%2Fbanking%2Fsavings-accounts%2Famp-saver-account&newPageVisit=1&eventKey=ae61b55b-8286-7a33-81de-d58977263908", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s82944808237515?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A7%3A6%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=banking%3Asavings%20accounts%3Aamp%20saver%20account&g=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&cc=AUD&events=event52&c28="
		"banking%3Asavings%20accounts%3Aamp%20saver%20account%3Abanner%20cta%3AAMP%20Saver%20Account%3AOpen%20an%20account&v28=D%3Dc28&pe=lnk_o&pev1=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&pev2=banner%20cta%3AOpen%20an%20account&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=301&AQE=1", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_custom_request("0_6", 
		"URL=https://bat.bing.com/actionp/0?ti=16012365&Ver=2&mid=03606a67-d2ab-49c0-94bb-a840672ad93b&sid=e6578fe0d89f11eb98165deac4f355a8&vid=e657ca70d89f11eb8fe68f742e2032a1&vids=0&evt=pageHide", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/banking/savings-accounts", 
		"Snapshot=t64.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		EXTRARES, 
		"Url=https://fonts.gstatic.com/s/opensans/v20/memnYaGs126MiZpBA-UFUKXGUdhrIqM.woff2", "Referer=https://fonts.googleapis.com/", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_custom_request("delivery_5", 
		"URL=https://ampserviceslimited.tt.omtrdc.net/rest/v1/delivery?client=ampserviceslimited&sessionId=3cc95b43f68748bfb93d005ba6dcfa05&version=2.3.2", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t65.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body={\"requestId\":\"eb04f2ec7cc8447d92c75197a67880d0\",\"context\":{\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36\",\"timeOffsetInMinutes\":600,\"channel\":\"web\",\"screen\":{\"width\":1500,\"height\":1000,\"orientation\":\"landscape\",\"colorDepth\":24,\"pixelRatio\":1},\"window\":{\"width\":1500,\"height\":857},\"browser\":{\"host\":\"www.amp.com.au\",\"webGLRenderer\":\"Google SwiftShader\"},\"address\":{\""
		"url\":\"https://www.amp.com.au/banking/savings-accounts/amp-saver-account\",\"referringUrl\":\"https://www.amp.com.au/banking/savings-accounts\"}},\"id\":{\"tntId\":\"3cc95b43f68748bfb93d005ba6dcfa05.36_0\",\"marketingCloudVisitorId\":\"23569144125047983874531016401195797023\"},\"experienceCloud\":{\"audienceManager\":{\"locationHint\":8,\"blob\":\"6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y\"},\"analytics\":{\"logging\":\"server_side\",\"supplementalDataId\":\""
		"1B4E6B6346B9E491-0155CB70FA9E9300\",\"trackingServer\":\"amp.d2.sc.omtrdc.net\",\"trackingServerSecure\":\"amp.d2.sc.omtrdc.net\"}},\"execute\":{\"pageLoad\":{\"parameters\":{\"user.categoryId\":\"banking\"},\"profileParameters\":{\"pageName\":\"banking:savings accounts:amp saver account\"}}},\"prefetch\":{\"views\":[{\"parameters\":{\"user.categoryId\":\"banking\"},\"profileParameters\":{\"pageName\":\"banking:savings accounts:amp saver account\"}}]}}", 
		EXTRARES, 
		"Url=https://fonts.gstatic.com/s/opensans/v20/mem6YaGs126MiZpBA-UFUK0Zdc0.woff2", "Referer=https://fonts.googleapis.com/", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_url("0_7", 
		"URL=https://bat.bing.com/action/0?ti=16012365&Ver=2&mid=217769c3-696d-4727-8b54-dd591df0ba94&sid=e6578fe0d89f11eb98165deac4f355a8&vid=e657ca70d89f11eb8fe68f742e2032a1&vids=0&pi=1200101525&lg=en-GB&sw=1500&sh=1000&sc=24&tl=AMP%20Saver%20Account%20-%20AMP&p=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account&r=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts&lt=1261&evt=pageLoad&msclkid=N&sv=1&rn=377713", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t66.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_find("Text=reCAPTCHA", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"iframe");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("anchor_4", 
		"URL=https://www.google.com/recaptcha/api2/anchor?ar=1&k=6Lf1YKQUAAAAAK3RIImnFOQrks8gZnrC7pObqn5q&co=aHR0cHM6Ly93d3cuYW1wLmNvbS5hdTo0NDM.&hl=en&v=eKRIyK-9MtX6JxeZcNZIkfUq&size=invisible&cb=6hd1aaxjj69l", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t67.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"https://www.amp.com.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_url("amp.asx_4", 
		"URL=https://yourir.info/api/v5/symbols/amp.asx?appID=61b218eca79bef95&liveness=delayed", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t68.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_header("x-dtpc", 
		"7$146796357_665h5vKGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0e5");

	web_url("NetPromoterScore_4", 
		"URL=https://www.amp.com.au/wps/gws/NetPromoterScore?pageId=amp%3Abanking%3Asavings-accounts%3Aamp-saver-account&userIdentifier=27405bde14c20c2e40f716f95415ce9b", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t69.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_add_header("Access-Control-Request-Headers", 
		"content-type,x-requested-with");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_custom_request("7QBD98FWDMDQKABHCQLGZ52QEX_5", 
		"URL=https://d2vj5tua97fz9h.cloudfront.net/nuassist/rest/in/api/amp_nps_v1/survey/7QBD98FWDMDQKABHCQLGZ52QEX", 
		"Method=OPTIONS", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t70.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_custom_request("view_4", 
		"URL=https://googleads4.g.doubleclick.net/pcs/view?xai=AKAOjsvhXskK2Zw5omEpBCTSp44QdgysutXYBmV2EYKRu4gZ6tGMoH-3r-IYUEtVdr5bEzIA8e6EisVx70xcIaLsBm9XI4CeFm0_6CMzos2M0n9LC49212KkcNNfI-2RY5vq&sig=Cg0ArKJSzF5dn2PvUcXdEAE&fbs_aeid=[gw_fbsaeid]&urlfix=1&omid=0&rm=1&ctpt=1&cbvp=1&cisv=r20210624.54615&adurl=", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t71.inf", 
		"EncType=text/plain;charset=UTF-8", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("7QBD98FWDMDQKABHCQLGZ52QEX_6", 
		"URL=https://d2vj5tua97fz9h.cloudfront.net/nuassist/rest/in/api/amp_nps_v1/survey/7QBD98FWDMDQKABHCQLGZ52QEX", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t72.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"npsSessionId\":\"fed2b445-4ba7-4206-92ab-8a85433599d9\",\"parameters\":[{\"key\":\"channelname\",\"value\":\"anon-portal\"},{\"key\":\"device\",\"value\":\"desktop\"},{\"key\":\"browser\",\"value\":\"Chrome/91.0\"},{\"key\":\"pageId\",\"value\":\"amp:banking:savings-accounts:amp-saver-account\"}]}", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_url("cds.taboola.com_3", 
		"URL=https://cds.taboola.com/?uid=69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e&src=tfa", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t73.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_header("x-dtpc", 
		"7$146796357_665h10vKGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0e5");

	web_url("nps.html_3", 
		"URL=https://www.amp.com.au/wps/gws/com_amp_portal_nps/nps.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t74.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_url("activityi;register_conversion=1;src=8836193;type=remarket;cat=amp_s002;ord=7606760929731;gtm=2od6n0;auiddc=1626384231.1624946690;ps=1;~oref=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account", 
		"URL=https://8836193.fls.doubleclick.net/activityi;register_conversion=1;src=8836193;type=remarket;cat=amp_s002;ord=7606760929731;gtm=2od6n0;auiddc=1626384231.1624946690;ps=1;~oref=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account?", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t75.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"iframe");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("activityi;src=8836193;type=remarket;cat=amp_s002;ord=7606760929731;gtm=2od6n0;auiddc=1626384231.1624946690;ps=1;~oref=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account", 
		"URL=https://8836193.fls.doubleclick.net/activityi;src=8836193;type=remarket;cat=amp_s002;ord=7606760929731;gtm=2od6n0;auiddc=1626384231.1624946690;ps=1;~oref=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account?", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t76.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Origin", 
		"https://www.amp.com.au");

	web_url("pips.taboola.com_2", 
		"URL=https://pips.taboola.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t77.inf", 
		"Mode=HTML", 
		LAST);

	web_url("cds.taboola.com_4", 
		"URL=https://cds.taboola.com/?uid=69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t78.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_custom_request("rb_bf96747ztk_11", 
		"URL=https://www.amp.com.au/rb_bf96747ztk?app=cd4697ba1bc4a478;crc=3792008648;end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t79.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$a="
		"d%7C-1%7CLearn%20more%7CC%7C-%7C146759505_475%7C1624946795767%7Chttps%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%7CHigh%20Interest%20Saving%20Accounts%20-%20AMP%7C%7C%2Fbanking%2Fsavings-accounts%7C1624946759265%2C1%7C1%7C_load_%7C_load_%7C-%7C1624946795809%7C1624946804246%7Cdn%7C1401%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Clr%7Chttps%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2C2%7C14%7C_event_%7C1624946795809%7C_vc_%7CV%7C4459%5Epc%7CVCD%7C2130%7"
		"CVCDS%7C10%7CVCS%7C8497%7CVCO%7C9499%7CVCI%7C0%7CVE%7C1313%5Ep-274%5Ep540%5Eps%5Esspan.icon.icon--plus.icon--plus-rotated%7CS%7C906%2C2%7C15%7C_event_%7C1624946795809%7C_wv_%7Cfcp%7C4197%7Cfp%7C4197%7Ccls%7C0.021%7Clt%7C4572%7CfIS%7C3273%7CfID%7C369%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C2%7C2%7Cx%7Cxhr%7Cx%7C1624946796509%7C1624946797130%7Cdn%7C1326%7Cxu%7Chttps%3A%2F%2Fampserviceslimited.tt.omtrdc.net%2Frest%2Fv1%2Fdelivery%3Fclient%3Dampserviceslimited%26sessionId%3D3cc95b43f68748bfb93d005ba6dcfa"
		"05%26version%3D2.3.2%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946796514e0m534T-1z11I1%7Cxcs%7C621%7Cxce%7C621%2C2%7C3%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946796680%7C1624946800267%7Cdn%7C1400%7Cxu%7C%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Flegacy-nps.js%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946796737e0f0g0h0i0j0k37l204m312u10641v9770w50111T-5z11I1M-1882840675%7Cxcs%7C425%7Cxce%7C447%2C3%7C5%7Cj1.12.4-aem%7Cx"
		"hr%7Cj1.12.4-aem%7C1624946797113%7C1624946800267%7Cdn%7C1400%7Cxu%7C%2Fwps%2Fgws%2FNetPromoterScore%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946797123e0f0g0h0i0j0k6l772m772u1139v260w312T-4z11I1M604072495%7Cxcs%7C816%7Cxce%7C822%2C4%7C8%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946797931%7C1624946800267%7Cdn%7C1400%7Cxu%7Chttps%3A%2F%2Fd2vj5tua97fz9h.cloudfront.net%2Fnuassist%2Frest%2Fin%2Fapi%2Famp_nps_v1%2Fsurvey%2F7QBD98FWDMDQKABHCQLGZ52QEX%7Csvtrg%7C1%7Cs"
		"vm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946797935e0m2220T-3z11I1%7Cxcs%7C2273%7Cxce%7C2282%2C5%7C10%7Cj1.12.4-aem%7Cxhr%7Cj1.12.4-aem%7C1624946800205%7C1624946800267%7Cdn%7C1400%7Cxu%7C%2Fwps%2Fgws%2Fcom_amp_portal_nps%2Fnps.html%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946800212e0f0g0h0i0j0k3l51m51u476v697w2375T-2z11I1M642068672%7Cxcs%7C60%7Cxce%7C63%2C2%7C4%7Cx%7Cxhr%7Cx%7C1624946797086%7C1624946797252%7Cdn%7C1335%7Cxu%7Chttps"
		"%3A%2F%2Fs.yimg.com%2Fwi%2Fconfig%2F10092149.json%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946797097e0m1T-6z11I1%7Cxcs%7C163%7Cxce%7C166%2C2%7C6%7Cx%7Cxhr%7Cx%7C1624946797760%7C1624946797914%7Cdn%7C1359%7Cxu%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.asx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946797807e0m45T-7z11I1%7Cxcs%7C151%7Cxce%7C154%2C2%7C7%7Cx%7Cx"
		"hr%7Cx%7C1624946797808%7C1624946797916%7Cdn%7C1359%7Cxu%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.nzx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946797821e0m11T-8z11I1%7Cxcs%7C108%7Cxce%7C108%2C2%7C9%7Cx%7Cxhr%7Cx%7C1624946797944%7C1624946799519%7Cdn%7C1364%7Cxu%7Chttps%3A%2F%2Ftrc.taboola.com%2F1236555%2Flog%2F3%2Funip%3Fen%3Dpage_view%26item-url%3Dhttps%253A%252F%252Fwww.amp.com.au%252Fbanking%25"
		"2Fsavings-accounts%26tim%3D1624946797661%26ui%3D69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e%26ref%3Dhttps%253A%252F%252Fwww.amp.com.au%252Fbanking%252Fsavings-accounts%26cv%3D20210615-3-RELEASE%26tos%3D103217%26ssd%3D4%26scd%3D27%26vi%3D1624946797640%26ri%3D30cb7f76d9d6019f3da262c68a2f8525%26sd%3Dv2_708454af5ecb44b01dc61b48cc798c89_69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e_1624946718_1624946797_CIi3jgYQy7xLGMjYgbOlLyADKAEwEDiu_...%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7C"
		"i1%5Esk0%5Esh0%7Cxcs%7C1574%7Cxce%7C1574%7Crc%7C204%7Crm%7CNo%20Content%2C2%7C11%7Cx%7Cxhr%7Cx%7C1624946800215%7C1624946802505%7Cdn%7C1400%7Cxu%7Chttps%3A%2F%2Fpips.taboola.com%2F%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946800218e0m2284T-9z11I1%7Cxcs%7C2290%7Cxce%7C2290%2C2%7C12%7Cx%7Cxhr%7Cx%7C1624946802505%7C1624946804246%7Cdn%7C1401%7Cxu%7Chttps%3A%2F%2Fcds.taboola.com%2F%3Fuid%3D69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e%7Csvtrg%7C1%7Csvm%7Ci1%5"
		"Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%7Cxrt%7Cb1624946802508e0m1733T-10z11I1%7Cxcs%7C1741%7Cxce%7C1741%7Crc%7C204%7Crm%7CNo%20Content%2C2%7C13%7C_onload_%7C_load_%7C-%7C1624946804230%7C1624946804242%7Cdn%7C1401%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0%2C1%7C16%7C_event_%7C1624946795809%7C_view_%7Csvn%7C%2Fbanking%2Fsavings-accounts%7Csvt%7C1624946759265%7Csvtrg%7C1%7Csvm%7Ci1%5Esk0%5Esh0%7Ctvtrg%7C1%7Ctvm%7Ci1%5Esk0%5Esh0$svrid=7$rId=RID_-399517870$rpId="
		"934212157$domR=1624946804226$tvn=%2Fbanking%2Fsavings-accounts%2Famp-saver-account$tvt=1624946795809$tvm=i1%3Bk0%3Bh0$tvtrg=1$w=1500$h=857$sw=1500$sh=1000$nt=a0b1624946795809e3f3g3h3i3j3k11l469m471o973p973q1261r8418s8421t8433u22169v21279w160507M934212157$ni=4g|8.85$di=1$fd=j1.12.4^sb11-50$url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account$title=AMP%20Saver%20Account%20-%20AMP$latC=6$app=cd4697ba1bc4a478$visitID=KGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0$vs=2$fId="
		"146796357_665$v=10217210531114014$vID=16249466784450Q0MQIFVSELV6Q8T30TVRP9L9CP81NSQ$time=1624946806475", 
		LAST);

	web_custom_request("rb_bf96747ztk_12", 
		"URL=https://www.amp.com.au/rb_bf96747ztk?app=cd4697ba1bc4a478;crc=2131134433;end=1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t80.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=$svrid=7$tvn=%2Fbanking%2Fsavings-accounts%2Famp-saver-account$tvt=1624946795809$tvm=i1%3Bk0%3Bh0$tvtrg=1$ni=4g|5.05$di=1$3p="
		"1-1624946795809%3Bassets.adobedtm.com%7C4%7C5%7C0%7C0%7C1%7C0%7C5%7C%7C0%7C0%7C0%7C521_521_647_965_976_978_981_1257%7C120%7C0%7C318%3Bwww.amp.com.au%7Cu%7C8%7C0%7C0%7C3%7C0%7C8%7C%7C0%7C0%7C0%7C527_527_709_1105_8225_8271_8444_8446_8493_8508%7C76%7C0%7C298%7C6%7C0%7C0%7C5%7C0%7C6%7C%7C0%7C0%7C0%7C523_524_716_716_928_1240%7C52%7C0%7C312%7C4%7C0%7C0%7C3%7C521_525_724_724%7C1%7C0%7C3%7C13%7C0%7C0%7C11%7C757_759_799_799_1314_2087_4403_4455%7C63%7C0%7C772%3Bwww.google.com%7Ck%7C1%7C0%7C0%7C0%7C0%7C1%7C%"
		"7C0%7C0%7C0%7C526_527%7C1%7C1%7C1%7C4%7C0%7C0%7C0%7C1507_1810_4101_4337%7C248%7C221%7C302%3Bs.yimg.com%7Ck%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C673_760%7C87%7C87%7C87%7C1%7C0%7C0%7C0%7C1288_1290%7C1%7C1%7C1%3Bbat.bing.com%7Ck%7C2%7C0%7C0%7C0%7C0%7C2%7C%7C0%7C0%7C0%7C691_767_1398_1399%7C39%7C1%7C76%7C0%7C1%7C0%7C0%7C1405_1546%7C141%7C141%7C141%3Bampserviceslimited.tt.omtrdc.net%7Cg%7C1%7C0%7C0%7C0%7C705_1239%7C534%7C534%7C534%3Byourir.info%7Cs%7C2%7C0%7C0%7C0%7C0%7C2%7C%7C0%7C0%7C0%7C716_768_14"
		"07_1415%7C30%7C8%7C52%7C1%7C0%7C0%7C0%7C1407_1414%7C6%7C6%7C6%7C2%7C0%7C0%7C0%7C1998_2044%7C28%7C11%7C45%3Bajax.googleapis.com%7C4%7C1%7C0%7C0%7C1%7C0%7C1%7C%7C0%7C0%7C0%7C717_717%7C0%7C0%7C0%3Bhello.myfonts.net%7Cg%7C1%7C0%7C0%7C0%7C722_722%7C0%7C0%7C0%3Bfonts.googleapis.com%7Cg%7C1%7C0%7C0%7C1%7C723_723%7C0%7C0%7C0%3Bfonts.gstatic.com%7Cg%7C5%7C0%7C0%7C3%7C753_754_756_756_824_1316%7C178%7C0%7C492%3Bad.doubleclick.net%7Cg%7C1%7C0%7C0%7C0%7C774_1735%7C961%7C961%7C961%3Bwww.gstatic.com%7C4%7C1%7C0%"
		"7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C851_920%7C69%7C69%7C69%3Bconnect.facebook.net%7Ck%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C957_968%7C11%7C11%7C11%7C1%7C0%7C0%7C0%7C1481_1483%7C2%7C2%7C2%3Bsp.analytics.yahoo.com%7Cg%7C1%7C0%7C0%7C0%7C1443_1569%7C126%7C126%7C126%3Bwww.googletagmanager.com%7Cg%7C4%7C0%7C0%7C0%7C1460_1463_2026_2030%7C3%7C2%7C3%3Bcdn.taboola.com%7C4%7C2%7C0%7C0%7C0%7C0%7C2%7C%7C0%7C0%7C0%7C1466_1468_2140_4345%7C1104%7C2%7C2205%3Bwww.facebook.com%7Cg%7C2%7C0%7C0%7C0%7C1554_1799%7C217%7"
		"C189%7C245%3Bamp.d2.sc.omtrdc.net%7Cg%7C1%7C0%7C0%7C0%7C1829_2023%7C193%7C193%7C193%3Btrc.taboola.com%7Cg%7C2%7C0%7C0%7C0%7C1856_2022_2139_3630%7C829%7C166%7C1491%3Bcds.taboola.com%7Cg%7C2%7C0%7C0%7C0%7C1858_4344_6699_8432%7C2110%7C1733%7C2486%3Bwww.googletagservices.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C2095_2098%7C2%7C2%7C2%3Bpagead2.googlesyndication.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C2096_2098%7C3%7C3%7C3%3Bgoogleads4.g.doubleclick.net%7Cg%7C1%7C0%7C0%7C0%7C2100_3630%7"
		"C1530%7C1530%7C1530%3Bd2vj5tua97fz9h.cloudfront.net%7Cg%7C1%7C0%7C0%7C0%7C2126_4346%7C2220%7C2220%7C2220%3Bwww.googleadservices.com%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C3653_3655%7C2%7C2%7C2%3B8836193.fls.doubleclick.net%7Cg%7C2%7C0%7C0%7C0%7C3702_4704%7C949%7C895%7C1003%3Bgoogleads.g.doubleclick.net%7Cg%7C3%7C0%7C0%7C0%7C3911_4097%7C182%7C179%7C183%3Bwww.google.com.au%7Cg%7C3%7C0%7C0%7C0%7C4102_4717%7C478%7C329%7C600%3Bpips.taboola.com%7Cg%7C1%7C0%7C0%7C0%7C4409_6693%7C2284%7C2284%7C2284%"
		"3Bwww.sc.pages03.net%7C4%7C1%7C0%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C8422_8424%7C2%7C2%7C2%3Bwww.pages03.net%7C2%7C0%7C1%7C0%7C0%7C0%7C1%7C%7C0%7C0%7C0%7C8489_10622%7C2132%7C2132%7C2132$rt="
		"1-1624946795809%3Bhttps%3A%2F%2Fassets.adobedtm.com%2F30cb14f656a0%2F7a08285d48a4%2Flaunch-36c302166c9d.min.js%7Cb521e0f0g0h0i0j0m0v98652w377849K1I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Fclientlib-site.css%7Cb521e0f0g0h0i0j0k2l2m3v43375w348255K1I11M-446851815%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc.clientlibs%2Fclientlibs%2Fgranite%2Fjquery.js%7Cb523e0f0g0h0i0j0m0v88042w294660K1I12M1038558126%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc.clientlibs%2Fclientlibs%2Fgranite%2Fut"
		"ils.js%7Cb523e0f0g0h0i0j0m0v10737w48607K1I12M-675004936%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc.clientlibs%2Fclientlibs%2Fgranite%2Fjquery%2Fgranite.js%7Cb523e0f0g0h0i0j0m0v973w2408K1I12M-1223847897%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Fswiftype-libs.js%7Cb524e0f0g0h0i0j0m0v8510w24519K1I12M254190841%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp%2FclientLibraries%2Ficons-libs.css%7Cb524e0f0g0h0i0j0m0v2180w11909K1I11M-831598683%7Chttps%3A%2F%2Fwww.amp.com.au%2Fet"
		"c%2Fdesigns%2Famp-au%2Fclientlibs%2Flegacy-nps.css%7Cb525e0f0g0h0i0j0m0v4872w38911K1I11M-1422456331%7Chttps%3A%2F%2Fwww.google.com%2Frecaptcha%2Fapi.js%3Frender%3D6Lf1YKQUAAAAAK3RIImnFOQrks8gZnrC7pObqn5q%7Cb526e0m1I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fdata%2Ficons%2Famp-logo-reversed.svg%7Cb527e0f0g0h0i0j0m0v205162w205162E1F6188O119P52I7M-1281867438%7Chttps%3A%2F%2Fassets.adobedtm.com%2Fextensions%2FEPbde2f7ca14e540399dcc1f8208860b7b%2FAppMeasurement.min.js%7Cb647e0f0g0h82i"
		"256j137k261l315m318u378v12184w33462I12%7Chttps%3A%2F%2Fs.yimg.com%2Fwi%2Fytc.js%7Cb673e0m87I12%7Chttps%3A%2F%2Fbat.bing.com%2Fbat.js%7Cb691e0m76I12%7Chttps%3A%2F%2Fampserviceslimited.tt.omtrdc.net%2Frest%2Fv1%2Fdelivery%3Fclient%3Dampserviceslimited%26sessionId%3D3cc95b43f68748bfb93d005ba6dcfa05%26version%3D2.3.2%7Cb705e0m534T-1z1I1%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fdata%2Ficons%2Famp-logo.svg%7Cb709e0f0g0h0i0j0m0v174276w174276N3O120P53Q284R125I7M-1231867539%7Chttps%3A%2F%2"
		"Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fimages%2Fbanking-hub%2Fbanners%2FKombi_5FSaver_5F768x480.jpg%7Cb710e0f0g0h0i0j0k197l252m256u22515v21734w46510N3O768P480I7M-561862137%7Chttps%3A%2F%2Fyourir.info%2F61b218eca79bef95.js%7Cb716e0m52I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Fclientlib-site.js%7Cb716e0f0g0h0i0j0m0v130526w431873K1I12M1189347597%7Chttps%3A%2F%2Fajax.googleapis.com%2Fajax%2Flibs%2Fwebfont%2F1.6%2Fwebfont.js%7Cb717e0f0g0h0i0j0m0v5437w13188K1I12%7Chtt"
		"ps%3A%2F%2Fhello.myfonts.net%2Fcount%2F3a2740%7Cb722e0m0I9%7Chttps%3A%2F%2Ffonts.googleapis.com%2Fcss%3Ffamily%3DOpen%2BSans%3A400italic%5Ec600italic%5Ec400%5Ec300%5Ec600%7Cb723e0f0g0h0i0j0m0v814w10371I9%7Chttps%3A%2F%2Fwww.amp.com.au%2Fddc%2Fpublic%2Fui%2Fassets%2Fddc-fonts%2Fddc-fonts.css%7Cb724e0f0g0h0i0j0m0v2043w10164I9M840765892%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs%2Fopensans%2Fv20%2Fmem5YaGs126MiZpBA-UN_5Fr8OUuhp.woff2%7Cb753e0f0g0h0i0j0m0v14992w14992I9%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs"
		"%2Fopensans%2Fv20%2Fmem8YaGs126MiZpBA-UFVZ0b.woff2%7Cb754e0f0g0h0i0j0m0v14440w14440I9%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs%2Fopensans%2Fv20%2Fmem5YaGs126MiZpBA-UNirkOUuhp.woff2%7Cb756e0f0g0h0i0j0m0v14956w14956I9%7Chttps%3A%2F%2Fwww.amp.com.au%2Fddc%2Fpublic%2Fui%2Fassets%2Fddc-fonts%2Fddc-icons.ttf%7Cb757e0f0g0h0i0j0m0v58104w58104I9M-1675776017%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F5c32de29c638fdf3bb4adc662a0ad595.woff2%7Cb757e0f0g0h0i0j0m0v83382w83382I9M-463698524%7C"
		"https%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2Fce62fa71a1a38af297b433e85d36d83f.woff2%7Cb757e0f0g0h0i0j0m0v76773w76773I9M1519948408%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F98c3ea22ad6bca213fa88175f7d9ffaf.woff2%7Cb758e0f0g0h0i0j0m0v96082w96082I9M-1892032532%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F33543c5cc5d88f5695dd08c87d280dfd.woff2%7Cb758e0f0g0h0i0j0m0v14380w14380I9M-1860783378%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns"
		"%2Famp-au%2Fassets%2F819af3d3abdc9f135d49b80a91e2ff4c.woff2%7Cb758e0f0g0h0i0j0m0v14880w14880I9M-733586217%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fassets%2F2525a15d1fb3ce824a7aad5e07ba2513.ttf%7Cb759e0f0g0h0i0j0m0v27480w27480I9M-835539285%7Chttps%3A%2F%2Fad.doubleclick.net%2Fddm%2Fadj%2FN962361.197812NSO.CODESRV%2FB22590592.244647881%5Essz%3D1x2%5Esord%3D934547106417%3F%7Cb774e0f0g0h12i555j351k555l802m961u8732v7784w20600K1I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp%2F"
		"assets%2Ffonts%2Fxtreme.woff%7Cb799e0f0g0h0i0j0m0v26408w26408I9M2047052215%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Fpromotion-banner%2Fbanner-background-2.jpg%7Cb807e0f0g0h0i0j0k127l178m298u24084v23303w105273E1F747062O1483P600Q3840R1400I9M-803553230%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs%2Fopensans%2Fv20%2Fmem6YaGs126MiZpBA-UFUK0Zdc0.woff2%7Cb824e0f0g0h0i0j0k417l445m492u14555v13792w13792I9%7Chttps%3A%2F%2Ffonts.gstatic.com%2Fs%2Fopensans%2Fv20%2FmemnYaGs126MiZpBA-UFUKXG"
		"UdhrIqM.woff2%7Cb841e0f0g0h0i0j0k146l271m399u14691v13928w13928I9%7Chttps%3A%2F%2Fwww.gstatic.com%2Frecaptcha%2Freleases%2FeKRIyK-9MtX6JxeZcNZIkfUq%2Frecaptcha_5F_5Fen.js%7Cb851e0m69I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp-au%2Fclientlibs%2Flegacy-nps.js%3F_5F%3D1624946796555%7Cb928e0f0g0h0i0j0k37l204m312u10641v9770w50111T-5z1I1M-1882840675%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fdata%2Fillustrations%2FCookies.svg%7Cb930e0f0g0h0i0j0m0v1382w1382I7M-100836164%7Chttps"
		"%3A%2F%2Fconnect.facebook.net%2Fen_5FUS%2Ffbevents.js%7Cb957e0m11I12%7Chttps%3A%2F%2Fassets.adobedtm.com%2F30cb14f656a0%2F7a08285d48a4%2F29c0db022c3d%2FRC3780d39ec03d45df99c03f86ac0bab9c-source.min.js%7Cb976e0f0g0h0i0j0k1l2m2v413w717I12%7Chttps%3A%2F%2Fassets.adobedtm.com%2F30cb14f656a0%2F7a08285d48a4%2F29c0db022c3d%2FRCdec9800f73ea4a7e826731b56050a137-source.min.js%7Cb981e0f0g0h0i0j0k242l276m276u753v265w405I12%7Chttps%3A%2F%2Fassets.adobedtm.com%2F30cb14f656a0%2F7a08285d48a4%2F29c0db022c3d%2FRC15"
		"a5c6f5e8cb4510b7d70763e430d359-source.min.js%7Cb984e0f0g0h0i0j0k1l2m4v489w824I12%7Chttps%3A%2F%2Fs.yimg.com%2Fwi%2Fconfig%2F10092149.json%7Cb1288e0m1T-6z1I1%7Chttps%3A%2F%2Fwww.amp.com.au%2Fwps%2Fgws%2FNetPromoterScore%3FpageId%3Damp_253Abanking_253Asavings-accounts_253Aamp-saver-account%26userIdentifier%3D27405bde14c20c2e40f716f95415ce9b%7Cb1314e0f0g0h0i0j0k6l772m772u1139v260w312T-4z1I1M604072495%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp%2Fassets%2Ffonts%2Fxtreme.woff%7Cb1367e0f0g0h0i0"
		"j0m0v26408w26408I9M2047052215%7Chttps%3A%2F%2Fbat.bing.com%2Fp%2Faction%2F16012365.js%7Cb1398e0m1I12%7Chttps%3A%2F%2Fbat.bing.com%2Faction%2F0%7Cb1405e0m141A1N3I7%7Chttps%3A%2F%2Fyourir.info%2Flib%2F1.11.6%2Fyourir.js%7Cb1407e0m8I12%7Chttps%3A%2F%2Fyourir.info%2Flib%2F1.11.6%2Fyourir.css%7Cb1407e0m6K1I11%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp%2Fassets%2Ffonts%2Fxtreme.woff%7Cb1434e0f0g0h0i0j0m0v26408w26408I9M2047052215%7Chttps%3A%2F%2Fsp.analytics.yahoo.com%2Fsp.pl%7Cb1443e0m126N3O1P"
		"1I7%7Chttps%3A%2F%2Fwww.googletagmanager.com%2Fgtag%2Fjs%3Fid%3DDC-8836193%7Cb1460e0m3I12%7Chttps%3A%2F%2Fcdn.taboola.com%2Flibtrc%2Funip%2F1236555%2Ftfa.js%7Cb1466e0m2I12%7Chttps%3A%2F%2Fconnect.facebook.net%2Fsignals%2Fconfig%2F131169910928083%3Fv%3D2.9.42%26r%3Dstable%7Cb1481e0m2I12%7Chttps%3A%2F%2Fwww.google.com%2Frecaptcha%2Fapi2%2Fanchor%3Far%3D1%26k%3D6Lf1YKQUAAAAAK3RIImnFOQrks8gZnrC7pObqn5q%26co%3DaHR0cHM6Ly93d3cuYW1wLmNvbS5hdTo0NDM.%26hl%3Den%26v%3DeKRIyK-9MtX6JxeZcNZIkfUq%26size%3Dinvisi"
		"ble%26cb%3D6hd1aaxjj69l%7Cb1507e0m302Bi0I4%7Chttps%3A%2F%2Fwww.amp.com.au%2Fetc%2Fdesigns%2Famp%2Fassets%2Ffonts%2Fxtreme.woff%7Cb1520e0f0g0h0i0j0m0v26408w26408I9M2047052215%7Chttps%3A%2F%2Fwww.facebook.com%2Ftr%2F%7Cb1554e0m245I7%7Chttps%3A%2F%2Fwww.facebook.com%2Ftr%2F%7Cb1554e0m189I7%7Chttps%3A%2F%2Famp.d2.sc.omtrdc.net%2Fb%2Fss%2Famp-dtm-prd%2F1%2FJS-2.22.0-LBSQ%2Fs89098107275091%7Cb1829e0m193I7%7Chttps%3A%2F%2Ftrc.taboola.com%2F1236555%2Ftrc%2F3%2Fjson%7Cb1856e0m166I12%7Chttps%3A%2F%2Fcds.tab"
		"oola.com%2F%3Fuid%3D69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e%26src%3Dtfa%7Cb1858e0m2486I7%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.asx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Cb1998e0m45T-7z1I1%7Chttps%3A%2F%2Fyourir.info%2Fapi%2Fv5%2Fsymbols%2Famp.nzx%3FappID%3D61b218eca79bef95%26liveness%3Ddelayed%7Cb2012e0m11T-8z1I1%7Chttps%3A%2F%2Fwww.googletagmanager.com%2Fgtag%2Fjs%3Fid%3DAW-751278354%26l%3DdataLayer%26cx%3Dc%7Cb2026e0m2I12%7Chttps%3A%2F%2Fwww.googletagmanager."
		"com%2Fgtag%2Fjs%3Fid%3DAW-684022622%26l%3DdataLayer%26cx%3Dc%7Cb2027e0m2I12%7Chttps%3A%2F%2Fwww.googletagmanager.com%2Fgtag%2Fjs%3Fid%3DAW-711997817%26l%3DdataLayer%26cx%3Dc%7Cb2028e0m2I12%7Chttps%3A%2F%2Fwww.googletagservices.com%2Factiveview%2Fjs%2Fcurrent%2Frx_5Flidar.js%3Fcache%3Dr20110914%7Cb2095e0m2I12%7Chttps%3A%2F%2Fpagead2.googlesyndication.com%2Fpagead%2Fjs%2Fr20210624%2Fr20110914%2Felements%2Fhtml%2Fomrhp.js%7Cb2096e0f0g0h0i0j0k2l2m3v3124w7957K1I12%7Chttps%3A%2F%2Fgoogleads4.g.doublecli"
		"ck.net%2Fpcs%2Fview%7Cb2100e0f0g0h0i0j0k2l1530m1530u818I3%7Chttps%3A%2F%2Fd2vj5tua97fz9h.cloudfront.net%2Fnuassist%2Frest%2Fin%2Fapi%2Famp_5Fnps_5Fv1%2Fsurvey%2F7QBD98FWDMDQKABHCQLGZ52QEX%7Cb2126e0m2220T-3z1I1%7Chttps%3A%2F%2Ftrc.taboola.com%2F1236555%2Flog%2F3%2Funip%7Cb2139e0m1491z11I1%7Chttps%3A%2F%2Fcdn.taboola.com%2Fscripts%2Fcds-pips.js%7Cb2140e0m2205I12%7Chttps%3A%2F%2Fwww.googleadservices.com%2Fpagead%2Fconversion_5Fasync.js%7Cb3653e0f0g0h0i0j0k1l1m2v14015w36813I12%7C8836193.fls.doubleclic"
		"k.net%2F..%2F..002%5Esord%3D7606760929731%5Esgtm%3D2od6n0%5Esauiddc%3D1626384231.1624946690%5Esps%3D1%5Es%7Eoref%3Dhttps_253A_252F_252Fwww.amp.com.au_252Fbanking_252Fsavings-accounts_252Famp-saver-account%7Cb3702c0d792e793f793g793h793i793j793k795l997m1003u2562v408w534Bi2I4%7C8836193.fls.doubleclick.net%2F..%2F..002%5Esord%3D7606760929731%5Esgtm%3D2od6n0%5Esauiddc%3D1626384231.1624946690%5Esps%3D1%5Es%7Eoref%3Dhttps_253A_252F_252Fwww.amp.com.au_252Fbanking_252Fsavings-accounts_252Famp-saver-account"
		"%7Cb3705e0m895I7%7Chttps%3A%2F%2Fgoogleads.g.doubleclick.net%2Fpagead%2Fviewthroughconversion%2F684022622%2F%7Cb3911e0f0g0h0i0j0k3l126m182u2283v1072w2486K1I12%7Chttps%3A%2F%2Fgoogleads.g.doubleclick.net%2Fpagead%2Fviewthroughconversion%2F711997817%2F%7Cb3915e0f0g0h0i0j0k10l150m183u2056v1071w2484K1I12%7Chttps%3A%2F%2Fgoogleads.g.doubleclick.net%2Fpagead%2Fviewthroughconversion%2F751278354%2F%7Cb3917e0f0g0h0i0j0k8l177m179u2143v1071w2486K1I12%7Chttps%3A%2F%2Fwww.google.com%2Fpagead%2F1p-user-list%2F6"
		"84022622%2F%7Cb4101e0f0g0h0i0j0k19l201m236u768v42w42I7%7Chttps%3A%2F%2Fwww.google.com.au%2Fpagead%2F1p-user-list%2F684022622%2F%7Cb4102e0m329I7%7Chttps%3A%2F%2Fwww.google.com%2Fpagead%2F1p-user-list%2F751278354%2F%7Cb4105e0f0g0h0i0j0k15l197m232u768v42w42I7%7Chttps%3A%2F%2Fwww.google.com.au%2Fpagead%2F1p-user-list%2F751278354%2F%7Cb4105e0m505I7%7Chttps%3A%2F%2Fwww.google.com%2Fpagead%2F1p-user-list%2F711997817%2F%7Cb4116e0f0g0h0i0j0k29l187m221u768v42w42I7%7Chttps%3A%2F%2Fwww.google.com.au%2Fpagead%"
		"2F1p-user-list%2F711997817%2F%7Cb4117e0m600I7%7Chttps%3A%2F%2Fwww.amp.com.au%2Fwps%2Fgws%2Fcom_5Famp_5Fportal_5Fnps%2Fnps.html%7Cb4403e0f0g0h0i0j0k3l51m51u476v697w2375T-2z1I1M642068672%7Chttps%3A%2F%2Fpips.taboola.com%2F%7Cb4409e0m2284T-9z1I1%7Chttps%3A%2F%2Fcds.taboola.com%2F%3Fuid%3D69eaba60-7012-4b6d-a7b1-7ea1c0d777c8-tuct7d43d9e%7Cb6699e0m1733T-10z1I1%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fdata%2Ficons%2Fdoc-pdf.svg%7Cb8225e0f0g0h0i0j0k15l45m46u5592v4855w4855I7M-1194991036%7"
		"Chttps%3A%2F%2Fwww.sc.pages03.net%2Flp%2Fstatic%2Fjs%2FiMAWebCookie.js%3F18560ebc-14a40f8eab9-943e27de0c8b91cc3fcf1475c3e5d726%26h%3Dwww.pages03.net%7Cb8422e0m2K1I12%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Ffavicon.ico%7Cb8444e0f0g0h0i0j0k2l2m2v1406w1406I22M265790923%7Chttps%3A%2F%2Fwww.pages03.net%2FWTS%2Fevent.jpeg%7Cb8489e0m2132A1N3S2135I7%7Chttps%3A%2F%2Fwww.amp.com.au%2Fcontent%2Fdam%2Famp-au%2Fauthoring%2Ficons%2Ffavicon.ico%7Cb8493e0f0g0h0i0j0k15l15m16v1"
		"406w1406I22M265790923$url=https%3A%2F%2Fwww.amp.com.au%2Fbanking%2Fsavings-accounts%2Famp-saver-account$title=AMP%20Saver%20Account%20-%20AMP$latC=4$app=cd4697ba1bc4a478$visitID=KGASFCFUFKFUHKAPLEWKRDUAKEFACDFH-0$vs=2$fId=146796357_665$v=10217210531114014$vID=16249466784450Q0MQIFVSELV6Q8T30TVRP9L9CP81NSQ$time=1624946808531", 
		LAST);

	lr_end_transaction("04_Click on AMP saver account_learn more",LR_AUTO);

	lr_start_transaction("05_open account");

	web_revert_auto_header("Origin");

	web_reg_find("Text=AMP Saver Account", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("saver-account", 
		"URL=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t81.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.amp.com.au/etc/designs/amp/clientLibraries/icons-libs.min.css", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=../assets/ddc-fonts/ddc-fonts.css", ENDITEM, 
		"Url=styles.0761fd239214ab23c67e.css", ENDITEM, 
		"Url=config.js", ENDITEM, 
		"Url=polyfills.7a1195e67f8d2d0712cb.js", ENDITEM, 
		"Url=runtime.a5b4734854bf1bbfa0a2.js", ENDITEM, 
		"Url=main.c60383d8a50300e5ec5f.js", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Origin", 
		"https://www.amp.com.au");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_custom_request("0_8", 
		"URL=https://bat.bing.com/actionp/0?ti=16012365&Ver=2&mid=217769c3-696d-4727-8b54-dd591df0ba94&sid=e6578fe0d89f11eb98165deac4f355a8&vid=e657ca70d89f11eb8fe68f742e2032a1&vids=0&evt=pageHide", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://www.amp.com.au/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t82.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		EXTRARES, 
		"Url=https://assets.adobedtm.com/30cb14f656a0/44b143ec5db5/launch-05c2e15134f4.min.js", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://www.amp.com.au/fonts/282695/EFFED685B8BB01EC4.css", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	web_reg_find("Text=Login to My AMP - AMP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Dest", 
		"script");

	web_url("ruxitagentjs_ICA27SVfghjqrux_10217210531114014.js", 
		"URL=https://secure.amp.com.au/wps/myportal/sec/ruxitagentjs_ICA27SVfghjqrux_10217210531114014.js", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t83.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"https://secure.amp.com.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_custom_request("id_2", 
		"URL=https://dpm.demdex.net/id?d_visid_ver=4.6.0&d_fieldgroup=AAM&d_rtbd=json&d_ver=2&d_orgid=11BA6EA55322342B0A490D44%40AdobeOrg&d_nsid=0&d_mid=23569144125047983874531016401195797023&d_blob=6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y&ts=1624946830936", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/", 
		"Snapshot=t84.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded", 
		LAST);

	web_custom_request("delivery_6", 
		"URL=https://ampserviceslimited.tt.omtrdc.net/rest/v1/delivery?client=ampserviceslimited&sessionId=3cc95b43f68748bfb93d005ba6dcfa05&version=2.3.2", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/", 
		"Snapshot=t85.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body={\"requestId\":\"90f3117bad00420b959b1aca4506e157\",\"context\":{\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36\",\"timeOffsetInMinutes\":600,\"channel\":\"web\",\"screen\":{\"width\":1500,\"height\":1000,\"orientation\":\"landscape\",\"colorDepth\":24,\"pixelRatio\":1},\"window\":{\"width\":1500,\"height\":857},\"browser\":{\"host\":\"secure.amp.com.au\",\"webGLRenderer\":\"Google SwiftShader\"},\"address\":"
		"{\"url\":\"https://secure.amp.com.au/ddc/public/ui/saver-account/\",\"referringUrl\":\"https://www.amp.com.au/banking/savings-accounts/amp-saver-account\"}},\"id\":{\"tntId\":\"3cc95b43f68748bfb93d005ba6dcfa05.36_0\",\"marketingCloudVisitorId\":\"23569144125047983874531016401195797023\"},\"experienceCloud\":{\"audienceManager\":{\"locationHint\":8,\"blob\":\"6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y\"},\"analytics\":{\"logging\":\"server_side\",\"supplementalDataId\":\""
		"76BB12190CC56603-3F4AAD5BB88BF786\",\"trackingServer\":\"amp.d2.sc.omtrdc.net\",\"trackingServerSecure\":\"amp.d2.sc.omtrdc.net\"}},\"execute\":{\"pageLoad\":{\"parameters\":{\"user.categoryId\":\"banking\"}}},\"prefetch\":{\"views\":[{\"parameters\":{\"user.categoryId\":\"banking\"}}]}}", 
		LAST);

	web_url("api.ipdata.co_2", 
		"URL=https://api.ipdata.co/?api-key=1a31485dfcd75b472742d9f7e224d7057a5d9ba6ce95eee1ee785c30", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/", 
		"Snapshot=t86.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Origin");

	web_reg_find("Text=AMP Saver Account", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("saver-account_2", 
		"URL=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t87.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://assets.adobedtm.com/30cb14f656a0/44b143ec5db5/5fde423c5655/RC135e88baa5e44a699bf2f57a66834364-source.min.js", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://assets.adobedtm.com/30cb14f656a0/44b143ec5db5/5fde423c5655/RC2180ce3e480d49f5a100296031843f93-source.min.js", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=../assets/ddc-fonts/ddc-fonts.css", ENDITEM, 
		"Url=assets/images/Intro-background_min.jpg", ENDITEM, 
		"Url=favicon.ico", ENDITEM, 
		LAST);

	web_reg_find("Text=Login to My AMP - AMP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"script");

	web_url("ruxitagentjs_ICA27SVfghjqrux_10217210531114014.js_2", 
		"URL=https://secure.amp.com.au/wps/myportal/sec/ruxitagentjs_ICA27SVfghjqrux_10217210531114014.js", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t88.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://assets.adobedtm.com/extensions/EPbde2f7ca14e540399dcc1f8208860b7b/AppMeasurement.min.js", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://assets.adobedtm.com/30cb14f656a0/44b143ec5db5/5fde423c5655/RC135e88baa5e44a699bf2f57a66834364-source.min.js", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_header("Origin", 
		"https://secure.amp.com.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_custom_request("delivery_7", 
		"URL=https://ampserviceslimited.tt.omtrdc.net/rest/v1/delivery?client=ampserviceslimited&sessionId=3cc95b43f68748bfb93d005ba6dcfa05&version=2.3.2", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/", 
		"Snapshot=t89.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body={\"requestId\":\"f4bdb154ce34440bbe52353655f0c172\",\"context\":{\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36\",\"timeOffsetInMinutes\":600,\"channel\":\"web\",\"screen\":{\"width\":1500,\"height\":1000,\"orientation\":\"landscape\",\"colorDepth\":24,\"pixelRatio\":1},\"window\":{\"width\":1500,\"height\":857},\"browser\":{\"host\":\"secure.amp.com.au\",\"webGLRenderer\":\"Google SwiftShader\"},\"address\":"
		"{\"url\":\"https://secure.amp.com.au/ddc/public/ui/saver-account/\",\"referringUrl\":\"https://secure.amp.com.au/ddc/public/ui/saver-account/\"}},\"id\":{\"tntId\":\"3cc95b43f68748bfb93d005ba6dcfa05.36_0\",\"marketingCloudVisitorId\":\"23569144125047983874531016401195797023\"},\"experienceCloud\":{\"audienceManager\":{\"locationHint\":8,\"blob\":\"6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y\"},\"analytics\":{\"logging\":\"server_side\",\"supplementalDataId\":\""
		"1915100DFEEBF163-0B427A36078E2CFF\",\"trackingServer\":\"amp.d2.sc.omtrdc.net\",\"trackingServerSecure\":\"amp.d2.sc.omtrdc.net\"}},\"execute\":{\"pageLoad\":{\"parameters\":{\"user.categoryId\":\"banking\"}}},\"prefetch\":{\"views\":[{\"parameters\":{\"user.categoryId\":\"banking\"}}]}}", 
		EXTRARES, 
		"Url=https://assets.adobedtm.com/30cb14f656a0/44b143ec5db5/5fde423c5655/RC2180ce3e480d49f5a100296031843f93-source.min.js", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://www.facebook.com/tr/?id=131169910928083&ev=PageView&dl=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&rl=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&if=false&ts=1624946834644&sw=1500&sh=1000&v=2.9.42&r=stable&ec=0&o=28&fbp=fb.2.1624946684859.99642261&it=1624946834582&coo=false&rqm=GET", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://www.facebook.com/tr/?id=131169910928083&ev=ViewContent&dl=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&rl=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&if=false&ts=1624946834648&sw=1500&sh=1000&v=2.9.42&r=stable&ec=1&o=28&fbp=fb.2.1624946684859.99642261&it=1624946834582&coo=false&rqm=GET", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	web_reg_find("Text=Login to My AMP - AMP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("apiKey", 
		"Bearer df591ce84c2d12ad679bedb3e14c6ba");

	web_custom_request("usersession", 
		"URL=https://secure.amp.com.au/services/secure/ddc/1.0.0/usersession", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t90.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s88910103501194?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A7%3A16%202%20-600&sdid=1915100DFEEBF163-0B427A36078E2CFF&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=DDC%3AAMP%20Saver%20Account&g=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&r=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&cc=AUD&aamb="
		"6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y&v6=false&c16=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&v16=D%3Dc16&c74=DDC%20Launch&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&AQE=1", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/711997817/?random=1624946836266&cv=9&fst=1624946836266&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=376635471%2C2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=5&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&ref=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&tiba="
		"AMP%20Saver%20Account&hn=www.googleadservices.com&async=1&rfmt=3&fmt=4", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://www.google.com/recaptcha/api.js?onload=reCaptchaOnloadCallback&render=explicit", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://www.amp.com.au/content/dam/amp/digitalhub/common/images/systems/ddc/amp-blue.png", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	web_add_header("caller", 
		"saver-account");

	web_custom_request("countries", 
		"URL=https://secure.amp.com.au/ddc/public/api/refdata/countries", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t91.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/ddc/public/ui/saver-account/3A2740_4_0.98c3ea22ad6bca213fa8.woff2", "Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/styles.0761fd239214ab23c67e.css", ENDITEM, 
		"Url=/ddc/public/ui/saver-account/3A2740_2_0.ce62fa71a1a38af297b4.woff2", "Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/styles.0761fd239214ab23c67e.css", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/751278354/?random=1624946836271&cv=9&fst=1624946836271&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=2505059651&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=5&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&ref=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&tiba="
		"AMP%20Saver%20Account&hn=www.googleadservices.com&async=1&rfmt=3&fmt=4", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://api.ipify.org/?format=jsonp&callback=?", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://www.google.com/pagead/1p-user-list/711997817/?random=1624946836266&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=376635471%2C2505059650&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=5&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&ref=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&tiba=AMP%20Saver%20Account&async=1&fmt=3&is_vtc=1&"
		"random=2535461926&resp=GooglemKTybQhCsO&rmt_tld=0&ipr=y", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_url("activityi;register_conversion=1;src=8836193;type=remarket;cat=amp_s005;ord=6199795994958;gtm=2od6n0;auiddc=1626384231.1624946690;ps=1;~oref=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F", 
		"URL=https://8836193.fls.doubleclick.net/activityi;register_conversion=1;src=8836193;type=remarket;cat=amp_s005;ord=6199795994958;gtm=2od6n0;auiddc=1626384231.1624946690;ps=1;~oref=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F?", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://secure.amp.com.au/", 
		"Snapshot=t92.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/684022622/?random=1624946836272&cv=9&fst=1624946836272&num=1&bg=ffffff&guid=ON&resp=GooglemKTybQhCsO&eid=2505059651&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=5&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&ig=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&ref=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&tiba="
		"AMP%20Saver%20Account&hn=www.googleadservices.com&async=1&rfmt=3&fmt=4", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://www.google.com/pagead/1p-user-list/751278354/?random=1624946836271&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=2505059651&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=5&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&ref=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&tiba=AMP%20Saver%20Account&async=1&fmt=3&is_vtc=1&random="
		"2406317366&resp=GooglemKTybQhCsO&rmt_tld=0&ipr=y", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	web_reg_find("Text=Login to My AMP - AMP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("apiKey", 
		"Bearer df591ce84c2d12ad679bedb3e14c6ba");

	web_add_header("caller", 
		"saver-account");

	web_custom_request("usersession_2", 
		"URL=https://secure.amp.com.au/services/secure/ddc/1.0.0/usersession", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t93.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"iframe");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("activityi;src=8836193;type=remarket;cat=amp_s005;ord=6199795994958;gtm=2od6n0;auiddc=1626384231.1624946690;ps=1;~oref=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F", 
		"URL=https://8836193.fls.doubleclick.net/activityi;src=8836193;type=remarket;cat=amp_s005;ord=6199795994958;gtm=2od6n0;auiddc=1626384231.1624946690;ps=1;~oref=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F?", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://secure.amp.com.au/", 
		"Snapshot=t94.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_find("Text=reCAPTCHA", 
		LAST);

	web_url("anchor_5", 
		"URL=https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LeXti4UAAAAAKwhgrxUbjY-dO-OMHhfK3ePEe4b&co=aHR0cHM6Ly9zZWN1cmUuYW1wLmNvbS5hdTo0NDM.&hl=en&type=image&v=eKRIyK-9MtX6JxeZcNZIkfUq&theme=light&size=invisible&cb=58cf5a5g5ma", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://secure.amp.com.au/", 
		"Snapshot=t95.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/pagead/1p-user-list/684022622/?random=1624946836272&cv=9&fst=1624946400000&num=1&bg=ffffff&guid=ON&eid=2505059651&u_h=1000&u_w=1500&u_ah=960&u_aw=1500&u_cd=24&u_his=5&u_tz=600&u_java=false&u_nplug=3&u_nmime=4&gtm=2oa6n0&sendb=1&data=event%3Dgtag.config&frm=0&url=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&ref=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&tiba=AMP%20Saver%20Account&async=1&fmt=3&is_vtc=1&random=3621861492&resp="
		"GooglemKTybQhCsO&rmt_tld=0&ipr=y", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	web_reg_find("Text=reCAPTCHA", 
		LAST);

	web_url("bframe", 
		"URL=https://www.google.com/recaptcha/api2/bframe?hl=en&v=eKRIyK-9MtX6JxeZcNZIkfUq&k=6LeXti4UAAAAAKwhgrxUbjY-dO-OMHhfK3ePEe4b&cb=htpx5f8fa98u", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://secure.amp.com.au/", 
		"Snapshot=t96.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Origin", 
		"https://www.google.com");

	web_custom_request("reload", 
		"URL=https://www.google.com/recaptcha/api2/reload?k=6LeXti4UAAAAAKwhgrxUbjY-dO-OMHhfK3ePEe4b", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.google.com/recaptcha/api2/bframe?hl=en&v=eKRIyK-9MtX6JxeZcNZIkfUq&k=6LeXti4UAAAAAKwhgrxUbjY-dO-OMHhfK3ePEe4b&cb=htpx5f8fa98u", 
		"Snapshot=t97.inf", 
		"Mode=HTML", 
		"EncType=application/x-protobuffer", 
		"BodyBinary=\n\\x18eKRIyK-9MtX6JxeZcNZIkfUq\\x12\\xF9\n"
		"03AGdBq27bQEpHXGe9QtzYPrfl82vEud8ypWASrf8aDR6W0Sa-Mr96dKO4xyeQPaeHXADS7wiDaNGEm5nxfmak04em6ue1AvI0rD7yhMkgUQcW0QW8DlddPnF5xmcqXBwvNnyYXO-KEMB_U0QDclOfH-MgZ63bBxH8cuJPRnRtLgKQ-PTsoNk2dxs14w3p0gvwW7SKQLiptRQ_qoxHFkT9Y6Mox33x0khdFUQ42jdl0-UUhCX7vGlbYLa8qQbFC5EVTC-NXq94VEgoz5gKWEgQ9sxiSzRi3sYz8BE-eU60qPa5O5rxGCtEDZLXLz0ltxPx16UAKH9Acd9fQ87OCQ_ULV7J3ltNXnGp9pfJvaiMYrbaGypYbudjmddzVq1_-bC7Cc47GGFBUbFpcHxuoqkRXtNS5WxHRwOxuVFi_p1pjotVH19zEwfkoFF3N3EWuaUmtQ0OpiNTJRIck5IGXEd01wLckR1SSJXXSRgQbQWR2asPpM631XNE"
		"501sZ3GxxJ5DX9YPh-K0NqXuwCFHDVtV0qZKC9-C38tVAm_e-fAqV_CN4nQn0reQSxriCNOQFLULqPKwL-k67b8R8EAJfxdNobMcrs-ySIMw05synGzIlMJ8XRnCU6tofxUqhs2s79IFXtHDN_xrNqNDDWNPHT6a_X8sNhHtTk-T0zyyP6DPZINVdw4x6snvGPgv-oOFBjGWudplbRBeUErjTZKbkIFGDObYVdxqpb0kS4TXgnFsuZhYKe5LYAdPZ_bhOslNm08qQAo7QI0CHtdgc5N4pyW0g3-CWwsl5p9EL7Ps2ZIGN9dpjpK4fbRB0nPWI1jFa4E_72kyPeQ_GSzOjUyztla4GrLiCXvz_IMROfJx1LqDi4cz9P4cqdTEk3TfKUqY2jTxfbfkWePDp9PW_IXWV4yPR3VE9QeDf80HIiqBoHoL32caonmrEl06QKEa01swidKqS1EiOJoRFXIEff7BQYZmWJAAZKoCRYFadZUccfjgyx"
		"j0mzz9XR6DJc8jUiYZPxgPVFwMizkf-apM5vA-MnGfGuWT7M5IMo2OBGbNThGWh8pi3t409JhGwY7BbFu5Z3eUWlsawVjwXcZlVXt3RIilLclOqr-y5DpYC7q9FZj9AWm2VQXrKiqwb9wD9G2JY8De3mR6qm584T9UBCVTL2OFzGzruXn2vZ7vrOcfEO5bCLuhUo6rLz2feHz-PmGQkfwkq9CA0MjHrDzJc1bLyl5aS2qKROGy2fCF7QPZmkEBP5qQIoYge2TM7bvj7PwNRg6qQxub9HWVJ2-NQ4XXvv6tKt_GsIuJHYuxukFx_J46rKYlDXZkb0oupmxMiQzm0lRFn29anUbfc3wRqQZOzzM6eY4KN1tK223gh6mFzD92-E8R_GAJ6EMtw1M\\x1A\n[56,51,96]\"\\xFF\\x07"
		"!BQOgAwYKAAQeBaUibQEHDwK1NtBs0V_cQW6EO5uuebdP0tn7DbD9JMkVT8rRw1ye0Cb9aq0yTEuRGWaemyIQbzCHbKYVvNjMUwGnaZpU5nNkIs-nRchUHo0G7eUsAmzWD39zWS09qKrgPXhIsPUAz9hmZ_dQsLNggAkrqDZk-mTBfYgWSJB8rzA8aF9gDkxJzEISBrIILAdSZdLoOeTgAcONs1cPJ6Fm4XJ5GL1VBMgxMwlJSbWVE-kSGyqeGEIvqdSgC0XPKJ8nFCffKKoBTFAfcSrjwVzR_isvhr8JKqNx-6N1yC0G6uK09pMfUEE6y3_8eVMdQ3NfkrPeGom4BGi4gdlT8gQ7TwyF6m9oOSJG9pSUJVsvPqibgP5bRhohRiTiW1HemSc3CtQjtoNptMNhaIAiA6e_oQSUIZahjtW6t3i5pLJ8FQp6RzBqL8nG7CRREw0IsUsQeWeGyUCwW6a6SyuyhYEgtT4FlK2u9u3yPCeFBlbpj"
		"s4Z5WeSegrn0Ml02Tv2DphRFZd8JtHl6TeGR8liZfiwtuCCZPkzcILTNErhwcYq4YrFbltlRx4_1z0Au6QhewyhNpT5YDkHqWY_hIP6uKCb0A3NxneUHUelO2c9SPl8DzRtT9ncCgqEsFkK6yt3NL2lRRuFWJtbckC_rS3-Dta683DFUPoxGxGW6DO6T7mKFLXarXgZoB30B9423X-1AmsKMCQjsDBzsCuFV8x229n-4qg7Z16pdHXcr9HEqOeLgWSrFijQe_GTpBgU5kKLz6SM6nN7B5kl9jDWaNKwR4jUq3dfSzM2JKIi6-XwC9P-9Rnw8q9OZCVT1tH4eAahTSuARh2j5zXmPm8mQukX4qtPrIsp-gNj-Z7YOcyADP6CnHpqLfJJsQkCoPnUbFGgIL0z05HVwibf-kPIBuLBrIptxWvbLjVhQAlAnJSqwemznAA0huNHUbJ6ZsZHmysuWO-tfeickWtKgjHlN2Ct4EqSd6Z9IlVCAET"
		"Gd_RAhlP1nbjXs24zXw*\t"
		"591346933\\x82\\x01\\x81\\x1900YgJfuNRfy-kCXelVcovnct78FXD8VXDO6ochTWqD32rW9A1o9GB9lvJ96ccge8dzUKnFUPzaM07aRmO82GPP7QZh7Vl2j-t24sAZdMBntNmBWq4Kp0gWNlKnjx_6pfrWLBLqi-R_2i0LH4AW8pcuUvCK4_vXsUYcRpXyjOXMKUjmv480VOtFXXObdE0hySF9EqdFcU6nw0762DFM2ERhutZhzesEX-tXdI3pdOD-F3L-akeg_Efz0SpF0XiF8Udc-N93nCSNIrfhQFfmhaFAnTbS7EefRhl5C23GpAplvRW1Tyd51LkZbcurxp-2lm1MH8ff8deuS28_5f7gK4yvxdzyFrvM6IFddUtpRiL9Wb8OdYLuRugGXbMQq7pYdZIsx649ZLHddkh0xiM-32zSdY9pwOOpx-UB23ddrNQhTOYFD21KJsGdAxJ5hvJKKzmZfE8qymN93fhY9w9gNdPxDed"
		"DabjgLVjsjWNJXcMb9whoA2i8HO0OroXeNtJzSyZ8n7oXKctqTSFzT_OKKgRpgBlzC67DHkDYLYcwy9m3F3CMrU1mR5L6kiPQ6MSSLtapSGIy0O2KZUAmtd0qVeoImHZTMAnlTBtCj_tL59NhiCY5HC2HpcldeZgrftz6FbKMsoHpNmH4FjGMcIPk_Y5qELACXDOWr9apCJNxTqnG4McWfYr2Sel-qb-XOc4uzx_z4TyC4P2adVA2he06ZcQiKEZjP9s3nCtSn8tkw43rySX_W0GQ-AVwzy0zUW4K5wGnNl2q1m9SmPbUMArmDJvDEHvRNIgZ99TvzGgCnnlV-4ryP2r52sIZMhKnCd01m_BLaD0ct9IqCieJ3rnbLlHowOE8YHMLIQSmt5_4EGbO4H5WLBfsRmn5Gb0G7MQixZE11alN3wOdc40kBGi6WnzXKcVif1j9STWHXD8c9pJziSJAk__RJckmgFS-i26QngXY9FE0DGu5YfcV6"
		"MjofpW2WvZKY4YV-Au0x5t5VrNM6M8eSmeA3GfPHEfdRNz6T2oFJsKPNA8mTam0nzYWsz5qu2FnRWI_GvVbKlGeymOGjOrIJP5aQI_3BG_IqcKgfpIsgSd_oXSNaQlsg5u7lapP5kVYQNJzyxz4GH8Z78XsvuCvT_OOJDpjt0txDCa7If_UbkowiqN4VPJR7zwcvxSyEO1H5f_fthCwChuBj7qSpgRev91sE-8-HXOXa81zhV77jrFXsw5fhZ-siDSEocUZedOxEKr3mroEYkEbt1NuyGS_mwGQ-AVwzG0zUW6LJcCnNmJ_mPR_5zRf9dmrAe3KEG5Lp0MfuxUwjCeNnMQRfM4wE--G3rURL9Wwitux3vkUZP0iO52rCSiKn0HbqdYkxZe6XWkMJj6kd4tpRiM-GfSRLIaiPaQzWqfTbAaahWJ8iaNNY7ad-QxqUWQ80fuPaIUfctDtiiZBW3jTbsrnC5rCD3rLdz1beBUvy_EAZ7TgdNi"
		"iwN26lG_WpdHvCGPvVqPPZIgnddJqC-wAG_4OMNZlCWjAmfHL3__jMpL4EypAnnqVbtJmxNgEW_RK6QtYuN53jqI9mbtU7RAyEF95mDgOa82ohBDzTKmAIXrYO0-kEGg33i2ZK7_fyJK1UbcH44bagBE3ACZ9ZT-QtNOrSBS8kC5QbIdeeJ1ryid6Z3HY6YfoOdpAzTES6AGV9kw3jOUFZvqfbc4fyhuyYG7JIoUjwtxwjLGGZnleqoslyV-z13PMscxdOpIyzKm93YbgPM5qv-BEVTUQ6wDiRJisCejE58KiLY9sTqMFZL7R9IhqvCF4UyoPJkHYgVJ2AanI3PDZc1RfAhw1TTbJ33ma8JNuEShHo7YUMQ2fyF3xXbGSZgAWQBP1S6lMGDxXewQmjJd0FjcU6gYaO1f0BeWLH_kcPRAjRSN8kHtUIkwfh1gxFGcGm4EZ9hUyAB87YzsJ6JHqvuQ_Gu5E43-YvFavTmME2rbYN8ojilo5S"
		"-8I6YecOdD1juX-pPySNVIuwho6WCdTpUFcshK2SLEK3z5Zb0uuTN43U3IObDucuhNp1eo8J4FW6hfhhOfCH7HFMMyguWE7laqPGYQibQ_pQuD64CvUb47iwlJ-2CoNaghS91gkP6gGIO1NJEIi_Nx3WjWGqkXgfholhSZA4bQUNEeu-dq3GW8O5LgcNNo1EurA2vkY7c-mgN_3XPDIKUrfQlnyUCb_3IAf-IwlTGN6jThR54ge_5fu0m394QAQMlSuzOrE1_sNscypxt5zT6mAIH3YesknjKBEEjiScsfiPqNx2DYR6seiNJtqkSr-nC3RKgpmAB14UbRF5nwP7cqnAx0DkvoHcskmgRv8k7DLav2Rb0ypQt7FFHuI9EKwjFaBHq_EoEiWgtRuBWRF3zbOskxkjiGCGGrNKQDfvaC8Sm4OH4RQuJYyhR65lPhY9EWYvJe9C6cCqboYrY7niB-8GbYM5AxtAiG3iWnEHTsZ8k8ljSR_4jB"
		"QrYbix9u8mnhGK4pi950niCM5ZTEQLMmewp723LDMYv9aupR1jaiHZnsaOdMgf6dDlTERZMAkhBSqTTACI8Vdb07uyVw92LHGos9fuZO0zOZCJ73faobjg996HzMT6BBrfVq2hyfMoPwWcg80yKMEFrIWoP7buFLv1KPLGEPcsto0hyo0Um8MJcLd-FTvi-fNHEOQ_FM0g1p4VTHMqE4dRJH9WaiNn4dd-961kWwGmv9eOhXuAyf5XLdTasWXxBMvlGG41vOQrEbsu-MwW_EUqw8hPV7tlGuDKgZi-pdrB5952DGQZ4TpO1ktjagN4nuWeZZwhit93vAWa8mc89HvCidB57beK1bwCSu5IfUY78niPWTyGutLa8hccdYzDG2EJy1LaAUffKEwV6TQaQujftL6gN78F7NOdIPg_Vfx2SZR5wyn-U-z1u9IngHVvRCsC9VzUCyIookYf4zwjqzLanyjcYgwDV_GnbwItcxgv5Upx-YBm_eUb"
		"somgqc2XarWbM8uBBO-WicIqoScvlN2EmS94rkQ8Uqei6axWWyLpMbV-BwxCqMIIC3L6IVfeyGw2CVQ4YSeMtd70-lHqcKgetNuvSFzlzGM7swatBTwBmfLFXNQLMfkiRh_jPCOq8SaAdF7WGrD3_ad_1LxzBt_lSnH5IEc-J2s1CFM6IZi-tcpjqPBHO7P8wNmRRr-UDgT5gAirEpnhB66oDu2\\x02fir(6LeXti4UAAAAAKwhgrxUbjY-dO-OMHhfK3ePEe4b", 
		EXTRARES, 
		"Url=https://www.gstatic.com/recaptcha/api2/canonical_car.png", "Referer=https://www.gstatic.com/recaptcha/releases/eKRIyK-9MtX6JxeZcNZIkfUq/styles__ltr.css", ENDITEM, 
		"Url=https://www.gstatic.com/recaptcha/api2/refresh_2x.png", "Referer=https://www.gstatic.com/recaptcha/releases/eKRIyK-9MtX6JxeZcNZIkfUq/styles__ltr.css", ENDITEM, 
		"Url=https://www.gstatic.com/recaptcha/api2/audio_2x.png", "Referer=https://www.gstatic.com/recaptcha/releases/eKRIyK-9MtX6JxeZcNZIkfUq/styles__ltr.css", ENDITEM, 
		"Url=https://www.gstatic.com/recaptcha/api2/info_2x.png", "Referer=https://www.gstatic.com/recaptcha/releases/eKRIyK-9MtX6JxeZcNZIkfUq/styles__ltr.css", ENDITEM, 
		"Url=payload?p=06AGdBq27DPSGttpaN791Mj9ul9AfgE4wnM7h4CbMpU9QMqTRhM5amfjoPdmUIvAP_3wldSgBA8Nc0oVpvmKo5Eoal_6xOZ6nEuAiQNvl59_bmoQXAOxTo7HjJrhBLZtJJozQ2rPRsvIVaKL6G7JvV-IfQRybWQT9QkmRWkMtnkFqX7ucZF388tDcGJhuxdYmD-XH2P8poMbl2wg_pvHW7x1nrxC3JgpOeDA&k=6LeXti4UAAAAAKwhgrxUbjY-dO-OMHhfK3ePEe4b", "Referer=https://www.google.com/recaptcha/api2/bframe?hl=en&v=eKRIyK-9MtX6JxeZcNZIkfUq&k=6LeXti4UAAAAAKwhgrxUbjY-dO-OMHhfK3ePEe4b&cb=htpx5f8fa98u", ENDITEM, 
		"Url=https://fonts.gstatic.com/s/roboto/v18/KFOlCnqEu92Fr1MmYUtfBBc4.woff2", "Referer=https://www.google.com/", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"iframe");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("pixel", 
		"URL=https://bid.g.doubleclick.net/xbbe/pixel?d=KAE", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://secure.amp.com.au/", 
		"Snapshot=t98.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://assets.adobedtm.com/30cb14f656a0/44b143ec5db5/5fde423c5655/RC37108aa621a541e2b2714e327f183124-source.min.js", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s8148662506216?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A7%3A43%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=DDC%3AAMP%20Saver%20Account&g=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&cc=AUD&events=event67&c16=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&v16=D%3Dc16&c25="
		"DDC%3AAMP%20Saver%20Account%3Abtn-welcome-New%20application&v25=DDC%3AAMP%20Saver%20Account%3Abtn-welcome-New%20application&pe=lnk_o&pev2=link%20clicked&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=1558&AQE=1", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s85374352614372?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A7%3A43%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=DDC%3AAMP%20Saver%20Account&g=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&cc=AUD&events=event67&c16=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&v16=D%3Dc16&v25=DDC%3AAMP%20Saver%3Anew%20application&pe=lnk_o&"
		"pev2=link%20clicked&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&AQE=1", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s85164438979605?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A7%3A43%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=DDC%3AAMP%20Saver%20Account&g=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&cc=AUD&events=event3&c16=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&v16=D%3Dc16&pe=lnk_o&pev2=link%20clicked&s=1500x1000&c=24&j=1.6&v"
		"=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&AQE=1", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates_fetch?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINOTEuMC40NDcyLjExNBopCAUQARobCg0IBRAGGAEiAzAwMTABENHSCxoCGAMByhKdIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARCHiAkaAhgD-pxkQCIEIAEgAigBGikIAxABGhsKDQgDEAYYASIDMDAxMAEQluwIGgIYA8nIWJMiBCABIAIoARopCAcQARobCg0IBxAGGAEiAzAwMTABEMDFCRoCGAMyqKIOIgQgASACKAEaJwgBEAEaGQoNCAEQBhgBIgMwMDEwAxAUGgIYA1m8dH0iBCABIAIoAxooCAEQCBoaCg0IARAIGAEiAzAwMTAEEIghGgIYA4AH7SMiBCABIAIoBBonCAkQARoZCg0ICRAGGAEiAzAwMTAGEAMaAhgDcqfsqSIEIAEgAigGGigIDxABGhoKDQgPEAYYASIDMDAxMAEQqG8aAhgDTgKK6yIEIAEgAigBGicIChAIGh"
		"kKDQgKEAgYASIDMDAxMAEQBxoCGAN3Vzc4IgQgASACKAEaJwgJEAEaGQoNCAkQBhgBIgMwMDEwARAfGgIYA056200iBCABIAIoARooCAgQARoaCg0ICBAGGAEiAzAwMTABELgMGgIYA8y4EuMiBCABIAIoARopCA0QARobCg0IDRAGGAEiAzAwMTABEIOcARoCGAORKttuIgQgASACKAEaKQgOEAEaGwoNCA4QBhgBIgMwMDEwARCw4gUaAhgD2T1tjiIEIAEgAigBGigIEBABGhoKDQgQEAYYASIDMDAxMAEQxQsaAhgDiPg60yIEIAEgAigBIgIIAQ==&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("05_open account",LR_AUTO);

	lr_start_transaction("06_Click on new application");

	lr_end_transaction("06_Click on new application",LR_AUTO);

	lr_start_transaction("07_click new customer");

	lr_end_transaction("07_click new customer",LR_AUTO);

	lr_start_transaction("08_Whos this account for");

	web_add_auto_header("Origin", 
		"https://secure.amp.com.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_custom_request("save", 
		"URL=https://secure.amp.com.au/ddc/public/api/forms/save?&formName=SaverAccount", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t99.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":null,\"surName\":null,\"dateOfBirth\":null,\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":null,\"Query\":null},\"middleName\":null},\"contactDetails\":{\"emailAddress\":null,\""
		"mobilePhone\":null,\"homePhone\":null},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":null,\"query\":null},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\",\"Query\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":null,\"streetName\":null,\"streetType\":{\"SelectedItem\":null,\""
		"Query\":null},\"poBox\":null,\"suburb\":null,\"state\":{\"SelectedItem\":null,\"Query\":null},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":null,\"dpid\":null,\"barcode\":null,\"isInternational\":false},\"isItPoBox\":null},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":null,\"ok\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\""
		"applicants.0.personalDetails.address\",\"crsStatus\":null,\"addresses\":[null,null],\"countries\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":null},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":null,\"Query\":null},\"sourceOfFundsForAccount\":{\"SelectedItem\":null,\"Query\":null},\"reasonForOpeningAccount\":{\"SelectedItem\":null,\"Query\":null}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\""
		"verificationId\":null,\"verificationStatus\":null},\"creditHeaderCheckbox\":null}}}],\"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}", 
		LAST);

	lr_end_transaction("08_Whos this account for",LR_AUTO);

	lr_start_transaction("09_Tell us about yourself");

	lr_start_transaction("10_Tell us about yourself");

	web_custom_request("save_2", 
		"URL=https://secure.amp.com.au/ddc/public/api/forms/save?formId=2529013615&checkSecurityToken=fceb0ffc-5d0a-4a90-9b8a-db35c2500b0b&formName=SaverAccount&checkDob=01/01/2000&checkName=Test", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t100.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"Perf\",\"surName\":\"Test\",\"dateOfBirth\":\"01/01/2000\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"Mr\",\"Query\":\"Mr\"},\"middleName\":null},\"contactDetails\":{\""
		"emailAddress\":null,\"mobilePhone\":null,\"homePhone\":null},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":null,\"query\":null},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\",\"Query\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":null,\"streetName\":null,\"streetType\":{\""
		"SelectedItem\":null,\"Query\":null},\"poBox\":null,\"suburb\":null,\"state\":{\"SelectedItem\":null,\"Query\":null},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":null,\"dpid\":null,\"barcode\":null,\"isInternational\":false},\"isItPoBox\":null},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":null,\"ok\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\""
		"applicants.0.personalDetails.address\",\"crsStatus\":null,\"addresses\":[null,null],\"countries\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":null},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":null,\"Query\":null},\"sourceOfFundsForAccount\":{\"SelectedItem\":null,\"Query\":null},\"reasonForOpeningAccount\":{\"SelectedItem\":null,\"Query\":null}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\""
		"verificationId\":null,\"verificationStatus\":null},\"creditHeaderCheckbox\":null}}}],\"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}", 
		EXTRARES, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s88324701281058?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A9%3A15%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=DDC%3AAMP%20Saver%20Account&g=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&cc=AUD&events=event67&c16=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&v16=D%3Dc16&c25="
		"DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-personalDetails-basicInfo-OK&v25=DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-personalDetails-basicInfo-OK&pe=lnk_o&pev2=link%20clicked&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=61&AQE=1", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	lr_end_transaction("09_Tell us about yourself",LR_AUTO);

	lr_end_transaction("10_Tell us about yourself",LR_AUTO);

	lr_start_transaction("11_Where do you live");

	web_revert_auto_header("Origin");

	web_add_auto_header("caller", 
		"saver-account");

	web_custom_request("church", 
		"URL=https://secure.amp.com.au/ddc/public/api/qas/doSearch/AUS/church?residentialOnly=true", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t101.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("church%20s", 
		"URL=https://secure.amp.com.au/ddc/public/api/qas/doSearch/AUS/church%20s?residentialOnly=true", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t102.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("church%20st", 
		"URL=https://secure.amp.com.au/ddc/public/api/qas/doSearch/AUS/church%20st?residentialOnly=true", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t103.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("church%20stree", 
		"URL=https://secure.amp.com.au/ddc/public/api/qas/doSearch/AUS/church%20stree?residentialOnly=true", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t104.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("church%20street", 
		"URL=https://secure.amp.com.au/ddc/public/api/qas/doSearch/AUS/church%20street?residentialOnly=true", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t105.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_custom_request("AUS%7C4eaba770-c647-42c2-afac-46a4d4fc542b%7C7.7304OAUSHATlBwAAAAAIAgEAAAAABms2UAAgAAAAAAAAAAD..2QAAAAA.....wAAAAAAAAAAAAAAAAAAAGNodXJjaCBzdHJlZXQAAAAAAA--$13", 
		"URL=https://secure.amp.com.au/ddc/public/api/qas/doGetAddress/AUS/AUS%7C4eaba770-c647-42c2-afac-46a4d4fc542b%7C7.7304OAUSHATlBwAAAAAIAgEAAAAABms2UAAgAAAAAAAAAAD..2QAAAAA.....wAAAAAAAAAAAAAAAAAAAGNodXJjaCBzdHJlZXQAAAAAAA--$13?partialAddress=1%20Church%20Street,%20ABERMAIN%20%20NSW%20%202326", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t106.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		EXTRARES, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s88142858856986?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A9%3A44%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=DDC%3AAMP%20Saver%20Account&g=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&cc=AUD&events=event67&c16=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&v16=D%3Dc16&c25="
		"DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-personalDetails-address-OK&v25=DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-personalDetails-address-OK&pe=lnk_o&pev2=link%20clicked&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=243&AQE=1", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	web_revert_auto_header("caller");

	web_add_auto_header("Origin", 
		"https://secure.amp.com.au");

	web_custom_request("save_3", 
		"URL=https://secure.amp.com.au/ddc/public/api/forms/save?formId=2529013615&checkSecurityToken=fceb0ffc-5d0a-4a90-9b8a-db35c2500b0b&formName=SaverAccount&checkDob=01/01/2000&checkName=Test", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t107.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"Perf\",\"surName\":\"Test\",\"dateOfBirth\":\"01/01/2000\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"Mr\",\"Query\":\"Mr\"},\"middleName\":null},\"contactDetails\":{\""
		"emailAddress\":null,\"mobilePhone\":null,\"homePhone\":null},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":\"AUS|4eaba770-c647-42c2-afac-46a4d4fc542b|7.7304OAUSHATlBwAAAAAIAgEAAAAABms2UAAgAAAAAAAAAAD..2QAAAAA.....wAAAAAAAAAAAAAAAAAAAGNodXJjaCBzdHJlZXQAAAAAAA--$13\",\"query\":\"1 Church Street, ABERMAIN  NSW  2326\"},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\",\"Query\":\"Australia\"},\""
		"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":\"1\",\"streetName\":\"Church\",\"streetType\":{\"SelectedItem\":\"ST\",\"Query\":\"Street\"},\"poBox\":null,\"suburb\":\"Abermain\",\"state\":{\"SelectedItem\":\"NSW\",\"Query\":\"NSW\"},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":\"2326\",\"dpid\":\"71670272\",\"barcode\":\"1301012101202100022102301330203203313\",\""
		"isInternational\":false},\"isItPoBox\":false},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":null,\"ok\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\"applicants.0.personalDetails.address\",\"crsStatus\":null,\"addresses\":[\"1 Church Street, ABERMAIN  NSW  2326\",\"1 Church Street, ABERMAIN  NSW  2326\"],\"countries\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\""
		"isForeignTaxResident\":null},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":null,\"Query\":null},\"sourceOfFundsForAccount\":{\"SelectedItem\":null,\"Query\":null},\"reasonForOpeningAccount\":{\"SelectedItem\":null,\"Query\":null}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\"verificationId\":null,\"verificationStatus\":null},\"creditHeaderCheckbox\":null}}}],\"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep"
		"\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}", 
		EXTRARES, 
		"Url=https://assets.adobedtm.com/30cb14f656a0/44b143ec5db5/5fde423c5655/RC9d84032629764986be28d0428cc31635-source.min.js", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	lr_end_transaction("11_Where do you live",LR_AUTO);

	lr_start_transaction("12_what are your contact details");

	web_custom_request("save_4", 
		"URL=https://secure.amp.com.au/ddc/public/api/forms/save?formId=2529013615&checkSecurityToken=fceb0ffc-5d0a-4a90-9b8a-db35c2500b0b&formName=SaverAccount&checkDob=01/01/2000&checkName=Test", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t108.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"Perf\",\"surName\":\"Test\",\"dateOfBirth\":\"01/01/2000\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"Mr\",\"Query\":\"Mr\"},\"middleName\":null},\"contactDetails\":{\""
		"emailAddress\":\"perftest03@gmail.com\",\"mobilePhone\":\"0444444444\",\"homePhone\":null},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":\"AUS|4eaba770-c647-42c2-afac-46a4d4fc542b|7.7304OAUSHATlBwAAAAAIAgEAAAAABms2UAAgAAAAAAAAAAD..2QAAAAA.....wAAAAAAAAAAAAAAAAAAAGNodXJjaCBzdHJlZXQAAAAAAA--$13\",\"query\":\"1 Church Street, ABERMAIN  NSW  2326\"},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\","
		"\"Query\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":\"1\",\"streetName\":\"Church\",\"streetType\":{\"SelectedItem\":\"ST\",\"Query\":\"Street\"},\"poBox\":null,\"suburb\":\"Abermain\",\"state\":{\"SelectedItem\":\"NSW\",\"Query\":\"NSW\"},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":\"2326\",\"dpid\":\"71670272\",\"barcode\":\""
		"1301012101202100022102301330203203313\",\"isInternational\":false},\"isItPoBox\":false},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":null,\"ok\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\"applicants.0.personalDetails.address\",\"crsStatus\":null,\"addresses\":[\"1 Church Street, ABERMAIN  NSW  2326\",\"1 Church Street, ABERMAIN  NSW  2326\"],\"countries\":[\"AUS\",\""
		"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":null},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":null,\"Query\":null},\"sourceOfFundsForAccount\":{\"SelectedItem\":null,\"Query\":null},\"reasonForOpeningAccount\":{\"SelectedItem\":null,\"Query\":null}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\"verificationId\":null,\"verificationStatus\":null},\"creditHeaderCheckbox\":null}}}],\"accountDetails\":{\""
		"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"iframe");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("activityi;src=8836193;type=remarket;cat=amp_s006;ord=5093219013899;gtm=2od6n0;auiddc=1626384231.1624946690;ps=1;~oref=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F", 
		"URL=https://8836193.fls.doubleclick.net/activityi;src=8836193;type=remarket;cat=amp_s006;ord=5093219013899;gtm=2od6n0;auiddc=1626384231.1624946690;ps=1;~oref=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F?", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://secure.amp.com.au/", 
		"Snapshot=t109.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_url("activityi;register_conversion=1;src=8836193;type=remarket;cat=amp_s006;ord=5093219013899;gtm=2od6n0;auiddc=1626384231.1624946690;ps=1;~oref=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F", 
		"URL=https://8836193.fls.doubleclick.net/activityi;register_conversion=1;src=8836193;type=remarket;cat=amp_s006;ord=5093219013899;gtm=2od6n0;auiddc=1626384231.1624946690;ps=1;~oref=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F?", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://secure.amp.com.au/", 
		"Snapshot=t110.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s86468392318921?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A10%3A19%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=DDC%3AAMP%20Saver%20Account&g=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&cc=AUD&events=event67&c16=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&v16=D%3Dc16&c25="
		"DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-personalDetails-contactDetails-OK&v25=DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-personalDetails-contactDetails-OK&pe=lnk_o&pev2=link%20clicked&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=48&AQE=1", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s86479768485695?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A10%3A39%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=DDC%3AAMP%20Saver%20Account&g=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&cc=AUD&events=event67&c16=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&v16=D%3Dc16&c25="
		"DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-furtherQuestions-taxFileNumber-OK-yes&v25=DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-furtherQuestions-taxFileNumber-OK-yes&pe=lnk_o&pev2=link%20clicked&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=1338&AQE=1", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	lr_end_transaction("12_what are your contact details",LR_AUTO);

	lr_start_transaction("12_do you have tax file number");

	web_add_header("Origin", 
		"https://secure.amp.com.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_custom_request("save_5", 
		"URL=https://secure.amp.com.au/ddc/public/api/forms/save?formId=2529013615&checkSecurityToken=fceb0ffc-5d0a-4a90-9b8a-db35c2500b0b&formName=SaverAccount&checkDob=01/01/2000&checkName=Test", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t111.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"Perf\",\"surName\":\"Test\",\"dateOfBirth\":\"01/01/2000\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"Mr\",\"Query\":\"Mr\"},\"middleName\":null},\"contactDetails\":{\""
		"emailAddress\":\"perftest03@gmail.com\",\"mobilePhone\":\"0444444444\",\"homePhone\":null},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":\"AUS|4eaba770-c647-42c2-afac-46a4d4fc542b|7.7304OAUSHATlBwAAAAAIAgEAAAAABms2UAAgAAAAAAAAAAD..2QAAAAA.....wAAAAAAAAAAAAAAAAAAAGNodXJjaCBzdHJlZXQAAAAAAA--$13\",\"query\":\"1 Church Street, ABERMAIN  NSW  2326\"},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\","
		"\"Query\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":\"1\",\"streetName\":\"Church\",\"streetType\":{\"SelectedItem\":\"ST\",\"Query\":\"Street\"},\"poBox\":null,\"suburb\":\"Abermain\",\"state\":{\"SelectedItem\":\"NSW\",\"Query\":\"NSW\"},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":\"2326\",\"dpid\":\"71670272\",\"barcode\":\""
		"1301012101202100022102301330203203313\",\"isInternational\":false},\"isItPoBox\":false},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":true,\"ok\":true,\"taxFileNumber\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\"applicants.0.personalDetails.address\",\"crsStatus\":null,\"addresses\":[\"1 Church Street, ABERMAIN  NSW  2326\",\"1 Church Street, ABERMAIN  NSW  2326\"],\""
		"countries\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":null},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":null,\"Query\":null},\"sourceOfFundsForAccount\":{\"SelectedItem\":null,\"Query\":null},\"reasonForOpeningAccount\":{\"SelectedItem\":null,\"Query\":null}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\"verificationId\":null,\"verificationStatus\":null},\"creditHeaderCheckbox\":null}}}],\""
		"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}", 
		EXTRARES, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s85560874686834?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A11%3A6%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=DDC%3AAMP%20Saver%20Account&g=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&cc=AUD&events=event67&c16=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&v16=D%3Dc16&c25="
		"DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-furtherQuestions-foreignTaxResident-OK&v25=DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-furtherQuestions-foreignTaxResident-OK&pe=lnk_o&pev2=link%20clicked&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=53&AQE=1", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	lr_end_transaction("12_do you have tax file number",LR_AUTO);

	lr_start_transaction("13_are you foreign tax resident");

	web_url("individual", 
		"URL=https://secure.amp.com.au/ddc/public/api/api-crs/AUS/individual?resCountry=AUS&postalCountry=AUS", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t112.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"https://secure.amp.com.au");

	web_custom_request("save_6", 
		"URL=https://secure.amp.com.au/ddc/public/api/forms/save?formId=2529013615&checkSecurityToken=fceb0ffc-5d0a-4a90-9b8a-db35c2500b0b&formName=SaverAccount&checkDob=01/01/2000&checkName=Test", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t113.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"Perf\",\"surName\":\"Test\",\"dateOfBirth\":\"01/01/2000\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"Mr\",\"Query\":\"Mr\"},\"middleName\":null},\"contactDetails\":{\""
		"emailAddress\":\"perftest03@gmail.com\",\"mobilePhone\":\"0444444444\",\"homePhone\":null},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":\"AUS|4eaba770-c647-42c2-afac-46a4d4fc542b|7.7304OAUSHATlBwAAAAAIAgEAAAAABms2UAAgAAAAAAAAAAD..2QAAAAA.....wAAAAAAAAAAAAAAAAAAAGNodXJjaCBzdHJlZXQAAAAAAA--$13\",\"query\":\"1 Church Street, ABERMAIN  NSW  2326\"},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\","
		"\"Query\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":\"1\",\"streetName\":\"Church\",\"streetType\":{\"SelectedItem\":\"ST\",\"Query\":\"Street\"},\"poBox\":null,\"suburb\":\"Abermain\",\"state\":{\"SelectedItem\":\"NSW\",\"Query\":\"NSW\"},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":\"2326\",\"dpid\":\"71670272\",\"barcode\":\""
		"1301012101202100022102301330203203313\",\"isInternational\":false},\"isItPoBox\":false},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":true,\"ok\":true,\"taxFileNumber\":null,\"change\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\"applicants.0.personalDetails.address\",\"crsStatus\":\"pass\",\"addresses\":[\"1 Church Street, ABERMAIN  NSW  2326\",\"1 Church Street, "
		"ABERMAIN  NSW  2326\"],\"countries\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":false},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":null,\"Query\":null},\"sourceOfFundsForAccount\":{\"SelectedItem\":null,\"Query\":null},\"reasonForOpeningAccount\":{\"SelectedItem\":null,\"Query\":null}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\"verificationId\":null,\"verificationStatus\":null},\""
		"creditHeaderCheckbox\":null}}}],\"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}", 
		EXTRARES, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s85666849331048?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A11%3A38%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=DDC%3AAMP%20Saver%20Account&g=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&cc=AUD&events=event67&c16=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&v16=D%3Dc16&c25="
		"DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-furtherQuestions-amlQuestions-OK&v25=DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-furtherQuestions-amlQuestions-OK&pe=lnk_o&pev2=link%20clicked&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=37&AQE=1", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	lr_end_transaction("13_are you foreign tax resident",LR_AUTO);

	lr_start_transaction("14_Some extra details we need");

	web_custom_request("save_7", 
		"URL=https://secure.amp.com.au/ddc/public/api/forms/save?formId=2529013615&checkSecurityToken=fceb0ffc-5d0a-4a90-9b8a-db35c2500b0b&formName=SaverAccount&checkDob=01/01/2000&checkName=Test", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t114.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"Perf\",\"surName\":\"Test\",\"dateOfBirth\":\"01/01/2000\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"Mr\",\"Query\":\"Mr\"},\"middleName\":null},\"contactDetails\":{\""
		"emailAddress\":\"perftest03@gmail.com\",\"mobilePhone\":\"0444444444\",\"homePhone\":null},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":\"AUS|4eaba770-c647-42c2-afac-46a4d4fc542b|7.7304OAUSHATlBwAAAAAIAgEAAAAABms2UAAgAAAAAAAAAAD..2QAAAAA.....wAAAAAAAAAAAAAAAAAAAGNodXJjaCBzdHJlZXQAAAAAAA--$13\",\"query\":\"1 Church Street, ABERMAIN  NSW  2326\"},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\","
		"\"Query\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":\"1\",\"streetName\":\"Church\",\"streetType\":{\"SelectedItem\":\"ST\",\"Query\":\"Street\"},\"poBox\":null,\"suburb\":\"Abermain\",\"state\":{\"SelectedItem\":\"NSW\",\"Query\":\"NSW\"},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":\"2326\",\"dpid\":\"71670272\",\"barcode\":\""
		"1301012101202100022102301330203203313\",\"isInternational\":false},\"isItPoBox\":false},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":true,\"ok\":true,\"taxFileNumber\":null,\"change\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\"applicants.0.personalDetails.address\",\"crsStatus\":\"pass\",\"addresses\":[\"1 Church Street, ABERMAIN  NSW  2326\",\"1 Church Street, "
		"ABERMAIN  NSW  2326\"],\"countries\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":false},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":\"WIE\",\"Query\":\"Income from employment (regular and/or bonus)\"},\"sourceOfFundsForAccount\":{\"SelectedItem\":\"FII\",\"Query\":\"Investment income (e.g. rent, dividends, pension)\"},\"reasonForOpeningAccount\":{\"SelectedItem\":\"EB\",\"Query\":\"Everyday banking (e.g. regular"
		" deposits and withdrawals for everyday expenses)\"}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\"verificationId\":null,\"verificationStatus\":null},\"creditHeaderCheckbox\":null}}}],\"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}", 
		EXTRARES, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s81172044042328?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A11%3A58%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=DDC%3AAMP%20Saver%20Account&g=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&cc=AUD&events=event67&c16=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&v16=D%3Dc16&c25="
		"DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-identityCheck-identity-OK-EnableRegister&v25=DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-identityCheck-identity-OK-EnableRegister&pe=lnk_o&pev2=link%20clicked&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=64&AQE=1", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://simpleui-au.vixverify.com/df/javascripts/greenidConfig.js", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://simpleui-au.vixverify.com/df/javascripts/greenidui.min.js", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://simpleui-au.vixverify.com/df/assets/stylesheets/greenid.css", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://simpleui-au.vixverify.com/df/assets/stylesheets/uploadifive.css", "Referer=https://simpleui-au.vixverify.com/df/assets/stylesheets/greenid.css", ENDITEM, 
		LAST);

	lr_end_transaction("14_Some extra details we need",LR_AUTO);

	lr_start_transaction("16_verify your identy online");

	web_custom_request("register", 
		"URL=https://secure.amp.com.au/ddc/public/api/green-id/register", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t115.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"title\":\"Mr\",\"firstName\":\"Perf\",\"middleNames\":\"\",\"lastName\":\"Test\",\"dateOfBirth\":\"01/01/2000\",\"email\":\"perftest03@gmail.com\",\"address\":{\"country\":\"AU\",\"state\":\"NSW\",\"streetName\":\"Church\",\"flatNumber\":\"\",\"streetNumber\":\"1\",\"suburb\":\"Abermain\",\"postcode\":\"2326\",\"streetType\":\"ST\",\"townCity\":\"\"},\"extraData\":[{\"name\":\"dnb-credit-header-consent-given\",\"value\":\"true\"}]}", 
		LAST);

	web_revert_auto_header("Origin");

	web_custom_request("token_3", 
		"URL=https://secure.amp.com.au/ddc/public/api/green-id/token?verificationId=k1nxnJEB", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t116.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	web_add_auto_header("Origin", 
		"https://secure.amp.com.au");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_custom_request("getsources", 
		"URL=https://simpleui-au.vixverify.com/df/getsources", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/", 
		"Snapshot=t117.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body={\"accountId\":\"amp_au\",\"apiCode\":\"F2x-L5D-7wW-EY4\",\"verificationToken\":\"b73726f3684ab793137f7e18d60f36aa3dd1a5c0\",\"origin\":\"simpleui\"}", 
		EXTRARES, 
		"Url=assets/images/loader.gif", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=assets/templates/intro.hb?_=1624947120658", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=javascripts/greenidui_privsec_bdm.min.js", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=assets/templates/sourcelist.hb?_=1624947120659", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	web_custom_request("getfields", 
		"URL=https://simpleui-au.vixverify.com/df/getfields", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/", 
		"Snapshot=t118.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body={\"accountId\":\"amp_au\",\"apiCode\":\"F2x-L5D-7wW-EY4\",\"verificationToken\":\"b73726f3684ab793137f7e18d60f36aa3dd1a5c0\",\"sourceId\":\"nswregodvs\",\"origin\":\"simpleui\"}", 
		EXTRARES, 
		"Url=assets/templates/fieldsform.hb?_=1624947120661", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=assets/templates/sourceheader.hb?_=1624947120660", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	web_custom_request("log", 
		"URL=https://simpleui-au.vixverify.com/df/log", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://secure.amp.com.au/", 
		"Snapshot=t119.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body=[{\"message\":\"Setting overrides\",\"overrides\":\"sessionCompleteCallback sessionCancelledCallback enableBackButtonWarning enableCancelButton \",\"verificationId\":\"\",\"verificationToken\":\"\",\"accountId\":\"\",\"version\":\"\",\"logId\":\"xf3bhxgn\",\"level\":\"INFO\",\"datetime\":\"2021-06-29 16:12:00:675\"},{\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36\",\"winHeight\":\"857\",\"docHeight\":\"6021\""
		",\"winWidth\":\"1483\",\"docWidth\":\"1483\",\"url\":\"https://secure.amp.com.au/ddc/public/ui/saver-account/\",\"message\":\"Client Info\",\"verificationId\":\"\",\"verificationToken\":\"\",\"accountId\":\"\",\"version\":\"21.0622.0_7e17ac71_63\",\"logId\":\"xf3bhxgn\",\"datetime\":\"2021-06-29 16:12:00:677\"},{\"message\":\"Entered show\",\"verificationId\":\"\",\"verificationToken\":\"b73726f3684ab793137f7e18d60f36aa3dd1a5c0\",\"accountId\":\"amp_au\",\"version\":\"21.0622.0_7e17ac71_63\",\""
		"logId\":\"xf3bhxgn\",\"level\":\"INFO\",\"datetime\":\"2021-06-29 16:12:02:449\"},{\"message\":\"Entered handleStartSuccess\",\"verificationId\":\"\",\"verificationToken\":\"b73726f3684ab793137f7e18d60f36aa3dd1a5c0\",\"accountId\":\"amp_au\",\"version\":\"21.0622.0_7e17ac71_63\",\"logId\":\"xf3bhxgn\",\"level\":\"INFO\",\"datetime\":\"2021-06-29 16:12:03:144\"},{\"accountId\":\"amp_au\",\"verificationToken\":\"b73726f3684ab793137f7e18d60f36aa3dd1a5c0\",\"attemptId\":\"\",\"userAgent\":\"Mozilla/"
		"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36\",\"platform\":\"Windows\",\"message\":\"greenID Web - Start workflow point\",\"pointOfInterest\":\"HandleStartSuccess\",\"poiOrder\":\"10\",\"verificationId\":\"\",\"version\":\"21.0622.0_7e17ac71_63\",\"logId\":\"xf3bhxgn\",\"level\":\"INFO\",\"datetime\":\"2021-06-29 16:12:03:144\"},{\"message\":\"dl is the next source, with order 0\",\"verificationId\":\"\",\"verificationToken\":\""
		"b73726f3684ab793137f7e18d60f36aa3dd1a5c0\",\"accountId\":\"amp_au\",\"version\":\"21.0622.0_7e17ac71_63\",\"logId\":\"xf3bhxgn\",\"level\":\"INFO\",\"datetime\":\"2021-06-29 16:12:03:159\"},{\"source\":\"dl\",\"message\":\"Loading first source\",\"verificationId\":\"\",\"verificationToken\":\"b73726f3684ab793137f7e18d60f36aa3dd1a5c0\",\"accountId\":\"amp_au\",\"version\":\"21.0622.0_7e17ac71_63\",\"logId\":\"xf3bhxgn\",\"level\":\"INFO\",\"datetime\":\"2021-06-29 16:12:03:159\"},{\"source\":\"dl\""
		",\"message\":\"Entered getFields: \",\"verificationId\":\"\",\"verificationToken\":\"b73726f3684ab793137f7e18d60f36aa3dd1a5c0\",\"accountId\":\"amp_au\",\"version\":\"21.0622.0_7e17ac71_63\",\"logId\":\"xf3bhxgn\",\"level\":\"INFO\",\"datetime\":\"2021-06-29 16:12:03:159\"},{\"source\":\"nswregodvs\",\"message\":\"Entered showFields Form: nswregodvs\",\"verificationId\":\"\",\"verificationToken\":\"b73726f3684ab793137f7e18d60f36aa3dd1a5c0\",\"accountId\":\"amp_au\",\"version\":\""
		"21.0622.0_7e17ac71_63\",\"logId\":\"xf3bhxgn\",\"level\":\"INFO\",\"datetime\":\"2021-06-29 16:12:04:216\"},{\"message\":\"Entered initiateSourceyThings: nswregodvs\",\"verificationId\":\"\",\"verificationToken\":\"b73726f3684ab793137f7e18d60f36aa3dd1a5c0\",\"accountId\":\"amp_au\",\"version\":\"21.0622.0_7e17ac71_63\",\"logId\":\"xf3bhxgn\",\"level\":\"INFO\",\"datetime\":\"2021-06-29 16:12:04:284\"}]", 
		EXTRARES, 
		"Url=assets/fonts/glyphicons/glyphicons-halflings-regular.woff2", "Referer=https://simpleui-au.vixverify.com/df/assets/stylesheets/greenid.css", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s8507544421029?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A12%3A27%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=DDC%3AAMP%20Saver%20Account&g=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&cc=AUD&events=event67&c16=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&v16=D%3Dc16&c25="
		"DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-identityCheck-identity-SkipIdCheck&v25=DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-identityCheck-identity-SkipIdCheck&pe=lnk_o&pev2=link%20clicked&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=327&AQE=1", "Referer=https://secure.amp.com.au/", ENDITEM, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s83475998496108?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A12%3A30%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=DDC%3AAMP%20Saver%20Account&g=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&cc=AUD&events=event67&c16=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&v16=D%3Dc16&c25="
		"DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-identityCheck-identity-OK-VerificationCompleted&v25=DDC%3AAMP%20Saver%20Account%3Abtn-applicants-0-identityCheck-identity-OK-VerificationCompleted&pe=lnk_o&pev2=link%20clicked&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=97&AQE=1", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	lr_end_transaction("16_verify your identy online",LR_AUTO);

	lr_start_transaction("17_skip verify id");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_custom_request("save_8", 
		"URL=https://secure.amp.com.au/ddc/public/api/forms/save?formId=2529013615&checkSecurityToken=fceb0ffc-5d0a-4a90-9b8a-db35c2500b0b&formName=SaverAccount&checkDob=01/01/2000&checkName=Test", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t120.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"Perf\",\"surName\":\"Test\",\"dateOfBirth\":\"01/01/2000\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"Mr\",\"Query\":\"Mr\"},\"middleName\":null},\"contactDetails\":{\""
		"emailAddress\":\"perftest03@gmail.com\",\"mobilePhone\":\"0444444444\",\"homePhone\":null},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":\"AUS|4eaba770-c647-42c2-afac-46a4d4fc542b|7.7304OAUSHATlBwAAAAAIAgEAAAAABms2UAAgAAAAAAAAAAD..2QAAAAA.....wAAAAAAAAAAAAAAAAAAAGNodXJjaCBzdHJlZXQAAAAAAA--$13\",\"query\":\"1 Church Street, ABERMAIN  NSW  2326\"},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\","
		"\"Query\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":\"1\",\"streetName\":\"Church\",\"streetType\":{\"SelectedItem\":\"ST\",\"Query\":\"Street\"},\"poBox\":null,\"suburb\":\"Abermain\",\"state\":{\"SelectedItem\":\"NSW\",\"Query\":\"NSW\"},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":\"2326\",\"dpid\":\"71670272\",\"barcode\":\""
		"1301012101202100022102301330203203313\",\"isInternational\":false},\"isItPoBox\":false},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":true,\"ok\":true,\"taxFileNumber\":null,\"change\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\"applicants.0.personalDetails.address\",\"crsStatus\":\"pass\",\"addresses\":[\"1 Church Street, ABERMAIN  NSW  2326\",\"1 Church Street, "
		"ABERMAIN  NSW  2326\"],\"countries\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":false},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":\"WIE\",\"Query\":\"Income from employment (regular and/or bonus)\"},\"sourceOfFundsForAccount\":{\"SelectedItem\":\"FII\",\"Query\":\"Investment income (e.g. rent, dividends, pension)\"},\"reasonForOpeningAccount\":{\"SelectedItem\":\"EB\",\"Query\":\"Everyday banking (e.g. regular"
		" deposits and withdrawals for everyday expenses)\"}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\"verificationId\":\"k1nxnJEB\",\"verificationStatus\":\"IN_PROGRESS\"}}}}],\"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}", 
		EXTRARES, 
		"Url=https://amp.d2.sc.omtrdc.net/b/ss/amp-dtm-prd/1/JS-2.22.0-LBSQ/s8403220801036?AQB=1&ndh=1&pf=1&t=29%2F5%2F2021%2016%3A12%3A47%202%20-600&mid=23569144125047983874531016401195797023&aamlh=8&ce=UTF-8&cdp=3&fpCookieDomainPeriods=3&pageName=DDC%3AAMP%20Saver%20Account&g=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&cc=AUD&events=event67&c16=https%3A%2F%2Fsecure.amp.com.au%2Fddc%2Fpublic%2Fui%2Fsaver-account%2F&v16=D%3Dc16&c25="
		"DDC%3AAMP%20Saver%20Account%3Abtn-accountDetails-declarations-lastStep-OK&v25=DDC%3AAMP%20Saver%20Account%3Abtn-accountDetails-declarations-lastStep-OK&pe=lnk_o&pev2=link%20clicked&s=1500x1000&c=24&j=1.6&v=N&k=Y&bw=1500&bh=857&mcorgid=11BA6EA55322342B0A490D44%40AdobeOrg&lrt=126&AQE=1", "Referer=https://secure.amp.com.au/", ENDITEM, 
		LAST);

	lr_end_transaction("17_skip verify id",LR_AUTO);

	lr_start_transaction("18_declaration");

	web_custom_request("save_9", 
		"URL=https://secure.amp.com.au/ddc/public/api/forms/save?formId=2529013615&checkSecurityToken=fceb0ffc-5d0a-4a90-9b8a-db35c2500b0b&formName=SaverAccount&checkDob=01/01/2000&checkName=Test", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://secure.amp.com.au/ddc/public/ui/saver-account/", 
		"Snapshot=t121.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"Perf\",\"surName\":\"Test\",\"dateOfBirth\":\"01/01/2000\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"Mr\",\"Query\":\"Mr\"},\"middleName\":null},\"contactDetails\":{\""
		"emailAddress\":\"perftest03@gmail.com\",\"mobilePhone\":\"0444444444\",\"homePhone\":null},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":\"AUS|4eaba770-c647-42c2-afac-46a4d4fc542b|7.7304OAUSHATlBwAAAAAIAgEAAAAABms2UAAgAAAAAAAAAAD..2QAAAAA.....wAAAAAAAAAAAAAAAAAAAGNodXJjaCBzdHJlZXQAAAAAAA--$13\",\"query\":\"1 Church Street, ABERMAIN  NSW  2326\"},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\","
		"\"Query\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":\"1\",\"streetName\":\"Church\",\"streetType\":{\"SelectedItem\":\"ST\",\"Query\":\"Street\"},\"poBox\":null,\"suburb\":\"Abermain\",\"state\":{\"SelectedItem\":\"NSW\",\"Query\":\"NSW\"},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":\"2326\",\"dpid\":\"71670272\",\"barcode\":\""
		"1301012101202100022102301330203203313\",\"isInternational\":false},\"isItPoBox\":false},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":true,\"ok\":true,\"taxFileNumber\":null,\"change\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\"applicants.0.personalDetails.address\",\"crsStatus\":\"pass\",\"addresses\":[\"1 Church Street, ABERMAIN  NSW  2326\",\"1 Church Street, "
		"ABERMAIN  NSW  2326\"],\"countries\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":false},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":\"WIE\",\"Query\":\"Income from employment (regular and/or bonus)\"},\"sourceOfFundsForAccount\":{\"SelectedItem\":\"FII\",\"Query\":\"Investment income (e.g. rent, dividends, pension)\"},\"reasonForOpeningAccount\":{\"SelectedItem\":\"EB\",\"Query\":\"Everyday banking (e.g. regular"
		" deposits and withdrawals for everyday expenses)\"}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\"verificationId\":\"k1nxnJEB\",\"verificationStatus\":\"IN_PROGRESS\"}}}}],\"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":true,\"acceptTandCsDeclaration\":true,\"acceptCRSDeclaration\":true}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}", 
		LAST);

	lr_end_transaction("18_declaration",LR_AUTO);

	return 0;
}